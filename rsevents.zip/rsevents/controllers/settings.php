<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');

class RSEventsSettings {

function save($task)
{
	global $wpdb;
	$rseventsConfigPost = $_POST['rseventsConfig'];
	
	if(isset($rseventsConfigPost['layouts.eventintro']) && strpos($rseventsConfigPost['layouts.eventintro'],'{EventName}') !== false && strpos($rseventsConfigPost['layouts.eventintro'],'{EventLink}') !== false ) RSEventsHelper::redirect('admin.php?page=rse_settings&message=1'); 
	
	$rseventsConfigDb = $wpdb->get_results("SELECT * FROM `".$wpdb->prefix."rsevents_config`");
	foreach ($rseventsConfigDb as $objConfig)
		if(isset($rseventsConfigPost[$objConfig->ConfigName]))
			$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_config SET ConfigValue='".$rseventsConfigPost[$objConfig->ConfigName]."' WHERE ConfigName='".$objConfig->ConfigName."'");
	
	if($task == 'save') RSEventsHelper::redirect('admin.php?page=rsevents&message=2');
	if($task == 'apply') RSEventsHelper::redirect(wp_get_referer().'&message=2');
}

function cancel()
{
	RSEventsHelper::redirect('admin.php?page=rsevents');
}

}
?>