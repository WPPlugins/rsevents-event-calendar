<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');

class RSEventsLocations {

	function addedit($cid)
	{
		global $wpdb;
		if (is_array($cid)) $cid = intval($cid[0]);
		if(empty($cid)) $cid = 0;
		
		RSEventsHelper::redirect('admin.php?page=rse_locations&task=edit&id='.$cid);
	}

	function publish($id,$task)
	{
		global $wpdb;
		$id = intval($id);
	
		if($task == 'publish')
			$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_locations SET published = 1 WHERE IdLocation =".$id);
		if($task == 'unpublish')
			$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_locations SET published = 0 WHERE IdLocation =".$id);
		
		RSEventsHelper::redirect('admin.php?page=rse_locations');
	}
	
	function delete($cids)
	{
		global $wpdb;
		$count = count($cids);
		$i = 0;
		foreach($cids as $cid)
		{
			$hasEvents = $wpdb->get_row("SELECT COUNT(*) AS cnt FROM ".$wpdb->prefix."rsevents_events WHERE IdLocation = ".$cid);
			if($hasEvents->cnt != 0) continue;
			$wpdb->query("DELETE FROM ".$wpdb->prefix."rsevents_locations WHERE IdLocation = ".$cid);
			$i++;
		}
		$message = ($i == $count) ? '&message=5' : '&message=6';
		RSEventsHelper::redirect('admin.php?page=rse_locations'.$message);
	}
	
	function save()
	{
		global $wpdb;
		
		//set variables
		$request = $_REQUEST;
		
		$task					= isset($request['option']) ? $request['option'] : '';
		$id						= isset($request['id']) ? intval($request['id']) : '';
		$LocationName			= isset($request['LocationName']) ? wp_filter_post_kses($request['LocationName']) : '';
		$LocationURL 			= isset($request['LocationURL']) ? $request['LocationURL'] : '';
		$LocationAddress 		= isset($request['LocationAddress']) ? wp_filter_post_kses($request['LocationAddress']) : '';
		$LocationZip 			= isset($request['LocationZip']) ? wp_filter_post_kses($request['LocationZip']) : '';
		$LocationCity 			= isset($request['LocationCity']) ? wp_filter_post_kses($request['LocationCity']) : '';
		$LocationState			= isset($request['LocationState']) ? wp_filter_post_kses($request['LocationState']) : '';
		$LocationCountry 		= isset($request['LocationCountry']) ? wp_filter_post_kses($request['LocationCountry']) : '';
		$LocationDescription	= isset($request['LocationDescription']) ? wp_filter_post_kses($request['LocationDescription']): '';
		$published				= isset($request['published']) ? intval($request['published']): '0';
		
		if(empty($id) || $id == 0)
		{	
			$res = $wpdb->query("INSERT INTO ".$wpdb->prefix."rsevents_locations SET LocationName  = '".$LocationName."' ,LocationURL  = '".$LocationURL."' ,LocationAddress  = '".$LocationAddress."' ,LocationZip  = '".$LocationZip."' ,LocationCity  = '".$LocationCity."' ,LocationState  = '".$LocationState."' ,LocationCountry  = '".$LocationCountry."' ,LocationDescription  = '".$LocationDescription."' , published = ".$published);
			$id = mysql_insert_id();
		} else
			$res = $wpdb->query("UPDATE ".$wpdb->prefix."rsevents_locations SET LocationName  = '".$LocationName."' ,LocationURL  = '".$LocationURL."' ,LocationAddress  = '".$LocationAddress."' ,LocationZip  = '".$LocationZip."' ,LocationCity  = '".$LocationCity."' ,LocationState  = '".$LocationState."' ,LocationCountry  = '".$LocationCountry."' ,LocationDescription  = '".$LocationDescription."', published = ".$published." WHERE IdLocation = ".$id);
		
		
		$message = ($res === false) ? '&message=3' : '&message=4';
		if($task == 'apply') RSEventsHelper::redirect('admin.php?page=rse_locations&task=edit&id='.$id.$message); else RSEventsHelper::redirect('admin.php?page=rse_locations'.$message); 		
	}
	
	function cancel()
	{
		RSEventsHelper::redirect('admin.php?page=rse_locations');
	}

}
?>