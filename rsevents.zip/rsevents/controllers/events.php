<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');

class RSEventsEvents {

	function save()
	{
		global $wpdb,$RSEventsConfig;
		
		$request = $_REQUEST;
		
		$subpage = isset($request['subpage']) ? $request['subpage'] : 'event';
		$id = isset($request['id']) ? $request['id'] : 0;
		$task = isset($request['option']) ? $request['option'] : '';
		
		if($subpage == 'event')
		{		
			$eventname = isset($request['EventName']) ? wp_filter_post_kses($request['EventName']) : '';
			$eventsubtitle = isset($request['EventSubtitle']) ? wp_filter_post_kses($request['EventSubtitle']) : '';
			$evenhost = isset($request['EventHost']) ? wp_filter_post_kses($request['EventHost']) : '';
			$idlocation = isset($request['IdLocation']) ? intval($request['IdLocation']) : 0;
			$iduser = isset($request['IdUser']) ? intval($request['IdUser']) : '';
			$eventurl = isset($request['EventURL']) ? wp_filter_post_kses($request['EventURL']) : '';
			$eventphone = isset($request['EventPhone']) ? wp_filter_post_kses($request['EventPhone']) : '';
			$eventemail = isset($request['EventEmail']) ? wp_filter_post_kses($request['EventEmail']) : '';
			$eventtype = isset($request['EventType']) ? intval($request['EventType']) : '';
			$published = isset($request['published']) ? intval($request['published']) : '';
			$eventampm1 = isset($request['EventAmPm1']) ? intval($request['EventAmPm1']) : '';
			$eventampm2 = isset($request['EventAmPm2']) ? intval($request['EventAmPm2']) : '';
			$EventStartDateH = isset($request['EventStartDateH']) ? $request['EventStartDateH'] : '';
			$EventStartDateM = isset($request['EventStartDateM']) ? $request['EventStartDateM'] : '';
			$EventEndDateH = isset($request['EventEndDateH']) ? $request['EventEndDateH'] : '';
			$EventEndDateM = isset($request['EventEndDateM']) ? $request['EventEndDateM'] : '';
			$EventStartDate = isset($request['EventStartDate']) ? $request['EventStartDate'] : '';
			$EventEndDate = isset($request['EventEndDate']) ? $request['EventEndDate'] : '';
			$icon  = $_FILES['icon'];
			$pathToThumbs = WP_PLUGIN_DIR.'/rsevents/images/thumbs/';
			
			//preparing the date into the unix timestamp
			if($RSEventsConfig['enable.12format'] == 1)
			{
				if($eventampm1 == 0)
					$startH = $EventStartDateH.':'.$EventStartDateM.':00 am';
				else 
					$startH = $EventStartDateH.':'.$EventStartDateM.':00 pm';
				
				if($eventampm2 == 0)
					$endH = $EventEndDateH.':'.$EventEndDateM.':00 am';
				else 
					$endH = $EventEndDateH.':'.$EventEndDateM.':00 pm';
			} else 
			{
				$startH = $EventStartDateH.':'.$EventStartDateM.':00';
				$endH = $EventEndDateH.':'.$EventEndDateM.':00';
			}
			
			$EvStartDate=strtotime($EventStartDate.' '.$startH);
			$EvEndDate=strtotime($EventEndDate.' '.$endH);
			
			if($EvEndDate < $EvStartDate) 
			if($id == 0)
				RSEventsHelper::redirect('admin.php?page=rse_events&task=edit&message=30');
			else
				RSEventsHelper::redirect('admin.php?page=rse_events&task=edit&id='.$id.'&message=30');
			
			if($eventurl == 'http://') $eventurl = '';	
			
			if($id == 0)
			{
				$wpdb->query("INSERT INTO ".$wpdb->prefix."rsevents_events SET EventName = '".$eventname."' , EventSubtitle = '".$eventsubtitle."' , EventHost = '".$evenhost."' , IdLocation = '".$idlocation."' , IdUser = '".$iduser."' , EventURL = '".$eventurl."' , EventPhone = '".$eventphone."' , EventEmail = '".$eventemail."' , EventType = '".$eventtype."' , published = '".$published."' , EventAmPm1 = '".$eventampm1."' , EventAmPm2 = '".$eventampm2."' , EventStartDate = '".$EvStartDate."' , EventEndDate = '".$EvEndDate."' , EventCreation = '".time()."' ");
				$id = mysql_insert_id();
			} else 
			{
				$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_events SET EventName = '".$eventname."' , EventSubtitle = '".$eventsubtitle."' , EventHost = '".$evenhost."' , IdLocation = '".$idlocation."'  , IdUser = '".$iduser."' , EventURL = '".$eventurl."' , EventPhone = '".$eventphone."' , EventEmail = '".$eventemail."' , EventType = '".$eventtype."' , published = '".$published."' , EventAmPm1 = '".$eventampm1."' , EventAmPm2 = '".$eventampm2."' , EventStartDate = '".$EvStartDate."' , EventEndDate = '".$EvEndDate."' WHERE IdEvent = ".$id);
			}
			
			//creating the private Url
			$eventprivateurl = $wpdb->get_var("SELECT EventPrivateUrl FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent='".$id."'");
			if(empty($eventprivateurl))
			{
				if($eventtype == '0') $eventprivateurl = uniqid('',FALSE); else $eventprivateurl = '';
				$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_events SET EventPrivateUrl = '".$eventprivateurl."'");
			}
			
			//create the thumbnail
			if($RSEventsConfig['enable.event.icon'] == 1)
			{
				$uniqid = uniqid('',FALSE);
				RSEventsHelper::createThumbs($icon , $pathToThumbs , $RSEventsConfig['event.icon.small'] , $id, $uniqid);
				RSEventsHelper::createThumbs($icon , $pathToThumbs , $RSEventsConfig['event.icon.big'] , $id, $uniqid);
			}
			
		}
		
		if($subpage == 'description')
		{
			$eventdescription = isset($request['EventDescription']) ? wp_filter_post_kses($request['EventDescription']) : '';
			
			if($id == 0)
			{
				$wpdb->query("INSERT INTO ".$wpdb->prefix."rsevents_events SET EventDescription = '".$eventdescription."' , EventStartDate = '".time()."' , EventEndDate = '".time()."' , EventCreation = '".time()."' ");
				$id = mysql_insert_id();
			} else 
			{
				$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_events SET EventDescription = '".$eventdescription."' , EventCreation = '".time()."' WHERE IdEvent = ".$id);
			}
		}
		
		if($subpage == 'files')
		{	
			$files = $_FILES['files'];
			$allowedExtensions = str_replace(array("\r"," "),"",$RSEventsConfig['event.files']);
			$allowedExtensions = explode("\n",$allowedExtensions);
			$target= WP_PLUGIN_DIR.'/rsevents/files/';
			
			
			if($id == 0)
			{
				$wpdb->query("INSERT INTO ".$wpdb->prefix."rsevents_events SET EventStartDate = '".time()."' , EventEndDate = '".time()."' , EventCreation = '".time()."' ");
				$id = mysql_insert_id();
			} else 
			{
				$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_events SET EventCreation = '".time()."' WHERE IdEvent = ".$id);
			}
			
			for($i=0;$i<10;$i++)
			{
				if(!empty($files['tmp_name'][$i]))
				{
					$extension = end(explode('.', $files['name'][$i]));

						if($extension != '' && array_search($extension,$allowedExtensions) !== false)
						{
							if($files['tmp_name'][$i]!='')
							{
								$fileLocation = uniqid('',FALSE)."_". basename( $files['name'][$i]);
								$file = $target . $fileLocation;
								move_uploaded_file($files['tmp_name'][$i] ,$file);
								$wpdb->query("INSERT INTO ".$wpdb->prefix."rsevents_files (IdEvent,FileName,FileLocation) VALUES ('".$id."','".basename( $files['name'][$i])."','".$fileLocation."') ");
							}
						} else RSEventsHelper::redirect('admin.php?page=rse_events&task=edit&id='.$id.'&message=31');
				}
			}
		}
		
		$spage = '&subpage='.$subpage;
		if($task == 'apply') RSEventsHelper::redirect('admin.php?page=rse_events&task=edit&id='.$id.$spage.'&message=32'); else RSEventsHelper::redirect('admin.php?page=rse_events&message=32');
	}
	
	function saverepeat()
	{
		global $wpdb;
		
		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		if($id == 0) RSEventsHelper::redirect('admin.php?page=rse_events');
		$parent = $id;
		
		$task = isset($_POST['option']) ? $_POST['option'] : '';
		$row = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent = ".$id);
		
		$hour = date('H',$row->EventStartDate);
		$min = date('i',$row->EventStartDate);
		
		$alsoRepeat = array();
		if(isset($_POST['EventRepeatAlso']) && is_array($_POST['EventRepeatAlso']))
			foreach($_POST['EventRepeatAlso'] as $date)
			{
				$datetounix = strtotime($date);
				$date = $datetounix	+ ((($hour * 60) + $min) * 60);
				$alsoRepeat[] = $date;
			}
		
		$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_events SET EventRepeatUntil = '".strtotime($_POST['EventRepeatUntil'])."' , EventEnableRepeat = '".$_POST['EventEnableRepeat']."'  , EventRepeatNumber = '".$_POST['EventRepeatNumber']."' , EventRepeatType = '".$_POST['EventRepeatType']."' , EventRepeatAlso = '".implode(',',$alsoRepeat)."' WHERE IdEvent =".$id);
		
		if($_POST['EventEnableRepeat'] == 1)
		{
		
			$eids = $wpdb->get_results("SELECT IdEvent FROM ".$wpdb->prefix."rsevents_events WHERE IdParent='".$parent."'");
			foreach($eids as $eid)
				$eidss[] = $eid->IdEvent;
			
			$eids = (!empty($eidss)) ? implode(',',$eidss) : '';
			$wpdb->query("DELETE FROM ".$wpdb->prefix."rsevents_events WHERE IdParent='".$parent."'");
			
			$repeatNumber = intval($_POST['EventRepeatNumber']);
			$startdate = $row->EventStartDate;
			$startdates = array();
			
			$repeatuntil = strtotime($_POST['EventRepeatUntil']);
			
			//switch on the type of the repetition
			switch($_POST['EventRepeatType'])
			{
				//Days
				case 1:
				
				while ($startdate<=$repeatuntil)
				{
					$startdate = strtotime('+'.$repeatNumber.' days',  $startdate);
					if($startdate > $repeatuntil) break;
					$startdates[] = $startdate;
					
				}
				//get dates with $startdates
				
				break;
				
				//Weeks
				case 2:
					
					while ($startdate<=$repeatuntil)
					{
						$startdate = strtotime('+'.$repeatNumber.' weeks',  $startdate);
						if($startdate > $repeatuntil) break;
						$startdates[] = $startdate;
						
					}
					//get dates with $startdates
					
				break;
				
				//Months
				case 3:
				
					while ($startdate<=$repeatuntil)
					{
						$startdate = strtotime('+'.$repeatNumber.' months',  $startdate);
						if($startdate > $repeatuntil) break;
						$startdates[] = $startdate;
						
					}
					//get dates with $startdates 
					
				break;
				
				//Years
				case 4:
				
					while ($startdate<=$repeatuntil)
					{
						$startdate = strtotime('+'.$repeatNumber.' year',  $startdate);
						if($startdate > $repeatuntil) break;
						$startdates[] = $startdate;
						
					}
					//get dates with $startdates 
					
				break;
			}	
			
			
			$startdates = array_merge($startdates,$alsoRepeat);
			
			$eventDuration = $row->EventEndDate - $row->EventStartDate; 
			
			foreach($startdates as $date) 
			{
				$ndate = $date + $eventDuration; 
				
				$wpdb->query("INSERT INTO ".$wpdb->prefix."rsevents_events SET IdLocation = '".$row->IdLocation."' , IdUser = '".$row->IdUser."', IdParent = '".$parent."', EventName = '".$row->EventName."', EventSubtitle = '".$row->EventSubtitle."', EventHost ='".$row->EventHost."' ,EventURL = '".$row->EventURL."' , EventPhone = '".$row->EventPhone."', EventEmail = '".$row->EventEmail."', EventDescription ='".$row->EventDescription."', EventType = '".$row->EventType."', EventStartDate = '".$date."', EventEndDate = '".$ndate."', EventPostReminder ='".$row->EventPostReminder."', published ='".$row->published."', EventPrivateUrl ='".$row->EventPrivateUrl."', EventArchive ='".$row->EventArchive."', EventIcon ='".$row->EventIcon."', EventReturnUrl ='".$row->EventReturnUrl."', EventAmPm1 = '".$row->EventAmPm1."', EventAmPm2 = '".$row->EventAmPm2."', EventCreation = '".time()."'");	
				$newid = mysql_insert_id();
			}
		}
		
		if($task == 'apply') RSEventsHelper::redirect('admin.php?page=rse_events&task=eventrepeat&id='.$id.'&message=27'); else RSEventsHelper::redirect('admin.php?page=rse_events&message=27');
	}
	
	function delete($cids)
	{
		global $wpdb;
		
		foreach($cids as $cid)
		{
			$arrayLocations = $wpdb->get_results("SELECT FileLocation FROM ".$wpdb->prefix."rsevents_files WHERE IdEvent=".$cid);
			foreach ($arrayLocations as $obj)
				@unlink(WP_PLUGIN_DIR.'rsevents/files/'.$obj->FileLocation);
			
			$wpdb->query("DELETE FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent = ".$cid);
			$wpdb->query("DELETE FROM ".$wpdb->prefix."rsevents_files WHERE IdEvent = ".$cid);
		}
			
		RSEventsHelper::redirect('admin.php?page=rse_events&message=33');
	}
	
	function deletefile()
	{
		global $wpdb;
		
		$idevent = isset($_POST['eid']) ? intval($_POST['eid']) : 0;
		$id = isset($_POST['gid']) ? intval($_POST['gid']) : 0;
		
		$file = $wpdb->get_var("SELECT FileLocation FROM ".$wpdb->prefix."rsevents_files WHERE IdFile =".$id);
		
		$wpdb->query("DELETE FROM ".$wpdb->prefix."rsevents_files WHERE IdFile = ".$id);
		@unlink(WP_PLUGIN_DIR.'/rsevents/files/'.$file);
		
		RSEventsHelper::redirect('admin.php?page=rse_events&task=edit&subpage=files&id='.$idevent.'&message=28');
	}
	
	function delicon()
	{
		global $wpdb,$RSEventsConfig;
		
		$idevent = isset($_POST['eid']) ? intval($_POST['eid']) : 0;
		
		$icon = $wpdb->get_var("SELECT EventIcon FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent =".$idevent);
		
		$small_icon = str_replace('.jpg','_'.$RSEventsConfig['event.icon.small'].'.jpg',$icon);
		$big_icon = str_replace('.jpg','_'.$RSEventsConfig['event.icon.big'].'.jpg',$icon);
		
		@unlink(WP_PLUGIN_DIR.'/rsevents/images/thumbs/'.$small_icon);
		@unlink(WP_PLUGIN_DIR.'/rsevents/images/thumbs/'.$big_icon);
		
		
		$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_events SET EventIcon = '' WHERE IdEvent = ".$idevent);
		
		RSEventsHelper::redirect('admin.php?page=rse_events&task=edit&id='.$idevent);
	}
	
	function privateurl()
	{
		global $wpdb;
		$id = isset($_POST['eid']) ? intval($_POST['eid']) : 0;
		
		$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_events SET EventPrivateUrl = '".uniqid('',FALSE)."' WHERE IdEvent = ".$id);
		
		RSEventsHelper::redirect('admin.php?page=rse_events&task=edit&id='.$id);
	}
	
	function publish($id,$task)
	{
		global $wpdb;
		$id = intval($id);
	
		if($task == 'publish')
			$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_events SET published = 1 WHERE IdEvent =".$id);
		if($task == 'unpublish')
			$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_events SET published = 0 WHERE IdEvent =".$id);
		
		RSEventsHelper::redirect('admin.php?page=rse_events');
	}
	
	function addedit($cid)
	{
		if (is_array($cid)) $cid = intval($cid[0]);
		if(empty($cid)) $cid = 0;
		
		RSEventsHelper::redirect('admin.php?page=rse_events&task=edit&id='.$cid);
	}
	
	function archive($cids)
	{
		global $wpdb;
		
		foreach($cids as $cid)
			$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_events SET published = -1 , EventArchive = 0 WHERE IdEvent = ".$cid);
			
		RSEventsHelper::redirect('admin.php?page=rse_events');
	}
	
	function cancel()
	{
		RSEventsHelper::redirect('admin.php?page=rse_events');
	}
	
	function cancelticket()
	{
		RSEventsHelper::redirect('admin.php?page=rse_events&task=tickets&id='.$_REQUEST['IdEvent']);
	}
	

}
?>