<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');

$wpdb->query("DROP TABLE IF EXISTS 
`".$wpdb->prefix."rsevents_locations`,
`".$wpdb->prefix."rsevents_config`,
`".$wpdb->prefix."rsevents_events`,
`".$wpdb->prefix."rsevents_files`");
?>