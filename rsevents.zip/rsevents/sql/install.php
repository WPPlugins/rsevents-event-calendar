<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');


$wpdb->query("CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."rsevents_events` (
  `IdEvent` int(11) NOT NULL AUTO_INCREMENT,
  `IdLocation` int(11) NOT NULL,
  `IdUser` int(11) NOT NULL,
  `IdParent` tinyint(2) NOT NULL,
  `EventName` varchar(255) NOT NULL,
  `EventSubtitle` varchar(255) NOT NULL,
  `EventHost` varchar(255) NOT NULL,
  `EventURL` varchar(255) NOT NULL,
  `EventPhone` varchar(255) NOT NULL,
  `EventEmail` varchar(255) NOT NULL,
  `EventDescription` text NOT NULL,
  `EventType` tinyint(1) NOT NULL DEFAULT '1',
  `EventStartDate` int(11) NOT NULL,
  `EventEndDate` int(11) NOT NULL,
  `EventPostReminder` tinyint(1) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `EventPrivateUrl` varchar(255) NOT NULL,
  `EventEnableRepeat` tinyint(2) NOT NULL,
  `EventRepeatType` tinyint(2) NOT NULL,
  `EventRepeatNumber` int(10) NOT NULL,
  `EventRepeatUntil` int(11) NOT NULL,
  `EventRepeatAlso` text NOT NULL,
  `EventArchive` tinyint(2) NOT NULL,
  `EventIcon` text NOT NULL,
  `EventAmPm1` int(1) NOT NULL,
  `EventAmPm2` int(1) NOT NULL,
  `EventCreation` int(15) NOT NULL,
  PRIMARY KEY (`IdEvent`),
  KEY `IdLocation` (`IdLocation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");


$wpdb->query("CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."rsevents_files` (
  `IdFile` int(11) NOT NULL AUTO_INCREMENT,
  `IdEvent` int(11) NOT NULL,
  `FileName` text NOT NULL,
  `FileDescription` text NOT NULL,
  `FileLocation` text NOT NULL,
  PRIMARY KEY (`IdFile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");


$wpdb->query("CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."rsevents_locations` (
  `IdLocation` int(11) NOT NULL AUTO_INCREMENT,
  `LocationName` varchar(255) NOT NULL,
  `LocationDescription` text NOT NULL,
  `LocationURL` varchar(255) NOT NULL,
  `LocationCity` varchar(255) NOT NULL,
  `LocationAddress` varchar(255) NOT NULL,
  `LocationZip` varchar(255) NOT NULL,
  `LocationState` varchar(255) NOT NULL,
  `LocationCountry` varchar(255) NOT NULL,
  `published` tinyint(1) NOT NULL,
  PRIMARY KEY (`IdLocation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");


$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_locations` (`IdLocation`, `LocationName`, `LocationDescription`, `LocationURL`, `LocationCity`, `LocationAddress`, `LocationZip`, `LocationState`, `LocationCountry`,`published`) VALUES(1, 'My first location', 'Location description', 'http://myfirstlocation.com', 'My city', 'My address', 'zip', 'My state', 'My country',1);");


$wpdb->query("CREATE TABLE IF NOT EXISTS `".$wpdb->prefix."rsevents_config` (
  `IdConfig` int(11) NOT NULL AUTO_INCREMENT,
  `ConfigName` varchar(255) NOT NULL,
  `ConfigValue` text NOT NULL,
  PRIMARY KEY (`IdConfig`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");


$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(8, 'global.dateformat', 'd M y H:i:s');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(9, 'layouts.eventintro', '<tr>\r\n	<td>{EventStartDate} - {EventEndDate}</td>\r\n	<td><a href=\"{EventLink}\">{EventName}</a></td>\r\n	<td><a href=\"{LocationLink}\">{LocationName}</a></td>\r\n</tr>');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(10, 'event.files', 'zip\r\ngif\r\njpg\r\ntxt\r\n');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(14, 'emails.from', 'from@email.com');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(15, 'emails.reply', 'reply@email.com');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(25, 'emails.from.name', 'From name');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(26, 'emails.invite.subject', 'Invitation to {EventName}');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(27, 'emails.invite.type', '1');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(28, 'emails.invite.content', 'Hello ,\r\n\r\nYou have been invited to {EventName} which starts on {EventStartDate} and will end on {EventEndDate} at {LocationName}\r\n\r\n{EventName}  {message}');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(41, 'event.enable.autoarchive', '0');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(44, 'emails.cc', '');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(45, 'emails.bcc', '');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(47, 'events.layout', '2');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(48, 'enable.event.icon', '1');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(49, 'event.icon.small', '80');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(50, 'event.icon.big', '185');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(54, 'event.show.invite', '1');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(55, 'event.show.outlook', '1');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(63, 'enable.12format', '0');");
$wpdb->query("INSERT IGNORE INTO `".$wpdb->prefix."rsevents_config` (`IdConfig`, `ConfigName`, `ConfigValue`) VALUES(65, 'events.perpage', '10');");



?>