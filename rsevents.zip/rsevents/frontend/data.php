<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');

class RSEventsDataFrontend {


/* Events */

//get all events data 
function getEvents($nolimit=null)
{
	global $wpdb,$rseargs,$userdata,$RSEventsConfig;
	
	if(isset($_GET['task'])) $task = $_GET['task']; elseif(isset($rseargs['task'])) $task = $rseargs['task']; else $task = '';
	
	$limit = $RSEventsConfig['events.perpage'];
	$limitstart = isset($_REQUEST['limitstart']) ? intval($_REQUEST['limitstart']) : 0;
	
	// In case limit has been changed, adjust it
	$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
	
	$setlimit = ($limit == 0 && $limitstart == 0 ) ? "" :" LIMIT ".$limitstart." , ".$limit." ";
	if($nolimit == 1) $setlimit = '';
	
	switch($task)
	{
		case '':
		default:
			
			$expired = isset($rseargs['expired']) ? (strtolower($rseargs['expired']) == 'no' ? 0 : 1) : 0;
			$l_filter = isset($_REQUEST['loc_filter']) ? intval($_REQUEST['loc_filter']) : '';
			$filter = isset($_REQUEST['rse_filter']) ? $_REQUEST['rse_filter'] : '';
			
			if($expired == 1)
			$published = " AND e.published IN ('-1','1') ";
			else
			$published = " AND e.published = '1' ";
			$where = " AND e.EventType = '1' ";
			
			if ($l_filter == 0) $loc_filter = ''; else $loc_filter = " AND l.IdLocation = '".$l_filter."' ";
			$filter = " AND (e.EventName LIKE '%".$wpdb->escape($filter)."%' OR e.EventDescription LIKE '%".$wpdb->escape($filter)."%' OR l.LocationName LIKE '%".$wpdb->escape($filter)."%') ".$loc_filter;
		break;
		
		case 'myevents':
			
			$where = isset($userdata->ID) ? " AND e.IdUser=".$userdata->ID : ''; 
			$published = '';
			$filter ='';
		break;
		
		case 'archive':
		
			$esearch = isset($rseargs['enablesearch']) ? (strtolower($rseargs['enablesearch']) == 'no' ? 0 : 1) : 0;
			$search_filter = isset($_REQUEST['rse_filter']) ? $_REQUEST['rse_filter'] : ''; 
			$where = ''; 
			if($esearch == 1) $where  = " AND e.EventName LIKE '%".$wpdb->escape($search_filter)."%' ";
			$published = ' AND e.published = -1 ';
			$filter ='';
		break;
		
		case 'daysevents':
			
			$startDate = isset($rseargs['startdate']) ? $rseargs['startdate'] : '01/01/1999';
			$endDate = isset($rseargs['enddate']) ? $rseargs['enddate'] : '01/01/2037';
			
			$start = strtotime($startDate);
			$end = strtotime($endDate);
		
			$published = " AND e.published = 1 ";
			
			$q1 = ' AND e.EventStartDate >= '.$start;
			$q2 = ' AND e.EventEndDate <= '.$end;
			$q3 = ' AND e.EventType = 1 ';
			$where = $q1 . $q2 . $q3;
			$filter ='';
		break;
		
		case 'listlocationevents':
		
			if(isset($_GET['id'])) $id = intval($_GET['id']); elseif(isset($rseargs['id'])) $id = intval($rseargs['id']); else $id = '0';
			
			$published = " AND e.published = '1' ";
			$where = " AND l.IdLocation = '".$id."'";
			$where .= " AND e.EventType = '1' ";
			$filter ='';
		break;
		
		case 'futureevents':
		
			$days = isset($rseargs['days']) ? intval($rseargs['days']) : '3';
			$sTime = time();
			$eTime = $sTime + ( $days * 86400);
			$published = " AND e.published = '1' ";
			$where = " AND e.EventStartDate >= ".$sTime." AND e.EventStartDate <= ".$eTime." ";
			$filter ='';
		break;
	}
	
	$ordering = isset($rseargs['order']) ? $rseargs['order'] : 'DESC';
	
	$columns[] = 'e.IdEvent';
	$columns[] = 'e.EventName';
	$columns[] ='e.EventSubtitle';
	$columns[] ='e.EventDescription';
	$columns[] ='l.LocationName';
	$columns[] ='e.EventStartDate';
	$columns[] ='e.EventEndDate';
	$columns[] ='e.EventHost';
	$columns[] ='l.IdLocation';
	$columns[] ='e.EventIcon';
	$columns[] ='e.EventCreation';
	$columns = implode(',',$columns);
	
	$return = $wpdb->get_results("SELECT ".$columns." FROM ".$wpdb->prefix."rsevents_events e "
				  ."LEFT JOIN ".$wpdb->prefix."rsevents_locations l ON e.IdLocation=l.IdLocation "
				  ."WHERE 1=1 ".$published.$where.$filter." GROUP BY e.IdEvent  ORDER BY e.EventStartDate ".$ordering.$setlimit);
	
	return $return;
}

//get the total number of events
function getTotalEvents()
{
	return count(RSEventsDataFrontend::getEvents('1'));
}

//get the event
function getEvent($idev=null)
{
	global $wpdb,$rseargs,$RSEventsConfig;
	
	if($idev==null)
	{
		if(isset($_GET['id'])) $id = intval($_GET['id']); elseif(isset($rseargs['id'])) $id = intval($rseargs['id']); else $id = '0';
	
	} else $id = intval($idev);
	
	$row = $wpdb->get_row("SELECT e.*, l.IdLocation, l.LocationName, l.LocationAddress, l.LocationCity ,l.LocationCountry, l.LocationState ,l.IdLocation , l.LocationZip , l.locationCountry, f.FileName, f.FileLocation , u.user_login AS EventOwner "
				  ."FROM ".$wpdb->prefix."rsevents_events e "
				  ."LEFT JOIN ".$wpdb->prefix."rsevents_locations l ON e.IdLocation = l.IdLocation   "
				  ."LEFT JOIN ".$wpdb->prefix."users u ON e.IdUser = u.ID "
				  ."LEFT JOIN ".$wpdb->prefix."rsevents_files f ON f.IdEvent=e.IdEvent "
				  ."WHERE e.IdEvent='".$id."'");
	
	
	if(empty($row)) $row = RSEventsDataFrontend::initEvent();
	if(empty($row->EventStartDate))
	{
		$row->EventStartDate = time();
		if($RSEventsConfig['enable.12format'] == 1)
		{
			$row->EventStartDateH='11';
			$row->EventStartDateM='00';
		} else 
		{
			$row->EventStartDateH='20';
			$row->EventStartDateM='00';
		}
	} else 
	{
		if($RSEventsConfig['enable.12format'] == 1)
			$row->EventStartDateH = date('g',$row->EventStartDate);
		else
			$row->EventStartDateH = date('H',$row->EventStartDate);
		$row->EventStartDateM = date('i',$row->EventStartDate);
	}
	
	if(empty($row->EventEndDate)) 
	{
		$row->EventEndDate = $row->EventStartDate;
		if($RSEventsConfig['enable.12format'] == 1)
		{
			$row->EventEndDateH = '12';
			$row->EventEndDateM = '00';
		} else 
		{
			$row->EventEndDateH = '22';
			$row->EventEndDateM = '00';
		}
	} else 
	{
		if($RSEventsConfig['enable.12format'] == 1)
			$row->EventEndDateH = date('g',$row->EventEndDate);
		else
			$row->EventEndDateH = date('H',$row->EventEndDate);
		$row->EventEndDateM = date('i',$row->EventEndDate);
	}

	return $row;
}

function initEvent()
{
	global $userdata;
	
	
	$row = new stdClass();
	$row->published = '1';
	$row->EventName = '';
	$row->EventSubtitle = '';
	$row->EventPhone = '';
	$row->EventHost = '';
	$row->EventEmail = '';
	$row->IdCategory = '0';
	$row->IdLocation = '0';
	$row->EventAmPm1 = '0';
	$row->EventAmPm2 = '0';
	$row->EventIcon = '';
	$row->EventType = '1';
	$row->IdEvent = 0;
	$row->EventOwner = '';
	
	return $row;
}


//loads the files attached to an event
	
function getFiles()
{
	global $wpdb,$rseargs;
	
	if(isset($_GET['id'])) $id = intval($_GET['id']); elseif(isset($rseargs['id'])) $id = intval($rseargs['id']); else $id = '0';
	$rows = $wpdb->get_results("SELECT IdFile, IdEvent, FileName , FileLocation FROM ".$wpdb->prefix."rsevents_files WHERE IdEvent='".$id."'");
	
	return $rows;
}


//show the search 
function showSearch()
{
	global $wpdb,$rseargs;
	
	//search variables
	$show_search = isset($rseargs['enablesearch']) ? (strtolower($rseargs['enablesearch']) == 'no' ? 0 : 1) : 0;
	$show_loc = isset($rseargs['locfilter']) ? (strtolower($rseargs['locfilter']) == 'no' ? 0 : 1) : 0;
	$filter = isset($_REQUEST['rse_filter']) ? $_REQUEST['rse_filter'] : '';
	
	$html = '';
	
	if ($show_search == 1) 
	{
		$html .='
			<div style="text-align:center;">
			<form method="post" action="">
			<input type="text" id="rse_filter" name="rse_filter" value="'.$filter.'"/>'; 
	
	if ($show_loc == 1)
	{
		$html .= '<select size="1" id="loc_filter" name="loc_filter">';
		$html .= '<option value="">'.RSE_EVENT_SELECT_LOCATION.'</option>';
		$locs = $wpdb->get_results("SELECT IdLocation,LocationName FROM ".$wpdb->prefix."rsevents_locations WHERE published = 1 ");
		
		foreach($locs as $loc)
			$html .= '<option value="'.$loc->IdLocation.'">'.$loc->LocationName.'</option>';
			
		$html .= '</select>';
	}
		
		$html .= '<button type="submit">'.RSE_SEARCH.'</button>
				</form>
				</div><br/>';
	}
	
	return $html;
}

/* Locations */

//get all locations

function getLocations()
{
	global $wpdb,$rseargs;
	
	$order = isset($rseargs['order']) ? $rseargs['order'] : 'ASC'; 
	
	$return = $wpdb->get_results("SELECT IdLocation, LocationName, LocationDescription FROM ".$wpdb->prefix."rsevents_locations WHERE published = 1 ORDER BY LocationName ".$order);
	
	return $return;
}

//get a specific location details

function getLocation($id)
{
	global $wpdb,$rseargs,$wp_query;
	
	$post = $wp_query->post;
	$post_id = $post->ID;
	$url= get_bloginfo('wpurl').'/index.php?page_id='.$post_id;
	
	$indb = $wpdb->get_var("SELECT IdLocation FROM ".$wpdb->prefix."rsevents_locations WHERE IdLocation = ".$id);
	if(empty($indb)) RSEventsHelper::redirect($url.'&view=locations&task=list');
	
	$return = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."rsevents_locations WHERE IdLocation = ".$id);
	
	return $return;
}

/* Calendar */

function getEventCalendar()
{
	global $wpdb,$userdata,$rseargs;
	
	$locations = isset($rseargs['locations']) ? $rseargs['locations'] : '';
	$userev = isset($rseargs['userev']) ? (strtolower($rseargs['userev']) == 'no' ? '' : 1 ) : '';
	$arhive = isset($rseargs['arhiveev']) ? (strtolower($rseargs['arhiveev']) == 'no' ? 0 : 1) : '0';
	$order  = isset($rseargs['order']) ? $rseargs['order'] : 'DESC';
	$where = '';
	
	if($arhive == 1)
		$where .= " AND e.published IN ('-1','1') ";
	elseif($arhive == 0) $where .= " AND e.published = 1 ";
	
	if ($userev && isset($userdata->ID)) $where .= " AND e.IdUser = ".$userdata->ID." ";
	
	if(!$userev)
	{
		if(!empty($locations)) $where .= " AND l.IdLocation IN (".$locations.") ";
	}
	
	$ordering = " ORDER BY e.EventStartDate $order ";
	
	
	$return = $wpdb->get_results("SELECT e.IdEvent , e.EventName , e.EventStartDate , e.EventEndDate , l.LocationName FROM ".$wpdb->prefix."rsevents_events e LEFT JOIN ".$wpdb->prefix."rsevents_locations l ON l.IdLocation = e.IdLocation WHERE 1=1 ".$where.$ordering);
	
	return $return;
}

function getEventDays($start , $end=0)
{
	//get variables
	global $wpdb,$rseargs;
	
	$order = isset($rseargs['order']) ? $rseargs['order'] : 'ASC';
	
		if($end == 0)
		$where = " AND ((e.EventStartDate <= '".$start."' AND e.EventEndDate >= '".$start."') OR (e.EventStartDate >= '".$start."' AND e.EventStartDate <= '".($start+86400)."')) ";
		else
		$where = " AND ((e.EventStartDate <= '".$start."' AND e.EventEndDate >= '".$start."') OR (e.EventStartDate >= '".$start."' AND e.EventStartDate <= '".($end)."')) ";
	
	$return = $wpdb->get_results("SELECT e.IdEvent , e.EventName , e.EventSubtitle , e.EventDescription , e.EventStartDate , e.EventEndDate , e.EventHost , l.LocationName , l.LocationCity , e.EventIcon , l.IdLocation FROM ".$wpdb->prefix."rsevents_events e LEFT JOIN ".$wpdb->prefix."rsevents_locations l ON e.IdLocation=l.IdLocation WHERE 1=1 AND e.published = 1 AND e.EventType = 1 ".$where." GROUP BY e.IdEvent ORDER BY e.EventStartDate $order ");
	
	return $return;
}


}

?>