<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');

require_once(WP_PLUGIN_DIR.'/rsevents/data/pagination.php');

//get the id of the page and the site url
$post = $wp_query->post;
$post_id = $post->ID;
$url= get_bloginfo('wpurl').'/index.php?page_id='.$post_id;

if(isset($_GET['task']))
	$task = $_GET['task'];
elseif(isset($args['task']))
	$task = $args['task'];
else $task = 'events';

switch($task)
{
	default:
	case 'events':
	case 'myevents':
	case 'archive':
	case 'daysevents':
	case 'listlocationevents':
	case 'futureevents':
		
		$startdate = isset($rseargs['startdate']) ? $rseargs['startdate'] : '01/01/1999';
		$enddate = isset($rseargs['enddate']) ? $rseargs['enddate'] : '01/01/2037';
		
		if($task == 'events' || $task == '') echo '<h2>'.RSE_EVENTS.'</h2><br/>';
		if($task == 'myevents' && isset($userdata->ID)) echo '<h2>'.RSE_MY_EVENTS.'</h2><br/>'; 
		if($task == 'myevents' && !isset($userdata->ID)) echo '<h2>'.RSE_EVENTS.'</h2><br/>';
		if($task == 'archive') echo '<h2>'.RSE_ARCHIVE.'</h2><br/>';
		if($task == 'daysevents') echo '<h2>'.RSE_EVENTS_FROM.' '.$startdate.' '.RSE_EVENTS_TO.' '.$enddate.'</h2><br/>';
		if($task == 'listlocationevents') 
		{
			if(isset($_GET['id'])) $id = intval($_GET['id']); elseif(isset($rseargs['id'])) $id = intval($rseargs['id']); else $id = '0';
			$locname = $wpdb->get_var("SELECT LocationName FROM ".$wpdb->prefix."rsevents_locations WHERE IdLocation = ".$id);
			echo '<h2>'.RSE_EVENTS_FROM.' "'.$locname.'"</h2><br/>';
		}
		if($task == 'futureevents') echo '<h2>'.RSE_FUTURE_EVENTS.'</h2><br/>';
		
		$events = RSEventsDataFrontend::getEvents();
		$total = RSEventsDataFrontend::getTotalEvents();
		$limit = isset($_REQUEST['limit']) ? intval($_REQUEST['limit']) : $RSEventsConfig['events.perpage'];
		$limitstart = isset($_REQUEST['limitstart']) ? intval($_REQUEST['limitstart']) : 0;
		$pagination = new RSPagination($total,$limitstart,$limit); 
		
		if(isset($rseargs['searchlocation']))
		{
			if(strtolower($rseargs['searchlocation']) == 'up')
				$search_location = 0;
			elseif(strtolower($rseargs['searchlocation']) == 'down')
				$search_location = 1;
			elseif(strtolower($rseargs['searchlocation']) == 'updown')
				$search_location = 2;
			else $search_location = 1;
		} else $search_location = 1;
		
		/* Start Data */
		$layouts = array();
		//replace the placeholders
		if(!empty($events))
		{
			foreach($events as $i => $objList)
			{
				$layout = $RSEventsConfig['layouts.eventintro'];
				
				// event link
				$eventLink = $url.'&view=events&task=show&id='.$objList->IdEvent;
				//location link
				$locationLink = $url.'&view=locations&task=show&id='.$objList->IdLocation;
				
				//get the icon of the event
				$small_icon = str_replace('.jpg','_'.$RSEventsConfig['event.icon.small'].'.jpg',$objList->EventIcon);
				if($RSEventsConfig['enable.event.icon'] && $objList->EventIcon != '')
					$eventIcon = '<div class="rsevents_icon"><a href="'.$eventLink.'"><img src="'.WP_PLUGIN_URL.'/rsevents/images/thumbs/'.$small_icon.'" /></a></div>';
				else 
					$eventIcon = '';
				
				$enableReg = $wpdb->get_var("SELECT EventEnableRegistration FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent = ".$objList->IdEvent);
				
				if($enableReg == 1)
					$subscribeevent = '<a href="'.$url.'&view=events&task=subscribe&id='.$objList->IdEvent.'">'.RSE_MENU_EVENT_SUBSCRIBE.'</a>';
				else 
					$subscribeevent = '';

				$bad  = array('{EventLink}','{LocationLink}','{EventIcon}','{EventSubscribe}');
				$good = array($eventLink,$locationLink,$eventIcon,$subscribeevent);
				
				$layout = str_replace($bad,$good,$layout);
				$properties = array();
				$values = array();
				$objList->EventStartDate = RSEventsHelper::translateDate(date($RSEventsConfig['global.dateformat'],$objList->EventStartDate));
				$objList->EventEndDate = RSEventsHelper::translateDate(date($RSEventsConfig['global.dateformat'],$objList->EventEndDate));
				$objList->EventDescription = RSEventsHelper::strip_html_tags(RSEventsHelper::shorten($objList->EventDescription));
				
				foreach($objList as $property => $value)
				{
					$properties[] = '{'.$property.'}';
					$values[] = $value;
				}

				$layouts[] = str_replace($properties, $values, $layout);
			}
		}
		/* End Data */
		
		/* Start View */
		
		if($search_location == 0  || $search_location == 2) echo RSEventsDataFrontend::showSearch(); 
		
		if ($RSEventsConfig['events.layout'] == 2) { ?> 
		<table class="rsevents-table-list" cellspacing="0" cellpadding="0" width="100%">
			<thead>
				<tr>
					<th>
						<?php echo RSE_DATE; ?>
					</th>
					<th>
						<?php echo RSE_EVENTNAME; ?>
					</th>
					<th>
						<?php echo RSE_LOCATION_NAME1; ?>
					</th> 
				</tr>
			</thead>
			<tbody>
		<?php
		} 
		//showing the events 
		if(!empty($layouts))
		   foreach($layouts as $layout)
			  echo $layout ;
		else
		   echo RSE_NO_EVENTS;

		echo ($RSEventsConfig['events.layout'] == 2) ? "</tbody>\n</table>" : "";
?>		
		<div class="rsfiles-pagination">
			<div class="rsfl_pageslinks">
				<?php echo $pagination->getPagesLinks(); ?>
			</div>
			<p class="rsfl_pagescounter">
				<?php echo $pagination->getTotalPages(); ?>
			</p>
		</div>
		<br/>
<?php
		if($search_location == 1 || $search_location == 2) 	echo RSEventsDataFrontend::showSearch(); 
		
		/* End View */
		
	break; 
	
	case 'show':
	
	$event=RSEventsDataFrontend::getEvent();
	$layout = RSEventsHelper::showEvent();
	
	echo $layout;
?>	
	<span id="rsevents-clear"></span>

	<br/>
	
<?php	
	break;
	
	case 'cancelevent':
		
		//get variables
		$id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
		$usertype = !empty($userdata->wp_capabilities) ? key($userdata->wp_capabilities) : '';
		
		$res = $wpdb->get_var("SELECT IdUser FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent='".$id."'");
		if($usertype == 'administrator' || $userdata->ID == $res )
		{			
			$arrayLocations = $wpdb->get_results("SELECT FileLocation FROM ".$wpdb->prefix."rsevents_files WHERE IdEvent='".$id."'");
			foreach ($arrayLocations as $obj)
				@unlink(WP_PLUGIN_DIR.'/rsevents/files/'.$obj->FileLocation);
			
			$wpdb->query("DELETE FROM ".$wpdb->prefix."rsevents_files WHERE IdEvent=".$id);
			$wpdb->query("DELETE FROM ".$wpdb->prefix."rsevents_tickets WHERE IdEvent='".$id."'");
			$idSubscriptions = $wpdb->get_results("SELECT IdSubscription FROM ".$wpdb->prefix."rsevents_subscriptions WHERE IdEvent='".$id."'");
			
			foreach($idSubscriptions as $idSubscription)
				$wpdb->query("DELETE FROM ".$wpdb->prefix."rsevents_subscription_tickets WHERE IdSubscription='".$idSubscription->IdSubscription."'");

			$wpdb->query("DELETE FROM ".$wpdb->prefix."rsevents_subscriptions WHERE IdEvent='".$id."'");
			$wpdb->query("DELETE FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent='".$id."'");
			$msg = 44;						
		} else $msg = 39;
		
		RSEventsHelper::redirect($url.'&view=events&task=events&message='.$msg);
	
	break;
	
	case 'invite':
		
		$id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
		$option = isset($_POST['option']) ? $_POST['option'] : '';
		if($option == 'sendinvites') RSEventsControllerFrontend::sendinvites();
		$layout = RSEventsHelper::showEvent('invite');
		$data = $wpdb->get_row("SELECT EventType,EventPrivateUrl FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent =".$id);
		echo $layout[0];
	
?>
		<script type="text/javascript">
		tinyMCE.init({
			// General options
			mode : "exact",
			elements : "rse_message",
			theme : "advanced",
			plugins : "style,layer,table,advimage,advlink,emotions,preview,searchreplace,directionality,noneditable,visualchars,nonbreaking,template,inlinepopups",

			// Theme options
			theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,styleselect,formatselect,fontselect,fontsizeselect",
			theme_advanced_buttons2 : "search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
			theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,|,ltr,rtl",
			theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,restoredraft",
			theme_advanced_toolbar_location : "top",
			theme_advanced_toolbar_align : "left",
			theme_advanced_statusbar_location : "bottom",
			theme_advanced_resizing : true,
		});
	</script>
		<div id="rsevents-action">
		<form action="" method="post" name="adminForm" id="adminForm">
		<?php echo RSE_FROM; ?> : <input type="text" value="" name="rse_from" size="40" />
		<br/><br/>
		<?php echo RSE_INVITE_ADDRESSES; ?>
		<br/>
		<textarea name="emails" rows="10" cols="100" class="rsevents-message" id="rsevents-emails"><?php echo ''; ?></textarea>
		<br/>
		<?php echo RSE_INVITE_IMPORTS; ?>
		<div id="rse_importers">
			<table>
				<tr>
					<td colspan="2">
						<input type="radio" name="importfrom" value="yahoo" id="yahoo" checked="checked" onclick="rse_change_carrier('yahoo');"/>
						<label for="yahoo"><img src="<?php echo WP_PLUGIN_URL;?>/rsevents/images/icons/yahoo.png" border="0"/></label>
						
						<input type="radio" name="importfrom" value="gmail" id="gmail" onclick="rse_change_carrier('gmail');"/>
						<label for="gmail"><img src="<?php echo WP_PLUGIN_URL;?>/rsevents/images/icons/gmail.png" border="0"/></label>
					</td>
				</tr>
				<tr>
					<td>
						<?php echo RSE_USER_ID; ?> : 
					</td>
					<td>
						<input name="username" type="text" id="username"/><span id="rsevents-carrier">@yahoo.com</span>
					</td>
				</tr>
				<tr>
					<td>
						<?php echo RSE_PASSWORD; ?> : 
					</td>
					<td>
						<input name="password" type="password" id="password" />
					</td>
				</tr>
			</table>
		<button type="button" onclick="return rsevents_import_validation('<?php echo WP_PLUGIN_URL; ?>');"><?php echo RSE_IMPORT_NOW;?></button>
		<input name="typename" id="typename" type="hidden" value="yahoo">
		</div>
		<br/>
		<br/>
		<?php echo RSE_INVITE_MESSAGE; ?>
		<br/>
		<textarea id="rse_message" name="rse_message"></textarea>
		<br/><br/><br/>
		<button type="submit" onclick="return rsevents_invite_validation();" style="float:left;"><?php echo RSE_INVITE; ?></button>
		<button type="button" style="float:left;" onclick="document.location='<?php echo $url.'&view=events&task=show&id='.$id; ?>'"><?php echo RSE_CANCEL_BTN;?></button>
		<input type="hidden" name="option" id="option" value="sendinvites" />
		<?php if ($data->EventType == 0) { ?>
		<input type="hidden" name="privateUrl" value="<?php echo $data->EventPrivateUrl; ?>" />
		<?php } ?>
		</form>
		</div>

<?php
		echo $layout[1];
	
	break;
	
}
?>
