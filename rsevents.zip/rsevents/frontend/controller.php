<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');

class RSEventsControllerFrontend {


/* Events */

function sendinvites()
{
	//get variables
	global $wpdb,$wp_query,$userdata,$RSEventsConfig;
	
	$request = $_REQUEST;
	
	$id = isset($request['id']) ? intval($request['id']) : 0;
	$uid = isset($userdata->ID) ? $userdata->ID : 0;
	$privateUrl = isset($request['privateUrl']) ? $request['privateUrl'] : '';
	if($privateUrl != '') $pUrl = '&privateUrl='.$privateUrl; else $pUrl='';
	$message = isset($request['rse_message']) ? wp_filter_post_kses($request['rse_message']) : '';
	$peoples = explode("\n",$request['emails']);
	
	$post = $wp_query->post;
	$post_id = $post->ID;
	$url= get_bloginfo('wpurl').'/index.php?page_id='.$post_id;	
	
	//send a mail to the people invited
	
	$eventDetails = $wpdb->get_row("SELECT e.EventName ,e.EventDescription ,e.EventStartDate , e.EventEndDate , e.EventHost , l.LocationName, l.LocationCity , l.LocationCountry ,l.LocationZip , u.user_login FROM ".$wpdb->prefix."rsevents_events e LEFT JOIN ".$wpdb->prefix."users u ON u.ID='".$uid."' LEFT JOIN ".$wpdb->prefix."rsevents_locations l ON e.IdLocation=l.IdLocation WHERE e.IdEvent='".$id."'");
	
	
	$eventLink = '<a target="_blank" href="'.$url.'&view=events&task=show&id='.$id.'">'.$eventDetails->EventName.'</a>';
	$toChange = array('{EventName}','{EventDescription}','{EventStartDate}','{EventEndDate}','{EventHost}','{LocationName}','{LocationCity}','{username}','{message}','{EventLink}','{LocationCountry}','{LocationZip}');
	$with = array($eventDetails->EventName , $eventDetails->EventDescription , RSEventsHelper::translateDate(date($RSEventsConfig['global.dateformat'],$eventDetails->EventStartDate)) , RSEventsHelper::translateDate(date($RSEventsConfig['global.dateformat'],$eventDetails->EventEndDate)), $eventDetails->EventHost,$eventDetails->LocationName,$eventDetails->LocationCity, $eventDetails->user_login,$message,$eventLink,$eventDetails->LocationCountry,$eventDetails->LocationZip);
	
	$from		= !empty($request['rse_from']) ? $request['rse_from'] : $RSEventsConfig['emails.from'];
	$fromName	= $RSEventsConfig['emails.from.name'];
	$subject	= $RSEventsConfig['emails.invite.subject'];
	$subject	= str_replace($toChange , $with ,$subject);
	$body		= $RSEventsConfig['emails.invite.content'];
	$body		= str_replace($toChange , $with ,$body);
	$mode		= $RSEventsConfig['emails.invite.type'];
	$replyto	= $RSEventsConfig['emails.reply'];			
	$cc			= !empty($RSEventsConfig['emails.cc']) ? $RSEventsConfig['emails.cc'] : null;
	$bcc		= !empty($RSEventsConfig['emails.bcc']) ? $RSEventsConfig['emails.bcc'] : null;
	
	foreach($peoples as $people)
	{
		$people = trim($people);
		if(!is_email($people)) continue;
		
		if($from!='')
		{
			$headers = '';
			$headers .= 'MIME-Version: 1.0' . "\r\n";
			if($mode == 1)
				$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
			else 
				$headers .= 'Content-type: text/plain; charset=UTF-8' . "\r\n";
			$headers .= 'From: '.$fromName.' <'.$from.'>' . "\r\n";
			$headers .= 'Reply-To: '.$replyto . "\r\n";
			if(!empty($cc)) $headers .= 'Cc: '.$cc . "\r\n";
			if(!empty($bcc)) $headers .= 'Bcc: '.$bcc. "\r\n";
			wp_mail($people,$subject,$body,$headers);
		}
	}
	
	RSEventsHelper::redirect($url.'&view=events&task=invite&id='.$id.$pUrl.'&message=50');
}
}

?>