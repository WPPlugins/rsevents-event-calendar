<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');

//get the id of the page and the site url
$post = $wp_query->post;
$post_id = $post->ID;
$url= get_bloginfo('wpurl').'/index.php?page_id='.$post_id;

if(isset($_GET['task']))
	$task = $_GET['task'];
elseif(isset($args['task']))
	$task = $args['task'];
else $task = 'list';

$option = isset($_POST['dotask']) ? $_POST['dotask'] : '';
if($option == 'saveLocation') RSEventsControllerFrontend::saveLocation();


switch($task)
{
	default:
	case 'list':
		
		echo '<h2>'.RSE_LOCATIONS.'</h2><br/>';
		$locations = RSEventsDataFrontend::getLocations();
		foreach($locations as $location)
		{
			echo '<a href="'.$url.'&view=events&task=listlocationevents&id='.$location->IdLocation.'">'.$location->LocationName.'</a><br/>';
			echo (empty($location->LocationDescription)) ? RSE_LOCATION_NO_DESCRIPTION.'<br/><br/>' : RSEventsHelper::strip_html_tags($location->LocationDescription).'<br/><br/>';
		}
		
	break;
	case 'show':

	$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
	$data = RSEventsDataFrontend::getLocation($id);
?>

<form action="" method="post" name="adminForm" id="adminForm">
	<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td valign="top">
				<table  class="adminform">
					<tr>
						<td>
							<label for="name">
								<?php echo RSE_LOCATION_NAME.':'; ?>
							</label>
						</td>
						<td>						
							<?php echo $data->LocationName; ?>
						</td>
					</tr>
					<tr>
						<td>
							<label for="weburl">
								<?php echo RSE_LOCATION_URL.':'; ?>
							</label>
						</td>
						<td>						
							<?php echo $data->LocationURL; ?>
						</td>
					</tr>
					<tr>
						<td>
							<label for="address">
								<?php echo RSE_LOCATION_ADDRESS.':'; ?>
							</label>
						</td>
						<td>						
							<?php echo $data->LocationAddress; ?>
						</td>
					</tr>
					<tr>
						<td>
							<label for="zip">
								<?php echo RSE_LOCATION_ZIP.':'; ?>
							</label>
						</td>
						<td>						
							<?php echo $data->LocationZip; ?>
						</td>
					</tr>
					<tr>
						<td>
							<label for="city">
								<?php echo RSE_LOCATION_CITY.':'; ?>
							</label>
						</td>
						<td>						
							<?php echo $data->LocationCity; ?>
						</td>
					</tr>
					<tr>
						<td>
							<label for="state">
								<?php echo RSE_LOCATION_STATE.':'; ?>
							</label>
						</td>
						<td>						
							<?php echo $data->LocationState; ?>
						</td>
					</tr>
					<tr>
						<td>
							<label for="country">
								<?php echo RSE_LOCATION_COUNTRY.':'; ?>
							</label>
						</td>
						<td>						
							<?php echo $data->LocationCountry; ?>
						</td>
					</tr>					
				</table>
			</td>
		</tr>
	</table>
	<p><?php echo $data->LocationDescription; ?></p>
</form>

<?php 
}
?>

