<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');
require_once(WP_PLUGIN_DIR.'/rsevents/frontend/calendarHelper.php');


//get the id of the page and the site url
$post = $wp_query->post;
$post_id = $post->ID;
$url= get_bloginfo('wpurl').'/index.php?page_id='.$post_id;

if(isset($_GET['task']))
	$task = $_GET['task'];
elseif(isset($args['task']))
	$task = $args['task'];
else $task = 'list';

switch($task)
{
	default:
	case '':
		$calendar = new RSEventsCalendar();
		$month = isset($_REQUEST['month']) ? $_REQUEST['month'] : '0';
		$year = isset($_REQUEST['year']) ? $_REQUEST['year'] : '0';
		$calendar->setDate($month, $year);
		$calendar->display();
	break; 
	
	case 'day':
		
		$date = isset($_REQUEST['date']) ? strtotime(urldecode($_REQUEST['date'])) : '';
		
		$eventsList = RSEventsDataFrontend::getEventDays($date,0);		
		$layouts = array();
		
		foreach($eventsList as $i => $objList)
		{
			$categoryname = array();
			$layout = $RSEventsConfig['layouts.eventintro'];
			
			// event link
			$eventLink = $url.'&view=events&task=show&id='.$objList->IdEvent;
			//location link
			$locationLink = $url.'&view=locations&task=show&id='.$objList->IdLocation;
			

			//get the icon of the event
			$small_icon = str_replace('.jpg','_'.$RSEventsConfig['event.icon.small'].'.jpg',$objList->EventIcon);
			if($RSEventsConfig['enable.event.icon'] && $objList->EventIcon != '')
				$eventIcon = '<div class="rsevents_icon"><a href="'.$eventLink.'"><img src="'.WP_PLUGIN_URL.'/rsevents/images/thumbs/'.$small_icon.'" /></a></div>';
			else 
				$eventIcon = '';
			
			$bad  = array('{EventLink}','{LocationLink}','{EventIcon}');
			$good = array($eventLink,$locationLink,$eventIcon);
			
			$layout = str_replace($bad,$good,$layout);
			$properties = array();
			$values = array();
			$objList->EventStartDate = RSEventsHelper::translateDate(date($RSEventsConfig['global.dateformat'],$objList->EventStartDate));
			$objList->EventEndDate = RSEventsHelper::translateDate(date($RSEventsConfig['global.dateformat'],$objList->EventEndDate));
			$objList->EventDescription = RSEventsHelper::strip_html_tags(RSEventsHelper::shorten($objList->EventDescription));
			
			foreach($objList as $property => $value)
			{
				$properties[] = '{'.$property.'}';
				$values[] = $value;
			}

			$layouts[] = str_replace($properties, $values, $layout);
		}
		
		if ($RSEventsConfig['events.layout'] == 2) { ?> 
		<table class="rsevents-table-list" cellspacing="0" cellpadding="0" width="100%">
			<thead>
				<tr>
					<th>
						<?php echo RSE_DATE; ?>
					</th>
					<th>
						<?php echo RSE_EVENTNAME; ?>
					</th>
					<th>
						<?php echo RSE_LOCATION_NAME1; ?>
					</th>
				</tr>
			</thead>
			<tbody>
		<?php
		} 
		if(!empty($layouts))
		foreach($layouts as $layout) echo $layout;
		else echo RSE_NO_EVENTS;	
		echo ($RSEventsConfig['events.layout'] == 2) ? "</tbody>\n</table>" : "";
		
	break;
	
	case 'week':		
		
		$date = isset($_REQUEST['date']) ? $_REQUEST['date'] : '';
		$startweek = strtotime($date);
		$endweek = $startweek+(6*86400);
		
		$eventsList = RSEventsDataFrontend::getEventDays($startweek,$endweek);
		
		$layouts = array();
		foreach($eventsList as $i => $objList)
		{
			$categoryname = array();
			
			$layout = $RSEventsConfig['layouts.eventintro'];
			// event link
			$eventLink = $url.'&view=events&task=show&id='.$objList->IdEvent;
			
			//location link
			$locationLink = $url.'&view=locations&task=show&id='.$objList->IdLocation;
			

			//get the icon of the event
			$small_icon = str_replace('.jpg','_'.$RSEventsConfig['event.icon.small'].'.jpg',$objList->EventIcon);
			if($RSEventsConfig['enable.event.icon'] && $objList->EventIcon != '')
				$eventIcon = '<div class="rsevents_icon"><a href="'.$eventLink.'"><img src="'.WP_PLUGIN_URL.'/rsevents/images/thumbs/'.$small_icon.'" /></a></div>';
			else 
				$eventIcon = '';
			
			
			$bad  = array('{EventLink}','{LocationLink}','{EventIcon}');
			$good = array($eventLink,$locationLink,$eventIcon);
			
			$layout = str_replace($bad,$good,$layout);
			$properties = array();
			$values = array();
			$objList->EventStartDate = RSEventsHelper::translateDate(date($RSEventsConfig['global.dateformat'],$objList->EventStartDate));
			$objList->EventEndDate = RSEventsHelper::translateDate(date($RSEventsConfig['global.dateformat'],$objList->EventEndDate));
			$objList->EventDescription = RSEventsHelper::strip_html_tags(RSEventsHelper::shorten($objList->EventDescription));
			
			foreach($objList as $property => $value)
			{
				$properties[] = '{'.$property.'}';
				$values[] = $value;
			}

			$layouts[] = str_replace($properties, $values, $layout);
			
		}	
			if ($RSEventsConfig['events.layout'] == 2) { ?> 
			<table class="rsevents-table-list" cellspacing="0" cellpadding="0" width="100%">
				<thead>
					<tr>
						<th>
							<?php echo RSE_DATE; ?>
						</th>
						<th>
							<?php echo RSE_EVENTNAME; ?>
						</th>
						<th>
							<?php echo RSE_LOCATION_NAME1; ?>
						</th>
					</tr>
				</thead>
				<tbody>
			<?php
			} 
			if(!empty($layouts))
			foreach($layouts as $layout) echo $layout;
			else echo RSE_NO_EVENTS;	
			echo ($RSEventsConfig['events.layout'] == 2) ? "</tbody>\n</table>" : "";
	
	break;
	
}
?>

