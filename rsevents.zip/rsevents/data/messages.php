<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');


class RSEMessages {
	
	function show($id)
	{
		global $RSEventsConfig;
		$id = intval($id);
		if(!isset($id) || empty($id)) return;
		
		switch($id)
		{
			case 1 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_PLACEHOLDER_MISSING.'</strong></p></div>';
			break;
			
			case 2 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_SETTINGS_SAVE.'</strong></p></div>';
			break;
			
			case 3 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_LOCATION_SAVE_ERROR.'</strong></p></div>';
			break;
			
			case 4 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_LOCATION_SAVE.'</strong></p></div>';
			break;
			
			case 5 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_LOCATION_DELETE.'</strong></p></div>';
			break;
			
			case 6 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_LOCATION_DELETE_ERROR.'</strong></p></div>';
			break;
			
			case 7 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_CATEGORY_SAVE.'</strong></p></div>';
			break;
			
			case 8 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_CATEGORY_SAVE_ERROR.'</strong></p></div>';
			break;
			
			case 9 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_CATEGORY_DELETE.'</strong></p></div>';
			break;
			
			case 10 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_CATEGORY_DELETE_ERROR.'</strong></p></div>';
			break;
			
			case 11 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_DESIGN_UNPUBLISH_ERROR.'</strong></p></div>';
			break;
			
			case 12 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_DESIGN_SAVED.'</strong></p></div>';
			break;
			
			case 13 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_DESIGN_SAVED_ERROR.'</strong></p></div>';
			break;
			
			case 14 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_DESIGN_DELETE.'</strong></p></div>';
			break;
			
			case 15 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_PLUGIN_DELETED.'</strong></p></div>';
			break;
			
			case 16 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_PLUGIN_SAVED.'</strong></p></div>';
			break;
			
			case 17 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_PLUGIN_SAVED_ERROR.'</strong></p></div>';
			break;
			
			case 18 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_GROUP_DELETE.'</strong></p></div>';
			break;
			
			case 19 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_GROUP_SAVE_ERROR.'</strong></p></div>';
			break;
			
			case 20 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_GROUP_SAVE.'</strong></p></div>';
			break;
			
			case 21 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_NO_GROUPS_AVAILABLE.'</strong></p></div>';
			break;
			
			case 22 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_EVENT_UNARCHIVED.'</strong></p></div>';
			break;
			
			case 23 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_EVENT_DELETE.'</strong></p></div>';
			break;
			
			case 24 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_SUBSCRIBER_SAVE_ERROR.'</strong></p></div>';
			break;
			
			case 25 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_SUBSCRIBER_SAVE.'</strong></p></div>';
			break;
			
			case 26 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_SUBSCRIBER_DELETE1.'</strong></p></div>';
			break;
			
			case 27 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_REPEAT_SAVE.'</strong></p></div>';
			break;
			
			case 28 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_FILE_DELETE.'</strong></p></div>';
			break;
			
			case 29 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_EXTRA_DELETE.'</strong></p></div>';
			break;
			
			case 30 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_INVALID_DATE.'</strong></p></div>';
			break;
			
			case 31 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_EVENT_INVALID_FILE.'</strong></p></div>';
			break;
			
			case 32 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_EVENT_SAVE.'</strong></p></div>';
			break;
			
			case 33 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_EVENT_DELETE.'</strong></p></div>';
			break;
			
			case 34 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_TICKET_CONTAINS_SUBSCRIBERS.'</strong></p></div>';
			break;
			
			case 35 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_TICKETS_DELETE1.'</strong></p></div>';
			break;
			
			case 36 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_TICKETS_ERR.'</strong></p></div>';
			break;
			
			case 37 :
				$return  = '<div class="updated fade" id="message"><p><strong>'.RSE_TICKETS_SAVE.'</strong></p></div>';
			break;

			/* FRONTEND MESSAGE */
			
			case 38 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_EVENT_INVALID.'</strong></p></div>';
			break;
			
			case 39 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_ACCESS_DENIED.'</strong></p></div>';
			break;
			
			case 40 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_SUBSCRIBER_UNSUBSCRIBE.'</strong></p></div>';
			break;
			
			case 41 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_SUBSCRIBER_LOGIN_UNSUBSCRIBE.'</strong></p></div>';
			break;
			
			case 42 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_SUBSCRIBER_NO_REGISTRATION.'</strong></p></div>';
			break;
			
			case 43 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_SUBSCRIBER_CANNOT_UNSUBSCRIBE.'</strong></p></div>';
			break;
			
			case 44 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_EVENT_DELETE.'</strong></p></div>';
			break;
			
			case 45 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_POST_REMINDER_SENT.'</strong></p></div>';
			break;
			
			case 46 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_REMINDER_SENT.'</strong></p></div>';
			break;
			
			case 47 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_PHOTOS_SAVED.'</strong></p></div>';
			break;
			
			case 48 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_PHOTOS_SAVED_ERROR.'</strong></p></div>';
			break;
			
			case 49 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_EXTRA_FLICKR_INVALID_URL.'</strong></p></div>';
			break;
			
			case 50 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_INVITE_SENT.'</strong></p></div>';
			break;
			
			case 51 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_MESSAGE_SENT.'</strong></p></div>';
			break;
			
			case 52 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_MESSAGE_RECIEVER_ERROR.'</strong></p></div>';
			break;
			
			case 53 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.$RSEventsConfig['event.full.booking'].'</strong></p></div>';
			break;
			
			case 54 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_EVENT_NO_TICKETS.'</strong></p></div>';
			break;
			
			case 55 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_EVENT_ALLREADY_REGISTERED.'</strong></p></div>';
			break;
			
			case 56 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_SUBSCRIBER_NAME_EMAIL_ERROR.'</strong></p></div>';
			break;
			
			case 57 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_SUBSCRIBER_ALLREADY_REGISTERED.'</strong></p></div>';
			break;
			
			case 58 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_SUBSCRIBER_SUCCESS.'</strong></p></div>';
			break;
			
			case 59 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_INVALID_DATE.'</strong></p></div>';
			break;
			
			case 60 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_FILE_INVALID.'</strong></p></div>';
			break;
			
			case 61 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_FILE_CANNOT_UPLOAD.'</strong></p></div>';
			break;
			
			case 62 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_TICKETS_DELETE1.'</strong></p></div>';
			break;
			
			case 63 :
				$return  = '<div id="message" style="padding-left:15px;padding-right:15px;border:1px solid red"><p><strong>'.RSE_TICKET_CONTAINS_SUBSCRIBERS.'</strong></p></div>';
			break;
			
		}
		
		return $return;
	}
	
}

?>