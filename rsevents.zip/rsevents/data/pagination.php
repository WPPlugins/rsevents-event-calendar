<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

 defined('_RSWP') or die('<h1>Permission denied!</h1>');

class RSPagination {

	/**
	 * The record number to start dislpaying from
	 *
	 * @access public
	 * @var int
	 */
	var $limitstart = null;

	/**
	 * Number of rows to display per page
	 *
	 * @access public
	 * @var int
	 */
	var $limit = null;

	/**
	 * Total number of rows
	 *
	 * @access public
	 * @var int
	 */
	var $total = null;
	
	/**
	 * Total pages
	 *
	 * @access public
	 * @var int
	 */
	var $total_pages = null;
	
	/**
	 * Current page
	 *
	 * @access public
	 * @var int
	 */
	var $current_page = null;
	
	/**
	 * Start page
	 *
	 * @access public
	 * @var int
	 */
	var $start_page = null;
	
	/**
	 * Stop page
	 *
	 * @access public
	 * @var int
	 */
	var $stop_page = null;
	
	/**
	 * View all flag
	 *
	 * @access protected
	 * @var boolean
	 */
	var $_viewall = false;

	
	function __construct($total, $limitstart, $limit)
	{
		// Value/Type checking
		$this->total		= (int) $total;
		$this->limitstart	= (int) max($limitstart, 0);
		$this->limit		= (int) max($limit, 0);

		if ($this->limit > $this->total) {
			$this->limitstart = 0;
		}

		if (!$this->limit)
		{
			$this->limit = $total;
			$this->limitstart = 0;
		}

		if ($this->limitstart > $this->total) {
			$this->limitstart -= $this->limitstart % $this->limit;
		}
		
		// Set the total pages and current page values
		if($this->limit > 0)
		{
			$this->total_pages = ceil($this->total / $this->limit);
			$this->current_page = ceil(($this->limitstart + 1) / $this->limit);
		}
		
		$displayedPages	= 10;
		$this->start_page = (floor(($this->current_page -1) / $displayedPages)) * $displayedPages +1;
		
		if ($this->start_page + $displayedPages -1 < $this->total_pages) {
			$this->stop_page = $this->start_page + $displayedPages -1;
		} else {
			$this->stop_page = $this->total_pages;
		}
		
		
		// If we are viewing all records set the view all flag to true
		if ($this->limit == $total) {
			$this->_viewall = true;
		}
		
	}
	
	
	function pagination_list_render($list)
	{
		// Initialize variables
		$html = null;

		if ($list['start']['active']) {
			$html .= "<div class=\"button2-right\"><div class=\"start\">".$list['start']['data']."</div></div>";
		} else {
			$html .= "<div class=\"button2-right off\"><div class=\"start\">".$list['start']['data']."</div></div>";
		}
		if ($list['previous']['active']) {
			$html .= "<div class=\"button2-right\"><div class=\"prev\">".$list['previous']['data']."</div></div>";
		} else {
			$html .= "<div class=\"button2-right off\"><div class=\"prev\">".$list['previous']['data']."</div></div>";
		}

		$html .= "\n<div class=\"button2-left\"><div class=\"page\">";
		foreach( $list['pages'] as $page ) {
			$html .= $page['data'];
		}
		$html .= "\n</div></div>";

		if ($list['next']['active']) {
			$html .= "<div class=\"button2-left\"><div class=\"next\">".$list['next']['data']."</div></div>";
		} else {
			$html .= "<div class=\"button2-left off\"><div class=\"next\">".$list['next']['data']."</div></div>";
		}
		if ($list['end']['active']) {
			$html .= "<div class=\"button2-left\"><div class=\"end\">".$list['end']['data']."</div></div>";
		} else {
			$html .= "<div class=\"button2-left off\"><div class=\"end\">".$list['end']['data']."</div></div>";
		}

		return $html;
	}

	function pagination_item_active(&$item)
	{
		if(is_admin())
		{
			if($item->base>0)
				return "<a href=\"#\" title=\"".$item->text."\" onclick=\"javascript: document.adminForm.limitstart.value=".$item->base."; document.adminForm.submit();return false;\">".$item->text."</a>";
			else
				return "<a href=\"#\" title=\"".$item->text."\" onclick=\"javascript: document.adminForm.limitstart.value=0; document.adminForm.submit();return false;\">".$item->text."</a>";
		
		} else return "<a href=\"".$item->link."\" title=\"".$item->text."\">".$item->text."</a>";
	} 

	function pagination_item_inactive(&$item)
	{
		return "<span>".$item->text."</span>";
	}
	
	function pagination_list_footer($list)
	{
		// Initialize variables
		$html = "<del class=\"rsj_container\"><div class=\"rsj_pagination\">\n";

		$html .= "\n<div class=\"limit\">".$list['limitfield']."</div>";
		$html .= $list['pageslinks'];
		$html .= "\n<div class=\"limit\">".$list['pagescounter']."</div>";

		$html .= "\n<input type=\"hidden\" name=\"limitstart\" value=\"".$list['limitstart']."\" />";
		$html .= "\n</div></del>";

		return $html;
	}
	
	function getTotalPages()
	{
		// Initialize variables
		$html = null;
		if ($this->total_pages > 1) {
			$html .= 'Page '.$this->current_page.' of '.$this->total_pages;
		}
		return $html;
	}
	
	function getLimitBox()
	{
		
		$html = 'Display # <select id="limit" onchange="document.adminForm.submit();" name="limit">';

		$selected = $this->_viewall ? 0 : $this->limit;
		
		// Make the option list
		for ($i = 5; $i <= 30; $i += 5)
		{
			$sel = ($selected == $i) ? 'selected="selected"' : '';
			$html .= '<option '.$sel.' value="'.$i.'">'.$i.'</option>';
		}
		
		$sel1 = ($selected == 50) ? 'selected="selected"' : '';
		$sel2 = ($selected == 100) ? 'selected="selected"' : '';
		$sel3 = ($selected == 0) ? 'selected="selected"' : '';
		
		$html .= '<option '.$sel1.' value="50">50</option>';
		$html .= '<option '.$sel2.' value="100">100</option>';
		$html .= '<option '.$sel3.' value="0">All</option>';
		

		$html .= '</select>';
		
		return $html;
	
	}
	
	function getPagesLinks()
	{
		// Build the page navigation list
		$data = $this->_buildDataObject();

		$list = array();
		
		// Build the select list
		if ($data->all->base !== null) {
			$list['all']['active'] = true;
			$list['all']['data'] = $this->pagination_item_active($data->all);
		} else {
			$list['all']['active'] = false;
			$list['all']['data'] = $this->pagination_item_inactive($data->all);
		}

		if ($data->start->base !== null) {
			$list['start']['active'] = true;
			$list['start']['data'] = $this->pagination_item_active($data->start);
		} else {
			$list['start']['active'] = false;
			$list['start']['data'] = $this->pagination_item_inactive($data->start);
		}
		if ($data->previous->base !== null) {
			$list['previous']['active'] = true;
			$list['previous']['data'] = $this->pagination_item_active($data->previous);
		} else {
			$list['previous']['active'] = false;
			$list['previous']['data'] = $this->pagination_item_inactive($data->previous);
		}

		$list['pages'] = array(); //make sure it exists
		foreach ($data->pages as $i => $page)
		{
			if ($page->base !== null) {
				$list['pages'][$i]['active'] = true;
				$list['pages'][$i]['data'] = $this->pagination_item_active($page);
			} else {
				$list['pages'][$i]['active'] = false;
				$list['pages'][$i]['data'] = $this->pagination_item_inactive($page);
			}
		}

		if ($data->next->base !== null) {
			$list['next']['active'] = true;
			$list['next']['data'] = $this->pagination_item_active($data->next);
		} else {
			$list['next']['active'] = false;
			$list['next']['data'] = $this->pagination_item_inactive($data->next);
		}
		if ($data->end->base !== null) {
			$list['end']['active'] = true;
			$list['end']['data'] = $this->pagination_item_active($data->end);
		} else {
			$list['end']['active'] = false;
			$list['end']['data'] = $this->pagination_item_inactive($data->end);
		}

		if($this->total > $this->limit){
			return is_admin() ? $this->pagination_list_render($list) : $this->_list_render($list);
		}
		else{
			return '';
		}
	}
	
	function _list_render($list)
	{
		// Initialize variables
		$html = null;

		// Reverse output rendering for right-to-left display
		$html .= '&lt;&lt; ';
		$html .= $list['start']['data'];
		$html .= ' &lt; ';
		$html .= $list['previous']['data'];
		foreach( $list['pages'] as $page ) {
			$html .= ' '.$page['data'];
		}
		$html .= ' '. $list['next']['data'];
		$html .= ' &gt;';
		$html .= ' '. $list['end']['data'];
		$html .= ' &gt;&gt;';

		return $html;
	}
	
	function getPagination()
	{
		global $mainframe;

		$list = array();
		$list['limit']			= $this->limit;
		$list['limitstart']		= $this->limitstart;
		$list['total']			= $this->total;
		$list['limitfield']		= $this->getLimitBox();
		$list['pagescounter']	= $this->getTotalPages();
		$list['pageslinks']		= $this->getPagesLinks();

		return $this->pagination_list_footer( $list );
	}
	
	function getPaginationFrontend()
	{
		global $mainframe;

		$list = array();
		$list['limit']			= $this->limit;
		$list['limitstart']		= $this->limitstart;
		$list['total']			= $this->total;
		$list['limitfield']		= '';
		$list['pagescounter']	= $this->getTotalPages();
		$list['pageslinks']		= $this->getPagesLinks();

		return $this->pagination_list_footer( $list );
	}
	
	
	function _buildDataObject()
	{
		// Initialize variables
		$data = new stdClass();

		$data->all	= new RSPagination_Helper('View All');
		if (!$this->_viewall) {
			$data->all->base	= '0';
			//$data->all->link	= "&limitstart=";
			$data->all->link	= add_query_arg('limitstart','');
		}

		// Set the start and previous data objects
		$data->start	= new RSPagination_Helper('Start');
		$data->previous	= new RSPagination_Helper('Prev');

		if ($this->current_page > 1)
		{
			$page = ($this->current_page -2) * $this->limit;

			$page = $page == 0 ? '' : $page; //set the empty for removal from route

			$data->start->base	= '0';
			//$data->start->link	= "&limitstart=";
			$data->start->link	= add_query_arg('limitstart','');
			$data->previous->base	= $page;
			//$data->previous->link	= "&limitstart=".$page;
			$data->previous->link	= add_query_arg('limitstart',$page);
		}

		// Set the next and end data objects
		$data->next	= new RSPagination_Helper('Next');
		$data->end	= new RSPagination_Helper('End');

		if ($this->current_page < $this->total_pages)
		{
			$next = $this->current_page * $this->limit;
			$end  = ($this->total_pages -1) * $this->limit;

			$data->next->base	= $next;
			//$data->next->link	= "&limitstart=".$next;
			$data->next->link	= add_query_arg('limitstart',$next);
			$data->end->base	= $end;
			//$data->end->link	= "&limitstart=".$end;
			$data->end->link	= add_query_arg('limitstart',$end);
		}

		$data->pages = array();
		$stop = $this->stop_page;
		for ($i = $this->start_page; $i <= $stop; $i ++)
		{
			$offset = ($i -1) * $this->limit;

			$offset = $offset == 0 ? '' : $offset;  //set the empty for removal from route

			$data->pages[$i] = new RSPagination_Helper($i);
			if ($i != $this->current_page || $this->_viewall)
			{
				$data->pages[$i]->base	= $offset;
				//$data->pages[$i]->link	= "&limitstart=".$offset;
				$data->pages[$i]->link	= add_query_arg('limitstart',$offset);
			}
		}
		return $data;
	}

}


//helper class
class RSPagination_Helper
{
	var $text;
	var $base;
	var $link;

	function __construct($text, $base=null, $link=null)
	{
		$this->text = $text;
		$this->base = $base;
		$this->link = $link;
	}
}

?>