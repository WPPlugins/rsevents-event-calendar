<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');


class RSEventsDataEvents {

	function getData()
	{
		global $wpdb;
		$filter = isset($_POST['rs_filter']) ? $_POST['rs_filter'] : '';
		$loc_filter = isset($_POST['loc_filter']) ? $_POST['loc_filter'] : '';
		$limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;
		$limitstart = isset($_POST['limitstart']) ? intval($_POST['limitstart']) : 0;
		$setlimit = ($limit == 0 && $limitstart == 0 ) ? "" :" LIMIT ".$limitstart." , ".$limit." ";
		
		$lfilter = !empty($loc_filter) ? " AND l.LocationName = ".intval($loc_filter)." " : '';
		
		$results = $wpdb->get_results("SELECT e.IdEvent, e.EventName , e.IdLocation , e.EventStartDate , e.EventEndDate, e.IdUser , e.IdParent , e.published , l.LocationName , u.user_login FROM ".$wpdb->prefix."rsevents_events e LEFT JOIN ".$wpdb->prefix."rsevents_locations l ON e.IdLocation = l.IdLocation LEFT JOIN ".$wpdb->prefix."users u ON e.IdUser = u.ID WHERE e.EventName LIKE '%".$wpdb->escape($filter)."%' AND e.published IN ('0','1') ".$lfilter." GROUP BY e.IdEvent ORDER BY e.EventStartDate DESC ".$setlimit);
		
		return $results;
	}
	
	function getTotal()
	{
		global $wpdb;
	
		$return = $wpdb->get_var("SELECT COUNT(IdEvent) as nr FROM ".$wpdb->prefix."rsevents_events ");
		return $return;
	}
	
	function getRepeat()
	{
		global $wpdb;
		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		
		if($id == 0) RSEventsHelper::redirect('admin.php?page=rse_events');
		
		$return = $wpdb->get_row("SELECT EventEnableRepeat,EventRepeatType,EventRepeatNumber,EventRepeatUntil,EventRepeatAlso FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent =".$id);
		
		if(empty($return))
		{
			$return = new stdClass();
			$return->EventEnableRepeat = 0;
			$return->EventRepeatType = 0;
			$return->EventRepeatNumber = 0;
		}
		
		return $return;
	}
	
	function getEvent()
	{
		global $wpdb,$RSEventsConfig;
		
		$id= isset($_GET['id']) ? $_GET['id'] : 0;
		
		
		$return = $wpdb->get_row("SELECT IdLocation , IdUser, EventName, EventSubtitle, EventHost, EventURL, EventPhone, EventEmail, EventDescription, EventType, EventStartDate, EventEndDate, EventPostReminder, published, EventPrivateUrl, EventArchive, EventIcon, EventAmPm1 ,EventAmPm2 FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent =".$id);
		
		if(!empty($return))
		{
			if($RSEventsConfig['enable.12format'] == 1)
					$return->EventStartDateH = date('g',$return->EventStartDate);
				else
					$return->EventStartDateH = date('H',$return->EventStartDate);
				$return->EventStartDateM = date('i',$return->EventStartDate);
			
			if($RSEventsConfig['enable.12format'] == 1)
					$return->EventEndDateH = date('g',$return->EventEndDate);
				else
					$return->EventEndDateH = date('H',$return->EventEndDate);
				$return->EventEndDateM = date('i',$return->EventEndDate);
		}
		
		if(empty($return))
		{
			$return = new stdClass();
			$return->EventName  = '';
			$return->EventSubtitle  = '';
			$return->EventHost  = '';
			$return->EventPhone  = '';
			$return->EventEmail  = '';
			$return->IdLocation  = 0;
			$return->IdUser  = 0;
			$return->EventDescription  = '';
			$return->EventType  = 1;
			$return->EventPostReminder  = 0;
			$return->published  = 1;
			$return->EventPrivateUrl  = '';
			$return->EventArchive  = '';
			$return->EventIcon  = '';
			$return->EventAmPm1  = 0;
			$return->EventAmPm2  = 1;
			
			$return->EventStartDate  = time();
			$return->EventEndDate  = time();
			
			if($RSEventsConfig['enable.12format'] == 1)
			{
				$return->EventStartDateH  = '11';
				$return->EventStartDateM  = '00';
				$return->EventEndDateH  = '12';
				$return->EventEndDateM  = '00';
			} else 
			{
				$return->EventStartDateH  = '20';
				$return->EventStartDateM  = '00';
				$return->EventEndDateH  = '22';
				$return->EventEndDateM  = '00';
			}	
			
			$return->EventURL = 'http://';
			
		}	
		
		return $return;
	}
	
	function getFiles()
	{
		global $wpdb;
		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		
		$return = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."rsevents_files WHERE IdEvent =".$id);
		return $return;
	}
	
	function getFile($id)
	{
		global $wpdb;
		
		$return = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."rsevents_files WHERE IdFile =".$id);
		
		return $return;
	}
	
	function checkDB()
	{
		global $wpdb;
		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		
		if($id == 0) return;
		
		$res = $wpdb->query("SELECT IdEvent FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent = ".$id);
		if($res == 0) RSEventsHelper::redirect('admin.php?page=rse_events'); else return;
	}
	
	function headers()
	{
		$id = isset($_GET['id']) ? intval($_GET['id']) : 'event' ;
		$subpage = isset($_GET['subpage']) ? $_GET['subpage'] : 'event' ;
		
		$event = ($subpage == 'event') ? 'class="current"' : '';
		$description = ($subpage == 'description') ? 'class="current"' : '';
		$registration = ($subpage == 'registration') ? 'class="current"' : '';
		$files = ($subpage == 'files') ? 'class="current"' : '';
		$extra = ($subpage == 'extra') ? 'class="current"' : '';
		
		echo '<ul class="subsubsub">';
		echo '<li><a '.$event.' href="admin.php?page=rse_events&task=edit&subpage=event&id='.$id.'">'.RSE_EVENT_TAB_INFO.'</a> <strong>|</strong></li>';
		echo '<li><a '.$description.' href="admin.php?page=rse_events&task=edit&subpage=description&id='.$id.'">'.RSE_EVENT_TAB_DESCRIPTION.'</a> <strong>|</strong></li>';
		echo '<li><a '.$files.' href="admin.php?page=rse_events&task=edit&subpage=files&id='.$id.'">'.RSE_EVENT_TAB_FILES.'</a></li>';
		echo '</ul>';
	}
}

?>