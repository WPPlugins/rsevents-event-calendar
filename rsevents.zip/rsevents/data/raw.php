<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

/** Load WordPress Bootstrap */
chdir('../../../../');
require_once('wp-config.php');
global $wpdb,$userdata;

$task = isset($_GET['task']) ? $_GET['task'] : '';
?>

<?php switch($task) {
	default: 
		echo 'Please specify a certain task!'; 
	break; 

	case 'addoutlook':
		
	$id = isset($_REQUEST['id']) ? $_REQUEST['id'] : 0;
	$event = $wpdb->get_row("SELECT EventName , EventStartDate ,EventEndDate,EventDescription,IdLocation FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent = ".$id);
	$location = $wpdb->get_row("SELECT LocationName, LocationCity , LocationAddress FROM ".$wpdb->prefix."rsevents_locations WHERE IdLocation='".$event->IdLocation."'");
	
	$Filename = 'Event-'.$id.'.vcs';
	header("Content-Type: text/x-vCalendar");
	header("Content-Disposition: inline; filename=$Filename");

		$vCalStart = gmdate("Ymd\THis\Z", $event->EventStartDate);
		$vCalEnd = gmdate("Ymd\THis\Z", $event->EventEndDate);
		$event->EventDescription = str_replace(array("\r","\n"),'',strip_tags($event->EventDescription));
echo'
BEGIN:VCALENDAR
VERSION:1.0
BEGIN:VEVENT
SUMMARY:'.$event->EventName.'
DESCRIPTION;ENCODING=QUOTED-PRINTABLE:'.$event->EventDescription.'
LOCATION:'.$location->LocationCity.' - '.$location->LocationName.' - '.$location->LocationAddress.'
DTSTART:'.$vCalStart.'
DTEND:'.$vCalEnd.'
END:VEVENT
END:VCALENDAR
';
	exit();

	break;
	
	case 'exportguests':
	
		$id = isset($_REQUEST['id']) ? $_REQUEST['id'] : 0;
		$usertype = !empty($userdata->wp_capabilities) ? key($userdata->wp_capabilities) : '';
		$uid = !empty($userdata->ID) ? $userdata->ID : 0;
		$iduser = $wpdb->get_var("SELECT IdUser FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent = ".$id);
		
		if($usertype == 'administrator' || $uid == $iduser)
		{
			$results = $wpdb->get_results("SELECT FirstName , LastName , Email FROM ".$wpdb->prefix."rsevents_subscriptions WHERE IdEvent=".$id);
			
			$filename = 'Event'.$id.'.csv';
			header("Content-type: application/octet-stream");
			header("Content-Disposition: attachment; filename=$filename");
			$csv ="First Name,Last Name,E-mail \n";
			if(!empty($results))
			foreach($results as $objCsv)
			{
				$csv .= $objCsv->FirstName.",".$objCsv->LastName.",".$objCsv->Email."\n";
			}
			echo $csv;
			exit();
		} else die(RSE_ACCESS_DENIED);
	
	break;
	
	case 'printevent':
	
	require_once(WP_PLUGIN_DIR.'/rsevents/data/helper.php');
	
	$id = isset($_REQUEST['id']) ? $_REQUEST['id'] : 0;
	$event = $wpdb->get_row("SELECT e.EventName, e.EventHost, e.IdUser, e.EventStartDate, e.EventEndDate, e.EventDescription, e.IdLocation, u.user_login FROM ".$wpdb->prefix."rsevents_events e LEFT JOIN ".$wpdb->prefix."users u ON e.IdUser = u.ID WHERE e.IdEvent =".$id);
	$location = $wpdb->get_row("SELECT LocationName,LocationAddress FROM ".$wpdb->prefix."rsevents_locations WHERE IdLocation =".$event->IdLocation);
	$date = $wpdb->get_var("SELECT ConfigValue FROM ".$wpdb->prefix."rsevents_config WHERE ConfigName = 'global.dateformat'");
?>
		<div style="text-align:right;">
		<a href="#" onclick="window.print();return false;" ><img src="<?php echo WP_PLUGIN_URL.'/rsevents/images/icons/print.png'; ?>" alt="<?php echo RSE_MENU_EVENT_PRINT; ?>" /></a>
		<a href="#" onclick="window.close();" ><img src="<?php echo WP_PLUGIN_URL.'/rsevents/images/icons/close.png'; ?>" alt="Close" /></a>
		</div>
		<h1><?php echo $event->EventName ?></h1>

		<table cellspacing="0" width="100%">
			<tr>
				<td><strong><?php echo RSE_EVENT_HOSTER.':';?> </strong> </td>
				<td width="75%"><?php echo $event->EventHost; ?> </td>
			</tr>
			<tr>
				<td><strong><?php echo RSE_EVENT_OWNER;?> </strong> </td>
				<td width="75%"><?php echo $event->user_login; ?></td>
			</tr>
			<tr>
				<td><strong><?php echo RSE_EVENT_STARTS_MESSAGE;?> </strong></td>
				<td width="75%"><?php echo RSEventsHelper::translateDate(date($date,$event->EventStartDate)) ; ?></td>
			</tr>
			<tr>
				<td><strong><?php echo RSE_EVENT_ENDS_MESSAGE;?> </strong> </td>
				<td width="75%"><?php echo RSEventsHelper::translateDate(date($date,$event->EventEndDate)); ?> </td>
			</tr>
			<tr>
				<td><strong><?php echo RSE_EVENT_LOCATION.':';?> </strong> </td>
				<td width="75%"><?php echo $location->LocationName.' - '.$location->LocationAddress; ?> </td>
			</tr>
			<tr>
				<td><strong><?php echo RSE_EVENT_DESCRIPTION;?> </strong> </td>
				<td width="75%"><?php echo $event->EventDescription ;?> </td>
			</tr>
		</table>

<?php
	break;
	
	
	case 'importyahoo':
		
		if(!extension_loaded('curl')) die('No cURL library loaded');
		
		require_once(WP_PLUGIN_DIR.'/rsevents/data/yahoo.class.php');
		
		$details = isset($_POST['string']) ? $_POST['string'] : '';
		if(empty($details)) die('No id or pass');
		
		$details = base64_decode($details);
		$details = explode('+',$details);
		
		$user = $details[0];
		$pass = $details[1];
		
		$contacts = rse_yahoo::import($user,$pass);
		if(empty($contacts))
		{
			echo RSE_CANNOT_CONNECT;
			echo '<br/><button type="button" onclick="document.location.reload();">'.RSE_BACK.'</button>';
			die();
		}
		
		echo $contacts;
		
	break;
	
	case 'importgmail':
	
		if(!extension_loaded('curl')) die('No cURL library loaded');
		
		require_once(WP_PLUGIN_DIR.'/rsevents/data/gmail.class.php');
		
		$details = isset($_POST['string']) ? $_POST['string'] : '';
		if(empty($details)) die('No id or pass');
		
		$details = base64_decode($details);
		$details = explode('+',$details);
		
		$user = $details[0];
		$pass = $details[1];
		
		$contacts = g_import($user,$pass);
		
		echo $contacts;
	
	break;
	
	case 'refreshlocations':
	
		$locations = $wpdb->get_results("SELECT IdLocation, LocationName FROM ".$wpdb->prefix."rsevents_locations WHERE published = 1 ORDER BY LocationName ASC");
		$loc_str = array();
		if(!empty($locations))
			foreach($locations as $locationObj)
				$loc_str[] = $locationObj->IdLocation.'|'.$locationObj->LocationName;
		echo implode("\n",$loc_str);
		exit();
	
	break;
	
	case 'calendar':
	
		if(file_exists(WP_PLUGIN_DIR.'/rsevents/frontend/calendarHelper.php'))
		{
			require_once(WP_PLUGIN_DIR.'/rsevents/frontend/data.php');
			require_once(WP_PLUGIN_DIR.'/rsevents/frontend/calendarHelper.php');
			
			$startday = isset($_GET['startday']) ? $_GET['startday'] : 1;
			$month = isset($_GET['month']) ? $_GET['month'] : '';
			$year  = isset($_GET['year']) ? $_GET['year'] : '';
			
			$calendar = new RSEventsCalendar;
			$calendar->is_module = true;
			$calendar->setWeekStart($startday);
			$calendar->setDate($month, $year);
			
			echo $calendar->display();
			
		}
	
	break;
	
?>

<?php } ?>