<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');


class RSEventsDataSettings {

	function subpage()
	{
		$subpage = isset($_GET['subpage']) ? $_GET['subpage'] : 'general' ;
		
		$general = ($subpage == 'general') ? 'class="current"' : '';
		$events = ($subpage == 'events') ? 'class="current"' : '';
		$emails = ($subpage == 'emails') ? 'class="current"' : '';
		
		echo '<ul class="subsubsub">';
		echo '<li><a '.$general.' href="admin.php?page=rse_settings&subpage=general">'.RSE_NAVIGATION_GENERAL.'</a> <strong>|</strong></li>';
		echo '<li><a '.$events.' href="admin.php?page=rse_settings&subpage=events">'.RSE_NAVIGATION_EVENTS.'</a> <strong>|</strong></li>';
		echo '<li><a '.$emails.' href="admin.php?page=rse_settings&subpage=emails">'.RSE_NAVIGATION_EMAILS.'</a></li>';	
		echo '</ul>';
	}	
}

?>