<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');


class RSEventsHelper {
	
	//Create the submit buttons: new/edit | editticket | duplicate | archive | unarchive | apply | save | applyticket | savetickets | publish | unpublish | adddesign | addplugin | default | delete | deletetickets | cancel | cancelticket | savep
	function makeButtons($args,$url = null)
	{
		$return = '';
		if(!is_array($args)) return;
		
		$return .= '<div style="text-align:right">';
		
		if(in_array('addedit',$args))
			$return .= '<input type="button" value="'.RSE_ADD_EDIT_BTN.'" name="edit" onclick="rswp_set_option(\'edit\');" class="button-primary"/>';
		if(in_array('editticket',$args))
			$return .= '<input type="button" value="'.RSE_ADD_EDIT_BTN.'" name="editticket" onclick="rswp_set_option(\'editticket\');" class="button-primary"/>';
		if(in_array('duplicate',$args))
			$return .= '<input type="button" value="'.RSE_DUPLICATE_BTN.'" name="duplicate" onclick="rswp_set_option(\'duplicate\',1);" class="button-primary"/>';
		if(in_array('archive',$args))
			$return .= '<input type="button" value="'.RSE_ARCHIVE_BTN.'" name="archive" onclick="rswp_set_option(\'archive\',1);" class="button-primary"/>';
		if(in_array('unarchive',$args))
			$return .= '<input type="button" value="'.RSE_UNARCHIVE_BTN.'" name="unarchive" onclick="rswp_set_option(\'unarchive\',1);" class="button-primary"/>';
		if(in_array('apply',$args))
			$return .= '<input type="button" value="'.RSE_APPLY_BTN.'" name="apply" onclick="rswp_set_option(\'apply\');" class="button-primary"/>';
		if(in_array('applyticket',$args))
			$return .= '<input type="button" value="'.RSE_APPLY_BTN.'" name="applyticket" onclick="rswp_set_option(\'applyticket\');" class="button-primary"/>';
		if(in_array('save',$args))
			$return .= '<input type="button" value="'.RSE_SAVE_BTN.'" name="save" onclick="rswp_set_option(\'save\');" class="button-primary"/>';
		if(in_array('savep',$args))
			$return .= '<input type="button" value="'.RSE_SAVE_BTN.'" name="save" onclick="rswp_submitform();" class="button-primary"/>';
		if(in_array('savetickets',$args))
			$return .= '<input type="button" value="'.RSE_SAVE_BTN.'" name="savetickets" onclick="rswp_set_option(\'savetickets\');" class="button-primary"/>';
		if(in_array('publish',$args))
			$return .= '<input type="button" value="'.RSE_PUBLISH_BTN.'" name="publish" onclick="rswp_set_option(\'publish\',1);" class="button-primary"/>';
		if(in_array('unpublish',$args))
			$return .= '<input type="button" value="'.RSE_UNPUBLISH_BTN.'" name="unpublish" onclick="rswp_set_option(\'unpublish\',1);" class="button-primary"/>';
		if(in_array('adddesign',$args))
			$return .= '<input type="button" value="'.RSE_ADD_NEW_BTN.'" name="adddesign" onclick="rswp_set_option(\'adddesign\');" class="button-primary"/>';
		if(in_array('addplugin',$args))
			$return .= '<input type="button" value="'.RSE_ADD_NEW_BTN.'" name="addplugin" onclick="rswp_set_option(\'addplugin\');" class="button-primary"/>';
		if(in_array('default',$args))
			$return .= '<input type="button" value="'.RSE_DEFAULT_BTN.'" name="default" onclick="rswp_set_option(\'default\',1);" class="button-primary"/>';
		if(in_array('delete',$args))
			$return .= '<input type="button" value="'.RSE_DELETE_BTN.'" name="delete" onclick="rswp_set_option(\'delete\',1);" class="button-primary"/>';
		if(in_array('deletetickets',$args))
			$return .= '<input type="button" value="'.RSE_DELETE_BTN.'" name="deletetickets" onclick="rswp_set_option(\'deletetickets\',1);" class="button-primary"/>';
		if(in_array('cancelticket',$args))
			$return .= '<input type="button" value="'.RSE_CANCEL_BTN.'" name="cancelticket" onclick="rswp_set_option(\'cancelticket\');" class="button-primary"/>';
		if(in_array('cancel',$args))
			$return .= '<input type="button" value="'.RSE_CANCEL_BTN.'" name="cancel" onclick="rswp_set_option(\'cancel\',\''.$url.'\');" class="button-primary"/>';
		
		$return .= '</div>';
		
		return $return;
	}
	
	function redirect($url)
	{
		if (headers_sent())
			echo "<script>document.location.href='".esc_js($url)."';</script>\n";
		else wp_redirect($url);
	}
	
	function isPublished($table,$key,$id)
	{
		global $wpdb;
		$id = intval($id);
		
		$value = $wpdb->get_row("SELECT published FROM ".$table." WHERE ".$key." = ".$id);
		
		if($value->published == 1)
			$return = '<a href="javascript:void(0);" onclick="rswp_publish('.$id.',\'unpublish\');"><img src="'.WP_PLUGIN_URL.'/rsevents/images/icons/tick.png" /></a>';
		if($value->published == 0)
			$return = '<a href="javascript:void(0);" onclick="rswp_publish('.$id.',\'publish\');"><img src="'.WP_PLUGIN_URL.'/rsevents/images/icons/delete.png" /></a>';
		
		return $return;
	}
	
	function delTree($dir) 
	{
		if (!file_exists($dir)) return true;
		if (!is_dir($dir) || is_link($dir)) return @unlink($dir);
			foreach (scandir($dir) as $item) {
				if ($item == '.' || $item == '..') continue;
				if (!RSEventsHelper::delTree($dir . "/" . $item)) {
					chmod($dir . "/" . $item, 0777);
					if (!RSEventsHelper::delTree($dir . "/" . $item)) return false;
				};
			}
			return @rmdir($dir);
    } 
	
	function createThumbs( $file, $pathToThumbs, $thumbWidth , $IdEvent , $uniqid)
	{
		global $wpdb;
		
		$info = pathinfo($file['name']);
		$fname = $file['tmp_name'];
		
		$nameOfFile = $uniqid.'_'.$file['name'];
		// continue only if this is a JPEG image
		if($file['name'] != '')
		if ( strtolower($info['extension']) == 'jpg' )
		{
			// load image and get image size
			$img = imagecreatefromjpeg( $fname );
			$width = imagesx( $img );
			$height = imagesy( $img );

			// calculate thumbnail size
			$new_width = $thumbWidth;
			$new_height = floor( $height * ( $thumbWidth / $width ) );

			// create a new temporary image
			$tmp_img = imagecreatetruecolor( $new_width, $new_height );

			// copy and resize old image into new image
			imagecopyresized( $tmp_img, $img, 0, 0, 0, 0, $new_width, $new_height, $width, $height );

			$thumb_name = str_replace('.jpg','_'.$thumbWidth.'.jpg',$nameOfFile);

			$wpdb->query("UPDATE ".$wpdb->prefix."rsevents_events SET EventIcon = '".$nameOfFile."' WHERE IdEvent = '".$IdEvent."'");

			// save thumbnail into a file
			imagejpeg( $tmp_img, "{$pathToThumbs}{$thumb_name}" );
		} 
		else RSEventsHelper::redirect('admin.php?page=rse_events&task=edit&id='.$IdEvent); 

	}
	
	function strip_html_tags($text)
	{
		$text = preg_replace(
			array(
			  // Remove invisible content
				'@<head[^>]*?>.*?</head>@siu',
				'@<style[^>]*?>.*?</style>@siu',
				'@<script[^>]*?.*?</script>@siu',
				'@<object[^>]*?.*?</object>@siu',
				'@<embed[^>]*?.*?</embed>@siu',
				'@<applet[^>]*?.*?</applet>@siu',
				'@<noframes[^>]*?.*?</noframes>@siu',
				'@<noscript[^>]*?.*?</noscript>@siu',
				'@<noembed[^>]*?.*?</noembed>@siu',
			  // Add line breaks before and after blocks
				'@</?((address)|(blockquote)|(center)|(del))@iu',
				'@</?((div)|(h[1-9])|(ins)|(isindex)|(p)|(pre))@iu',
				'@</?((dir)|(dl)|(dt)|(dd)|(li)|(menu)|(ol)|(ul))@iu',
				'@</?((table)|(th)|(td)|(caption))@iu',
				'@</?((form)|(button)|(fieldset)|(legend)|(input))@iu',
				'@</?((label)|(select)|(optgroup)|(option)|(textarea))@iu',
				'@</?((frameset)|(frame)|(iframe))@iu',
			),
			array(
				' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
				"\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0",
				"\n\$0", "\n\$0",
			),
			$text );
		return strip_tags( $text );
	}
	
	function shorten($string,$max=255,$more=' ...')
	{
		$string_tmp = '';
		$exp = explode(' ',$string);
		for ($i=0; $i<count($exp); $i++)
		{
			if (strlen($string_tmp) + strlen($exp[$i]) < $max)
			$string_tmp .= $exp[$i].' ';
			else
			break;
		}
	return substr($string_tmp,0,-1).(strlen($string) > strlen($string_tmp) ? $more : '');
	}
	
	function translateDate($date)
	{
		$replace = array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','January','February','March','April','May','June','July','August','September','October','November','December','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
		$with	 = array(RSE_MONTH_MONDAY,RSE_MONTH_TUESDAY,RSE_MONTH_WEDNESDAY,RSE_MONTH_THURSDAY,RSE_MONTH_FRIDAY,RSE_MONTH_SATURDAY,RSE_MONTH_SUNDAY,RSE_JANUARY,RSE_FEBRUARY,RSE_MARCH,RSE_APRIL,RSE_MAY,RSE_JUNE,RSE_JULY,RSE_AUGUST,RSE_SEPTEMBER,RSE_OCTOBER,RSE_NOVEMBER,RSE_DECEMBER,RSE_JAN,RSE_FEB,RSE_MAR,RSE_APR,RSE_MAY,RSE_JUN,RSE_JUL,RSE_AUG,RSE_SEP,RSE_OCT,RSE_NOV,RSE_DEC);
		
		return str_replace($replace, $with, $date);
	}
	
	function showEvent($body = 'info')
	{
		//get variables
		global $wpdb,$userdata,$RSEventsConfig,$rseargs,$wp_query;
		
		//Load the event
		$event=RSEventsDataFrontend::getEvent();
		
		//get the id of the page and the site url
		$post = $wp_query->post;
		$post_id = $post->ID;
		$url= get_bloginfo('wpurl').'/index.php?page_id='.$post_id;
		
		//get the user type
		$usertype = !empty($userdata->wp_capabilities) ? key($userdata->wp_capabilities) : '';
		$userid = isset($userdata->ID) ? $userdata->ID : 0;
		
		//Private url
		$privateUrl = isset($_REQUEST['privateUrl']) ? $_REQUEST['privateUrl'] : '';
		
		
		//Is event viewable (public=1 OR (private=0 AND (PrivateUrl == EventPrivateUrl OR I'm the event owner)) check)
		$EventPublicPrivate = ($event->EventType || (!$event->EventType && ($privateUrl == $event->EventPrivateUrl || $event->IdUser == $userid))) ? 1:0;
		
		//If IdEvent exists AND (Event is published OR (Event is unpublished AND I am the owner)) AND Event is public/private viewable
		if($event->IdEvent != 0 && ($event->published || (!$event->published && ($event->IdUser == $userid || $usertype =='administrator') )) && $EventPublicPrivate)
		{			
			$layout = file_get_contents(WP_PLUGIN_DIR.'/rsevents/designs/default/default.html');
			echo '<link type="text/css" rel="stylesheet" href="'.WP_PLUGIN_URL.'/rsevents/designs/default/default.css" />';
			
			
			//keep the unix time
			$event->EventStartDateToTime = $event->EventStartDate;
			$event->EventEndDateToTime = $event->EventEndDate;
			
			//change the event date to user's date format
			$event->EventStartDate = RSEventsHelper::translateDate(date($RSEventsConfig['global.dateformat'],$event->EventStartDate));
			$event->EventEndDate = RSEventsHelper::translateDate(date($RSEventsConfig['global.dateformat'],$event->EventEndDate));
			
			//replace event properties
			$find = array('{EventName}' , '{EventSubtitle}' , '{EventHost}' ,'{EventStartDate}' , '{EventEndDate}' , '{LocationName}' , '{LocationAddress}' , '{LocationCity}' , '{LocationState}' , '{EventPhone}' , '{EventEmail}' , '{EventURL}' , '{EventOwner}' , '{EventDescription}' , '{EventIcon}' , '{LocationZip}' , '{LocationCountry}' );
			
			//location url
			$link = $url.'&view=locations&task=show&id='.$event->IdLocation;
			$layout = str_replace('{locationUrl}' , $link , $layout);
			$eventLocationUrl = RSE_AT_LOCATION.' <a href="'.$link.'">'.$event->LocationName.'</a>';
			
			if($RSEventsConfig['enable.event.icon'] == 1 && $event->EventIcon != '')
				$eventIcon = '<img src="'.WP_PLUGIN_URL.'/rsevents/images/thumbs/'.str_replace('.jpg','_'.$RSEventsConfig['event.icon.big'].'.jpg',$event->EventIcon).'" />';
			else
				$eventIcon = '';
			
			$replace =array($event->EventName , $event->EventSubtitle , RSE_HOSTED_BY.' '.$event->EventHost , RSE_START_EVENT.' '.$event->EventStartDate , RSE_END_EVENT.' '.$event->EventEndDate , $eventLocationUrl , $event->LocationAddress , $event->LocationCity , $event->LocationState , $event->EventPhone , $event->EventEmail , $event->EventURL , RSE_EVENT_POSTED.' '.$event->EventOwner , $event->EventDescription , $eventIcon,$event->LocationZip , $event->LocationCountry ); 
			
			$layout = str_replace($find , $replace , $layout);
			
			//replace guest menu			
			$guest_module = RSEventsHelper::createGuestMenu($event);			
			$layout = str_replace('{EventGuestMenu}',$guest_module,$layout);

			
			/* Switch Body */
			switch($body)
			{
				case 'info':
					$layout = str_replace(array('{EventStartInfo}','{EventEndInfo}'),'',$layout);
					$layout = RSEventsHelper::createExtras($event, $layout);
				break;
				
				case 'invite':
				case 'importyahoo':
				case 'importgmail':
					$layout = RSEventsHelper::splitLayout($event, $layout);
				break;
				
			}
			
			return $layout;
		} else
		{
			RSEventsHelper::redirect($url.'&view=events&task=events&message=38');
		}

	
	}
	
	function splitLayout($event, $layout)
	{
		$find = explode('{EventStartInfo}',$layout);
		$l[0] = $find[0];
		
		$end = explode('{EventEndInfo}',$find[1]);
		$l[1] = $end[1];
		
		return $l;
		
	}
	
	
	function createGuestMenu($event)
	{			
		global $wpdb,$RSEventsConfig,$wp_query;
		
		//get the id of the page and the site url
		$post = $wp_query->post;
		$post_id = $post->ID;
		$url= get_bloginfo('wpurl').'/index.php?page_id='.$post_id;
		
		//get and set the Private Url
		$privateUrl = isset($_REQUEST['privateUrl']) ? $_REQUEST['privateUrl'] : '';
		if($privateUrl !='') $link = '&privateUrl='.$privateUrl;
		else $link='';
		
		$guest_module = '<div id="rsevents_menu">';
		$guest_module .= '<h3>'.RSE_GUEST_MENU.'</h3>';
		$guest_module .= '<ul>';
		
		if($RSEventsConfig['event.show.invite'] && $event->published != '-1') $guest_module .= '<li><a href="'.$url.'&view=events&task=invite&id='.$event->IdEvent.$link.'">'.RSE_MENU_EVENT_INVITE.'</a></li>';
		if ($RSEventsConfig['event.show.outlook']) $guest_module .= '<li><a href="'.WP_PLUGIN_URL.'/rsevents/data/raw.php?task=addoutlook&id='.$event->IdEvent.'">'.RSE_MENU_EVENT_ADD_OUTLOOK.'</a></li>';
		$guest_module .= '<li><a href="'.WP_PLUGIN_URL.'/rsevents/data/raw.php?task=printevent&id='.$event->IdEvent.'"  onclick="window.open(this.href,\'win2\',\'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no\'); return false;">'.RSE_MENU_EVENT_PRINT.'</a></li>';
		$guest_module .= '</ul>';
		$guest_module .= '</div>';
		
		return $guest_module;
	}
	
	
	function createExtras($event, $layout)
	{
		global $wpdb,$userdata,$RSEventsConfig,$wp_query;
		
		//get the id of the page and the site url
		$post = $wp_query->post;
		$post_id = $post->ID;
		$url= get_bloginfo('wpurl').'/index.php?page_id='.$post_id;
		
		//loading the files
		$fileList= RSEventsDataFrontend::getFiles();
	
		//Show files
		$files = array();
		if(!empty($fileList))
		{
			foreach($fileList as $i => $file)
			{
				$files[] = '<li><a href="'.WP_PLUGIN_URL.'/rsevents/files/'.$file->FileLocation.'" target="_blank">'.$file->FileName.'</a></li>';
			}
		}
		$find[] = '{EventFiles}';
		$replace[] = implode('',$files);
		
		//Replace the placeholders in the layout
		$layout = str_replace($find,$replace,$layout);
		
		return $layout;
	}
	
}
?>