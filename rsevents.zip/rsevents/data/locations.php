<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');


class RSEventsDataLocations {

	function getData()
	{
		global $wpdb;
		$filter = isset($_POST['rs_filter']) ? $_POST['rs_filter'] : '';
		$limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;
		$limitstart = isset($_POST['limitstart']) ? intval($_POST['limitstart']) : 0;
		$setlimit = ($limit == 0 && $limitstart == 0 ) ? "" :" LIMIT ".$limitstart." , ".$limit." ";
		
		$results = $wpdb->get_results("SELECT IdLocation,LocationName,published FROM ".$wpdb->prefix."rsevents_locations WHERE LocationName LIKE '%".$wpdb->escape($filter)."%' ORDER BY LocationName ASC ".$setlimit);
	
		return $results;
	}
	
	function getTotal()
	{
		global $wpdb;
	
		$return = $wpdb->get_row("SELECT COUNT(IdLocation) as nr FROM ".$wpdb->prefix."rsevents_locations");
		return $return;
	}
	
	function getLocation($id)
	{
		global $wpdb;
		
		$return = $wpdb->get_row("SELECT * FROM ".$wpdb->prefix."rsevents_locations WHERE IdLocation = ".$id);

		if(empty($return))
		{
			$return = new stdClass();
			$return->IdLocation = 0;
			$return->LocationName = '';
			$return->LocationDescription = '';
			$return->LocationURL = '';
			$return->LocationCity = '';
			$return->LocationAddress = '';
			$return->LocationZip = '';
			$return->LocationState = '';
			$return->LocationCountry = '';
			$return->LocationLat = '';
			$return->LocationLon = '';
			$return->published = 1;
		}
		
		return $return;
	}
	
	function checkDB()
	{
		global $wpdb;
		$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
		
		if($id == 0) return;
		
		$res = $wpdb->query("SELECT IdLocation FROM ".$wpdb->prefix."rsevents_locations WHERE IdLocation = ".$id);
		if($res == 0) RSEventsHelper::redirect('admin.php?page=rse_locations'); else return;
	}
}

?>