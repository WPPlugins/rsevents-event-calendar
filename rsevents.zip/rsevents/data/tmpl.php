<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

/** Load WordPress Administration Bootstrap */
chdir('../../../../wp-admin/');
require_once('admin.php');
global $wpdb,$userdata;

$task = isset($_GET['task']) ? $_GET['task'] : '';
?>

<?php switch($task) {

default: echo 'Please specify a certain task!'; 
break; 

case 'searchlocations': 

	$string = $_REQUEST['string'];
	$return = '';
	
	
	$locations = $wpdb->get_results("SELECT IdLocation,LocationName FROM ".$wpdb->prefix."rsevents_locations WHERE LocationName LIKE '%".$wpdb->escape($string)."%' ");
	
	$return .= '<select id="IdLocation" class="inputbox" size="1" name="IdLocation">'; 
	$return .= '<option value="0">'.RSE_EVENT_SELECT_LOCATION.'</option>';
	foreach($locations as $location)
		$return .= '<option value="'.$location->IdLocation.'">'.$location->LocationName.'</option>'; 
	$return .= '</select>';
	
	echo $return;
	exit();

break; ?>
<?php } ?>