<?php 
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

						####  BACKEND  ####

#GENERAL

define('RSE_YES','Yes');
define('RSE_NO','No');
define('RSE_FILTER','Filter');
define('RSE_CLEAR_FILTER','Clear Filter');
define('RSE_PUBLISHED','Published');
define('RSE_ORDER','Order');
define('RSE_SELECT','Select');
define('RSE_SAVE_BTN','Save');
define('RSE_CANCEL_BTN','Cancel');
define('RSE_CANCEL_OPERATION','Operation Cancelled');
define('RSE_PUBLISHED_ERROR','Select an item to ');
define('RSE_COPY_OF','Copy of ');
define('RSE_BACK','Back');
define('RSE_CHANGE','Change');
define('RSE_HTML','Html');
define('RSE_TEXT','Text');
define('RSE_LATEST_NEWS','Latest News');
define('RSE_REGISTRATION_SAVED','Registration saved');
define('RSE_REGISTRATION_CODE','Please enter your code to receive updates');
define('RSE_FEEDBACK','Feedback');
define('RSE_PREVIEW','Preview');
define('RSE_DEBUG','Debug');
define('RSE_GUEST','Guest');
define('RSE_TICKET_SEPARATOR','x');
define('RSE_ADD_EDIT_BTN','Add/Edit');
define('RSE_DUPLICATE_BTN','Duplicate');
define('RSE_ARCHIVE_BTN','Archive');
define('RSE_UNARCHIVE_BTN','Unarchive');
define('RSE_APPLY_BTN','Apply');
define('RSE_PUBLISH_BTN','Publish');
define('RSE_UNPUBLISH_BTN','Unpublish');
define('RSE_DELETE_BTN','Delete');
define('RSE_DEFAULT_BTN','Default');
define('RSE_ADD_NEW_BTN','Add new');
define('RSE_NONAME','<em>no name</em>');
define('RSE_CANNOT_CONNECT','<br/><font color="red">Error:</font> Cannot connect with username and password. Please try again!');

############# BACKEND ############# 

#MAIN MENU

define('RSE_MAIN_MENU','RSEvents!');
define('RSE_UPDATE','Update');
define('RSE_UPDATES_MENU','Updates');
define('RSE_PACKAGE','Package File');
define('RSE_PACKAGE_FILE','Upload Package File');
define('RSE_UPDATE_INSTRUCTIONS','Update Instructions');
define('RSE_UPDATE_INSTRUCTIONS_MESSAGE','Whenever we release a new update, you are able to download it directly from this screen. Save the file on your computer, then click on Browse, and then install the update.');
define('RSE_CONFIRM_MESSAGE','Please read the following:\\nIf you have made any changes to the RSEvents! files, your files will be overwritten after this update (even language or css files). So please make sure you backup any files you have modified from the plugins/rsevents directory.\\nYour current settings and uploaded files will remain untouched.');
define('RSE_EVENT_MANAGER','Events');
define('RSE_SUBSCRIPTION_MANAGER','Subscriptions');
define('RSE_CATEGORIES','Categories');
define('RSE_LOCATIONS','Locations');
define('RSE_DESIGNS','Designs');
define('RSE_GROUPS','Groups');
define('RSE_SETTINGS','Settings');
define('RSE_UPDATES','Check for updates');
define('RSE_INSTALLED_VERSION','Installed version:');
define('RSE_COPYRIGHT_NAME','Copyright:');
define('RSE_LICENSE_NAME','License:');
define('RSE_AUTHOR_NAME','Author:');
define('RSE_MODIFY_LICENSE','Modify code');
define('RSE_UPDATE_BUTTON','Update code');
define('RSE_UPDATE_CHECKING','Checking for updates');

#SETTINGS

define('RSE_DATE_FORMAT','Date Format');
define('RSE_NO_COMMENTS','No comments');
define('RSE_NO_PAYMENT','No Payment');
define('RSE_PAYMENT_PAYPAL','Paypal');
define('RSE_PAYMENT_WIRED','Wire transfer');
define('RSE_2CO_METHOD','2Checkout');
define('RSE_NAVIGATION_GENERAL','General');
define('RSE_NAVIGATION_EVENTS','Events');
define('RSE_NAVIGATION_LOCATIONS','Locations');
define('RSE_NAVIGATION_EMAILS','Emails');
define('RSE_NAVIGATION_PAYMENT','Payment');
define('RSE_SETTINGS_SAVE','Settings Saved');
define('RSE_GOOGLE_KEY_ERROR','Please insert a Google api key to enable Google Maps');
define('RSE_PLACEHOLDER_MISSING','{EventName} or {EventLink}  not found. Please insert it into layout');
define('RSE_GOOGLE_MAP','Google Map type');
define('RSE_12H','Enable 12h format');

#SETTINGS - EVENTS

define('RSE_EVENT_INTRO','Event Intro Layout');
define('RSE_EVENTS_PER_PAGE','Number of events on page');
define('RSE_FULL_BOOKING','Full Booking');
define('RSE_FULL_BOOKING_MESSAGE','Message for when booking is full');
define('RSE_USER_REGISTRATION','Event Registration');
define('RSE_DEFAULT_REGISTER_FORM','Default Registration Form');
define('RSE_REGISTRATION_METHOD','Registration Method');
define('RSE_CREATE_USER','Create user account automatically upon registration');
define('RSE_REDIRECT','Redirect to registration page');
define('RSE_FILES_ALLOWED','Files Allowed');
define('RSE_EXTENSIONS','Extensions');
define('RSE_EXTRAS','Extras');
define('RSE_ENABLE_FLASH','Enable flash');
define('RSE_ENABLE_YOUTUBE','Enable youtube');
define('RSE_ENABLE_MP3','Enable MP3');
define('RSE_ENABLE_MEEBO','Enable meebo');
define('RSE_ENABLE_FLICKR','Enable Flickr');
define('RSE_FLICKR_API_KEY','Flickr Api Key');
define('RSE_FLICKR_NUM_PHOTOS','Photos to display in event layout');
define('RSE_COMMENTS','Comments');
define('RSE_COMMENTS_SELECT','Select comment system');
define('RSE_SUBSCRIBERS_PROFILE','Comunity Profile');
define('RSE_SUBSCRIBERS_ENABLE_PROFILE','Enable comunity profile for');
define('RSE_NO_PROFILE','No profile');
define('RSE_SELECT_INTRO_LAYOUT','Select intro layout');
define('RSE_SELECT_LAYOUT','- Select layout -');
define('RSE_DEFAULT_LAYOUT','Default layout');
define('RSE_TABLE_LAYOUT','Table layout');
define('RSE_ICON_SHOW','Event Icon');
define('RSE_SMALL_ICON','Small icon width');
define('RSE_BIG_ICON','Big icon width');
define('RSE_ENABLE_ICON','Enable event icon');
define('RSE_CB_AUTOACCEPT','Enable auto-approve user');
define('RSE_CB_AUTOACCEPT_INFO','If you have CB installed please set this option to Yes in order to auto-approve the new user');
define('RSE_CB_REDIRECT','Redirection link');
define('RSE_JOOMLA_DEFAULT','Joomla Registration');
define('RSE_CB_LINK','Community Builder Registration');
define('RSE_MODERATION_SETTINGS','Moderation Settings');
define('RSE_MODERATION_EMAIL','Moderation E-mail');
define('RSE_MODERATION_INFO','Enter the email address where you will be noticed when a new event is created if you have Event Moderation on');
define('RSE_GUEST_MENU_OPTIONS','Guest Menu Options');
define('RSE_SHOW_INVITE','Show invite link');
define('RSE_SHOW_OUTLOOK','Show outlook link');
define('RSE_ENABLE_GUEST_REGISTRATION','Enable Registration of Guests');
define('RSE_ENABLE_MULTIPLE_REGISTRATION','Enable Multiple Registration');

#SETTINGS - EMAILS

define('RSE_EMAIL_FROM','From');
define('RSE_EMAIL_FROM_NAME','From Name');
define('RSE_EMAIL_REPLY','Reply to');
define('RSE_EMAIL_REG_EMAIL','Registration Email');
define('RSE_EMAIL_ACT_EMAIL','Activation Email');
define('RSE_EMAIL_PR_EMAIL','Post Reminder Email');
define('RSE_EMAIL_INV_EMAIL','Invite Email');
define('RSE_EMAIL_SUBJECT','Subject');
define('RSE_EMAIL_MODE','Mode(Text/HTML)');
define('RSE_EMAIL_MESSAGE','Email');
define('RSE_EMAIL_ENABLE','Enable E-mail');
define('RSE_EMAIL_REMINDER','Reminder Email');

#LOCATIONS

define('RSE_LOCATION_NEW','New Location');
define('RSE_LOCATION_EDIT','Edit Location');
define('RSE_LOCATION_LIST','List Locations');
define('RSE_LOCATION_NAME_DEFAULT','Location');
define('RSE_LOCATION_NAME','Name');
define('RSE_LOCATION_URL','Url');
define('RSE_LOCATION_ADDRESS','Address');
define('RSE_LOCATION_ZIP','Zip');
define('RSE_LOCATION_CITY','City');
define('RSE_LOCATION_STATE','State');
define('RSE_LOCATION_COUNTRY','Country');
define('RSE_LOCATION_DESCRIPTION','Description');
define('RSE_LOCATION_MAP','Map');
define('RSE_LOCATION_LATITUDE','Latitude');
define('RSE_LOCATION_LONGITUDE','Longitude');
define('RSE_LOCATION_SAVE','Location Saved!');
define('RSE_LOCATION_SAVE_ERROR','Error Saving Location');
define('RSE_LOCATION_DELETE','Location(s) deleted');
define('RSE_LOCATION_DELETE_ERROR','Some of the locations that you want to delete still contains events');
define('RSE_LOCATION_SELECT','Select Location');
define('RSE_LOCATION_NAME1','Location name');


#EVENTS

define('RSE_EVENTNAME','Event name');
define('RSE_EVENT_NEW','New Event');
define('RSE_EVENT_EDIT','Edit Event');
define('RSE_EVENT_LIST','List Events');
define('RSE_EVENT_TAB_INFO','Event Info');
define('RSE_EVENT_TAB_DESCRIPTION','Description');
define('RSE_EVENT_TAB_REGISTRATION','Registration');
define('RSE_EVENT_TAB_FILES','Files');
define('RSE_EVENT_TAB_EXTRAS','Extras');
define('RSE_EVENT_NAME_DEFAULT','Event Name');
define('RSE_EVENT_SUBSCRIPTIONS','Subscriptions');
define('RSE_EVENT_OWNER','Owner');
define('RSE_EVENT_CATEGORY_NAME_DEFAULT','Category name');
define('RSE_EVENT_LOCATION_NAME_DEFAULT','Location name');
define('RSE_EVENT_START_DATE_DEFAULT','Event start date');
define('RSE_EVENT_END_DATE_DEFAULT','Event end date');
define('RSE_EVENT_SELECT_CATEGORY','- Select Category -');
define('RSE_EVENT_SELECT_LOCATION','- Select Location -');
define('RSE_EVENT_SELECT_DESIGN','- Select Design -');
define('RSE_EVENT_ALIAS','Event Alias');
define('RSE_EVENT_SUBTITLE','Event Subtitle');
define('RSE_EVENT_HOSTER','Hosted by');
define('RSE_EVENT_CATEGORY','Category');
define('RSE_EVENT_DESIGN','Design');
define('RSE_EVENT_LOCATION','Location');
define('RSE_EVENT_START_DATE','Start date');
define('RSE_EVENT_START_TIME','Start time');
define('RSE_EVENT_END_DATE','End date');
define('RSE_EVENT_END_TIME','End time');
define('RSE_EVENT_WEB','Web');
define('RSE_EVENT_PHONE','Phone');
define('RSE_EVENT_EMAIL','E-mail');
define('RSE_EVENT_DESCRIPTION','Event Description');
define('RSE_EVENT_OPTION_TYPE','Event will be');
define('RSE_EVENT_OPTION_OVERBOOKING','Allow overbooking');
define('RSE_EVENT_OPTION_PRIVATE_URL','Private Url');
define('RSE_EVENT_GENERATE_PRIVATE_URL','Generate new private URL');
define('RSE_EVENT_OPTION_REGISTRATION','Enable registration');
define('RSE_EVENT_OPTION_TICKETS','Manage tickets type');
define('RSE_EVENT_OPTION_GUEST','Show guests that registered');
define('RSE_EVENT_OPTION_COMMENT','Allow users to commnent');
define('RSE_EVENT_OPTION_RSFORM','Select registration form');
define('RSE_ADD_RSEVENTS_COMPONENTS','Add RSEvents! form components first');
define('RSE_EVENT_FILES','File(s)');
define('RSE_EVENT_ADD_FILES','Add a new field');
define('RSE_EVENT_FILES_NAME','File name');
define('RSE_EVENT_FILES_EVERYONE','Visible for everyone');
define('RSE_EVENT_FILES_REGISTERED','Visible for registered');
define('RSE_EVENT_FILES_DELETE','Delete file');
define('RSE_EVENT_FILES_BEFORE','Before event:');
define('RSE_EVENT_FILES_DURING','During event:');
define('RSE_EVENT_FILES_AFTER','After event:');
define('RSE_EVENT_EXTRAS_ADD','Add new extras');
define('RSE_EVENT_EXTRA_TYPE','Extra type');
define('RSE_EVENT_EXTRA_NAME','Extra');
define('RSE_EVENT_EXTRA_DELETE','Delete extra');
define('RSE_EVENT_INVALID_FILE','Invalid file type');
define('RSE_EVENT_SAVE','Event Saved!');
define('RSE_EVENT_SAVE_ERROR','Error Saving Event');
define('RSE_EVENT_DELETE_ERROR','Error: One or More Event Could not be Deleted');
define('RSE_EVENT_DELETE','Event(s) Deleted');
define('RSE_EVENT_SELECT','Please select at least one event');
define('RSE_EVENT_COPY','Event(s) copied.');
define('RSE_EVENT_COPY_ERROR','Select at least one event.');
define('RSE_SELECT_EVENT','Select Event');
define('RSE_PRIVATE','Private');
define('RSE_PUBLIC','Public');
define('RSE_EVENT_REPEAT','Repeat');
define('RSE_EVENT_TYPE_INFO','Selecting "Private" you will get a private link to share with event attendants.');
define('RSE_DEFAULT_FORM','Default form');
define('RSE_ADD_NEW_FORM','Add new form');
define('RSE_EVENT_AUTO_APROVE_INFO','Automatically approve users who purchase a free ticket (price is set to 0)');
define('RSE_EVENT_AUTO_APROVE','Automatically approve users');
define('RSE_SUBJECT_REQUIRE_MODERATION','User %s has created a new event');
define('RSE_BODY_REQUIRE_MODERATION','A new event that requires moderetation has been submitted.');
define('RSE_INVALID_DATE','Please set the "End Date" to be higher than the "Start Date"');
define('RSE_EVENT_KEYWORDS','Event keywords');
define('RSE_EVENT_METADESCRIPTION','Event meta description');
define('RSE_MY_EVENTS','My Events');




#FILES

define('RSE_FILE_EDIT','Edit File Details');
define('RSE_FILE_NAME','File Name');
define('RSE_FILE_DESCRIPTION','File Description');
define('RSE_FILE_LOCATION','File Location');
define('RSE_FILE_PERMISSIONS','Permissions');
define('RSE_FILE_PERMISSIONS_EVERYONE','Make visible for Everyone:');
define('RSE_FILE_PERMISSIONS_REGISTERED','Make visible for Registered:');
define('RSE_FILE_PERMISSIONS_BEFORE','Before the event');
define('RSE_FILE_PERMISSIONS_DURING','During the event');
define('RSE_FILE_PERMISSIONS_AFTER','After the event');
define('RSE_FILE_SAVE','File Details Saved!');
define('RSE_FILE_SAVE_ERROR','Error Saving File Details');
define('RSE_FILE_DELETE_ERROR','Error: One or More Files Could not be Deleted');
define('RSE_FILE_DELETE','File(s) Deleted');
define('RSE_FILE_DELETE_ERROR1','Please select at least one file to delete');
define('RSE_ICON','Upload Icon');
define('RSE_ICON_ERROR','Please upload only JPG files');
define('RSE_ICON_DELETED','The icon has been deleted');

#REPEAT

define('RSE_REPEAT_FOR','Repeating for:');
define('RSE_SELECT_TYPE','Select type');
define('RSE_REPEAT_DAYS','Day(s)');
define('RSE_REPEAT_WEEKS','Week(s)');
define('RSE_REPEAT_MONTHS','Month(s)');
define('RSE_REPEAT_YEARS','Year(s)');
define('RSE_ENABLE_REPEAT','Enable repeating');
define('RSE_REPEAT_METHOD','Repeat every');
define('RSE_REPEAT_UNTIL','Repeat until');
define('RSE_REPEAT_ALSO','Repeat also on');
define('RSE_REPEAT_SAVE','Event repeating saved');
define('RSE_REPEAT_ERROR','Error saving');
define('RSE_REPEAT_ERROR1','Cannot repeat a child-event');

#ARCHIVE

define('RSE_ARCHIVE','Archive');
define('RSE_EVENT_ARCHIVED','Events Archived');
define('RSE_EVENT_UNARCHIVED','Event(s) Unarchived');
define('RSE_AUTO_ARCHIVE','Auto Archive');
define('RSE_NR_DAYS_ARCHIVE','Archive expired events after');
define('RSE_NR_DAYS','Days');
define('RSE_ENABLE_ARCHIVE','Enable Auto Archive');

					### FRONTEND ###
					
					
#GENERAL



define('RSE_NEW_BTN','New');
define('RSE_CANCELED_OPERATION','Operation Cancelled');
define('RSE_ACCESS_DENIED','Access denied');
define('RSE_IMPORT','Import');
define('RSE_INVALID_LOGIN','The email or password you entered does not exist. Please try again');
define('RSE_EMPTY_USERNAME','Enter Your Username and Password.');
define('RSE_NEXT_BTN','Next');
define('RSE_PLEASE_SAVE','Please save');
define('RSE_POST_REMINDER_SENT','Post reminder sent!');
define('RSE_REMINDER_SENT','Reminder sent!');
define('RSE_MORE','More...');
define('RSE_HOST_MENU','Host Menu');
define('RSE_GUEST_MENU','Guest Menu');
define('RSE_PREV','Prev');
define('RSE_REFRESH','Refresh');
define('RSE_GO','Go');
define('RSE_EVENT','Event');
define('RSE_SEARCH','Search');
define('RSE_DATE','Date');
define('RSE_GUESTS','Guests');
define('RSE_NO_EVENTS_MODULE','No events');
define('RSE_EVENT_MODULE','event');
define('RSE_EVENT_MODULE_PLURAL','s');
define('RSE_ORDERING','Ordering');
define('RSE_REDIRECT_2CO','Please wait while you are redirected ...');
define('RSE_APPLY','Apply');
define('RSE_FROM','From');


############# FRONTEND ############# 


#SHOW EVENT LAYOUT

define('RSE_HOSTED_BY','Hosted by:');
define('RSE_START_EVENT','The event will start on: ');
define('RSE_END_EVENT','And will end on: ');
define('RSE_AT_LOCATION','At');
define('RSE_EVENT_POSTED','Posted by:');


#LOCATIONS

define('RSE_LOCATION_NO_PERMISSION','You dont have the permission to create a new location');
define('RSE_LOCATION_NO_DESCRIPTION','No description available');

#EVENTS

define('RSE_MENU_EVENT_EDIT','Edit Event');
define('RSE_MENU_EVENT_INVITE','Invite People');
define('RSE_MENU_EVENT_SEND_MESSAGES','Send message to guests');
define('RSE_MENU_EVENT_EXPORT','Export guests');
define('RSE_MENU_EVENT_SUBSCRIBERS','List subscribers');
define('RSE_MENU_EVENT_DUPLICATE','Duplicate Event');
define('RSE_MENU_EVENT_PREMINDER','Send Post Reminder');
define('RSE_MENU_EVENT_REMINDER','Send Reminder');
define('RSE_MENU_EVENT_CANCEL','Cancel Event');
define('RSE_MENU_EVENT_SUBSCRIBE','Subscribe');
define('RSE_MENU_EVENT_ADD_PHOTOS','Add photos');
define('RSE_MENU_EVENT_ADD_OUTLOOK','Add to Outlook Calendar');
define('RSE_MENU_EVENT_PRINT','Print Event');
define('RSE_MENU_EVENT_UNSUBSCRIBE','Unsubscribe');
define('RSE_MENU_EVENT_UNSUBSCRIBE_CONFIRM','Are you sure that you want to unsubscribe this event?');
define('RSE_MENU_EVENT_PREMINDER_CONFIRM','Are you sure that you want to send post-reminder emails to registered subscribers?');
define('RSE_MENU_EVENT_REMINDER_CONFIRM','Are you sure that you want to send a reminder email to registered subscribers?');
define('RSE_MENU_EVENT_DELETE_CONFIRM','Are you sure that you want to delete this event ?');
define('RSE_EVENT_INVALID','Invalid Event');
define('RSE_EVENT_ALLREADY_REGISTERED','You have allready registered to this event');
define('RSE_PAYPAL_METHOD','Paypal');
define('RSE_WIRE_METHOD','Wire Transfer');
define('RSE_EVENT_INFO','Event Info');
define('RSE_EVENT_NAME','Event Name');
define('RSE_EVENT_ADD_LOCATION','Add Location');
define('RSE_EVENT_LAYOUT','Event Layout');
define('RSE_DESIGN','DESIGN');
define('RSE_FILES','FILES');
define('RSE_DESCRIPTION','DESCRIPTION');
define('RSE_EVENTS','Events');
define('RSE_ADD_EVENT','Add new Event');
define('RSE_ADD_EVENT_TITLE','Submit new event::Click to add an event');
define('RSE_NO_EVENTS','No events found');
define('RSE_EVENTS_FROM','Events from');
define('RSE_EVENTS_TO',' to');
define('RSE_NO_EVENTS_IN_PERIOD','There are no events in this period of time');
define('RSE_EVENT_STARTS_MESSAGE','The event will start on :');
define('RSE_EVENT_ENDS_MESSAGE','And will end on :');
define('RSE_REGISTERED_USERS','Registered users:');
define('RSE_EVENT_ERROR1','Select at least one event.');
define('RSE_ARCHIVE_EVENTS','Archive Events');
define('RSE_FEATURE_EVENTS','Feature Events');
define('RSE_FUTURE_EVENTS','Future Events');


#EVENT SEND MESSAGES

define('RSE_MESSAGE_TITLE','Send an e-mail to registered users');
define('RSE_MESSAGE_TO','To: ');
define('RSE_MESSAGE_ACCEPTED','Accepted');
define('RSE_MESSAGE_PENDING','Pending');
define('RSE_MESSAGE_DENIED','Denied');
define('RSE_MESSAGE_SUBJECT','Subject:');
define('RSE_MESSAGE_BODY','Message:');
define('RSE_MESSAGE_SEND','Send');
define('RSE_MESSAGE_SENT','Message sent');
define('RSE_MESSAGE_RECIEVER_ERROR','Please select a receiver');

#IMPORTERS

define('RSE_USER_ID','User Id');
define('RSE_PASSWORD','Password');
define('RSE_IMPORT_NOW','Import Now');
define('RSE_RESET','Reset');

#EVENTS INVITE

define('RSE_INVITE_TITLE','Invite people');
define('RSE_INVITE_ADDRESSES',' Enter the email addresses of people you want to invite, each email address on a new line:');
define('RSE_INVITE_IMPORTS','or import addresses from');
define('RSE_INVITE_MESSAGE',' Personalized message (optional):');
define('RSE_INVITE','Invite');
define('RSE_INVITE_SENT','Invitations sent');

#FILES


define('RSE_FILE_ADD_FILES','Add a new upload file');
define('RSE_FILE_VISIBLE_EVERYONE','Visible for everyone');
define('RSE_FILE_VISIBLE_REGISTERED','Visible for registered');
define('RSE_DELETE_FILE','Delete');
define('RSE_FILE_BEFORE','Before:');
define('RSE_FILE_DURING','During:');
define('RSE_FILE_AFTER','After:');
define('RSE_FILE_INVALID','Invalid file type');
define('RSE_FILE_CANNOT_UPLOAD','You cannot upload files');

#SEND MAIL 

define('RSE_MSG_SUBJECT','Account details for %s');
define('RSE_SEND_MSG','Hello %s,\n\nThank you for registering at %s.\n\nYou may now log in to %s. \n\nUsername: %s \n\nPassword: %s');

#RSEVENTS CALENDAR

define('RSE_STARTS_ON','Starts on:');
define('RSE_ENDS_ON','Ends on:');

define('RSE_WEEK','Week');
define('RSE_MONTH_MONDAY','Monday');
define('RSE_MONTH_TUESDAY','Tuesday');
define('RSE_MONTH_WEDNESDAY','Wednesday');
define('RSE_MONTH_THURSDAY','Thursday');
define('RSE_MONTH_FRIDAY','Friday');
define('RSE_MONTH_SATURDAY','Saturday');
define('RSE_MONTH_SUNDAY','Sunday');

define('RSE_MONTH_SHORT_MONDAY','Mo');
define('RSE_MONTH_SHORT_TUESDAY','Tu');
define('RSE_MONTH_SHORT_WEDNESDAY','We');
define('RSE_MONTH_SHORT_THURSDAY','Th');
define('RSE_MONTH_SHORT_FRIDAY','Fr');
define('RSE_MONTH_SHORT_SATURDAY','Sa');
define('RSE_MONTH_SHORT_SUNDAY','Su');


define('RSE_JANUARY','January');
define('RSE_FEBRUARY','February');
define('RSE_MARCH','March');
define('RSE_APRIL','April');
define('RSE_MAY','May');
define('RSE_JUNE','June');
define('RSE_JULY','July');
define('RSE_AUGUST','August');
define('RSE_SEPTEMBER','September');
define('RSE_OCTOBER','October');
define('RSE_NOVEMBER','November');
define('RSE_DECEMBER','December');

define('RSE_JAN','Jan');
define('RSE_FEB','Feb');
define('RSE_MAR','Mar');
define('RSE_APR','Apr');
define('RSE_JUN','Jun');
define('RSE_JUL','Jul');
define('RSE_AUG','Aug');
define('RSE_SEP','Sep');
define('RSE_OCT','Oct');
define('RSE_NOV','Nov');
define('RSE_DEC','Dec');

?>