<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');
require_once(WP_PLUGIN_DIR.'/rsevents/controllers/events.php');
require_once(WP_PLUGIN_DIR.'/rsevents/data/events.php');
require_once(WP_PLUGIN_DIR.'/rsevents/data/pagination.php');

$task = isset($_GET['task']) ? $_GET['task'] : ''; 
$message = isset($_GET['message']) ? $_GET['message'] : ''; 
$view = isset($_POST['view']) ? $_POST['view'] : ''; 

/*  Do Actions  */
$option = isset($_POST['option']) ? $_POST['option'] : '';
$published = isset($_POST['generalid']) ? intval($_POST['generalid']) : '';
$cids = isset($_POST['cid']) ? $_POST['cid'] : '';
if(isset($option) && $option == 'delete') RSEventsEvents::delete($cids);
if(isset($option) && $option == 'deletefile') RSEventsEvents::deletefile();
if(isset($option) && $option == 'delicon') RSEventsEvents::delicon();
if(isset($option) && $option == 'private') RSEventsEvents::privateurl();
if(isset($option) && $option == 'edit') RSEventsEvents::addedit($cids);
if(isset($option) && $option == 'archive') RSEventsEvents::archive($cids);
if(isset($option) && $option == 'cancel') RSEventsEvents::cancel();
if(isset($option) && ($option == 'apply' || $option == 'save')) RSEventsEvents::save();
if(isset($option) && ($option == 'apply' || $option == 'save') && $view == 'repeat') RSEventsEvents::saverepeat();
if(!empty($option) && isset($published) && ($option == 'publish' || $option == 'unpublish'))  RSEventsEvents::publish($published,$option);
?>

<div class="wrap">

<?php 
switch($task) {
default:  case '':

$buttons = array('addedit','delete'); 
$data = RSEventsDataEvents::getData();
$total = RSEventsDataEvents::getTotal();
$limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;
$limitstart = isset($_POST['limitstart']) ? intval($_POST['limitstart']) : 0;
$pagination = new RSPagination($total,$limitstart,$limit); 

$cat_filter = isset($_POST['cat_filter']) ? $_POST['cat_filter'] : '';
$loc_filter = isset($_POST['loc_filter']) ? $_POST['loc_filter'] : '';
?>

<h2><?php echo RSE_EVENT_LIST; ?></h2>
<div class="clear"></div>
<?php echo RSEMessages::show($message); ?>

<form action="" method="post" name="adminForm">
<?php echo RSEventsHelper::makeButtons($buttons); ?>
<br/>
	<table>
		<tr>
			<td width="100%"><?php echo RSE_FILTER; ?> <input type="text" name="rs_filter" id="rs_filter" class="text_area" value="<?php echo @$_POST['rs_filter']; ?>"/> <input type="button" value="<?php echo RSE_FILTER; ?>" onclick="createFilter(document.getElementById('rs_filter').value);return false;" /> <input type="button" onclick="eraseFilter();" value="<?php echo RSE_CLEAR_FILTER; ?> " />
			</td>
			<td nowrap="nowrap">
				<?php $locs = $wpdb->get_results("SELECT IdLocation ,LocationName FROM ".$wpdb->prefix."rsevents_locations"); ?>
				<select onchange="rswp_submitform();" size="1" name="loc_filter">
					<option <?php selected($loc_filter,'',true); ?> value=""><?php echo RSE_EVENT_SELECT_LOCATION; ?></option>
					<?php foreach($locs as $loc) { ?>
					<option <?php selected($loc_filter,$loc->IdLocation,true); ?> value="<?php echo $loc->IdLocation; ?>"><?php echo $loc->LocationName; ?></option>
					<?php } ?>
				</select>
			</td>
		</tr>
	</table>
	<div id="editcell1">
		<table class="widefat page" width="100%">
			<thead>
			<tr>
				<th width="1%">#</th>
				<th width="1%"><input type="checkbox" name="toggle" value="" onclick="rswp_checkAll(<?php echo count($data); ?>);"/></th>
				<th width="20%"><?php echo RSE_EVENT_NAME_DEFAULT; ?></th>
				<th width="2%"><?php echo RSE_EVENT_OWNER; ?></th>
				<th width="5%"><?php echo RSE_EVENT_CATEGORY_NAME_DEFAULT; ?></th>
				<th width="6%"><?php echo RSE_EVENT_LOCATION_NAME_DEFAULT; ?></th>
				<th width="6%"><?php echo RSE_EVENT_START_DATE_DEFAULT; ?></th>
				<th width="6%"><?php echo RSE_EVENT_END_DATE_DEFAULT; ?></th>
				<th width="1%"><?php echo RSE_EVENT_REPEAT; ?></th>
				<th width="1%"><?php echo RSE_PUBLISHED; ?></th>
			</tr>
			</thead>
	<?php
	$k = 0;
	for ($i=0,$n=count($data);$i<$n;$i++)
	{
		
		$row =& $data[$i];
		
	?>
			<tr class="<?php echo "row$k"; ?>">
				<td><?php echo $row->IdEvent; ?></td>
				<td align="center"><input type="checkbox" onclick="rswp_isChecked(this.checked);" id="cb<?php echo $i; ?>" value="<?php echo $row->IdEvent; ?>" name="cid[]" /></td>
				<td><?php echo '<a href="admin.php?page=rse_events&task=edit&id='.$row->IdEvent.'">'.$row->EventName.'</a>'; ?></td>
				<td><?php echo $row->user_login; ?></td>
				<td align="center">Events</td>
				<td align="center"><?php echo $row->LocationName; ?></td>
				<td><?php echo date($RSEConfig['global.dateformat'],$row->EventStartDate); ?></td>
				<td><?php echo date($RSEConfig['global.dateformat'],$row->EventEndDate); ?></td>
				<td align="center"><?php if($row->IdParent == 0) { ?><a href="admin.php?page=rse_events&task=eventrepeat&id=<?php echo $row->IdEvent; ?>"><img src="<?php echo WP_PLUGIN_URL;?>/rsevents/images/icons/details.png" /></a><?php } ?></td>
				<td align="center"><?php echo RSEventsHelper::isPublished($wpdb->prefix.'rsevents_events','IdEvent',$row->IdEvent); ?></td>
			</tr>
	<?php
		$k=1-$k;
	}
	?>
		<tfoot>
			<tr>
				<td colspan="11"><?php echo $pagination->getPagination(); ?></td>
			</tr>
		</tfoot>
		</table>
	</div>
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="generalid" value="" />
	<input type="hidden" name="option" value="" />
	<input type="hidden" name="rs_filter" value="" id="filter" />
	</form>

<?php break; ?>
<?php case 'edit': 

$id = isset($_GET['id']) ? $_GET['id'] : 0;
$subpage = isset($_GET['subpage']) ? $_GET['subpage'] : 'event';
$buttons = array('apply','save','cancel');
RSEventsDataEvents::checkDB();
$event = RSEventsDataEvents::getEvent();
?>

<h2><?php echo $id == 0  ? RSE_EVENT_NEW : RSE_EVENT_EDIT; ?></h2>
<div class="clear"></div>
<?php echo RSEMessages::show($message); ?>
<?php echo RSEventsDataEvents::headers(); ?>

<script type="text/javascript">
function newFile()
{
	document.getElementById('files').innerHTML += '<br/><input type="file" name="files[]" size="40"/>';
}

function rse_del_file(idf,ide)
{
	document.adminForm.option.value = 'deletefile';
	document.adminForm.gid.value = idf;
	document.adminForm.eid.value = ide;
	rswp_submitform();
}

function rse_del_ext(idex,ide)
{
	document.adminForm.option.value = 'deleteextra';
	document.adminForm.gid.value = idex;
	document.adminForm.eid.value = ide;
	rswp_submitform();
}

function rse_del_ico(ide)
{
	document.adminForm.option.value = 'delicon';
	document.adminForm.eid.value = ide;
	rswp_submitform();
}

function rse_private(id)
{
	document.adminForm.option.value = 'private';
	document.adminForm.eid.value = id;
	rswp_submitform();
}

<?php if($subpage == 'event') { ?>
function rswp_submitform()
{
	var form = document.adminForm;
	
	if(form.option.value == 'cancel') 
	{	
		form.option.value = 'cancel'; 
		form.submit();
	}
	else  
	{
		ret = true;
		if(form.EventName.value=='') { form.EventName.className = 'rswpError'; ret=false; } else { form.EventName.className = '';  }	
		if(form.IdLocation.value=='0') { form.IdLocation.className = 'rswpError'; ret=false; } else { form.IdLocation.className = '';  }	
		if(form.EventHost.value=='') { form.EventHost.className = 'rswpError'; ret=false; } else { form.EventHost.className = ''; }
		if(form.IdUser.value=='') { form.IdUser.className = 'rswpError'; ret=false; } else { form.IdUser.className = '';	 }
		if(form.EventStartDate.value=='') { form.EventStartDate.className = 'rswpError'; ret=false; } else { form.EventStartDate.className = '';  }	
		if(form.EventStartDateH.value=='') { form.EventStartDateH.className = 'rswpError'; ret=false; } else { form.EventStartDateH.className = ''; }	
		if(form.EventStartDateM.value=='') { form.EventStartDateM.className = 'rswpError'; ret=false; } else { form.EventStartDateM.className = '';  }	
		if(form.EventEndDate.value=='') { form.EventEndDate.className = 'rswpError'; ret=false; } else { form.EventEndDate.className = '';	 }
		if(form.EventEndDateH.value=='') { form.EventEndDateH.className = 'rswpError'; ret=false; } else { form.EventEndDateH.className = '';  }	
		if(form.EventEndDateM.value=='') { form.EventEndDateM.className = 'rswpError'; ret=false; } else { form.EventEndDateM.className = '';  }
		<?php if($RSEConfig['enable.12format'] == 1) { ?>
			if(form.EventStartDateH.value > 12 || form.EventStartDateH.value < 1) { form.EventStartDateH.className = 'rswpError'; ret=false; } else { form.EventStartDateH.className = ''; }	
			if(form.EventStartDateM.value > 59 || form.EventStartDateM.value < 0 || form.EventStartDateM.value == '') { form.EventStartDateM.className = 'rswpError'; ret=false; } else { form.EventStartDateM.className = '';  }
			if(form.EventEndDateH.value > 12 || form.EventEndDateH.value < 1) { form.EventEndDateH.className = 'rswpError'; ret=false; } else { form.EventEndDateH.className = '';  }	
			if(form.EventEndDateM.value > 59 || form.EventEndDateM.value < 0 || form.EventEndDateM.value == '') { form.EventEndDateM.className = 'rswpError'; ret=false; } else { form.EventEndDateM.className = '';  }
		<?php } else { ?>
			if(form.EventStartDateH.value > 23 || form.EventStartDateH.value < 0 || form.EventStartDateH.value == '') { form.EventStartDateH.className = 'rswpError'; ret=false; } else { form.EventStartDateH.className = ''; }	
			if(form.EventStartDateM.value > 59 || form.EventStartDateM.value < 0 || form.EventStartDateM.value == '') { form.EventStartDateM.className = 'rswpError'; ret=false; } else { form.EventStartDateM.className = '';  }
			if(form.EventEndDateH.value > 23 || form.EventEndDateH.value < 0 || form.EventEndDateH.value == '') { form.EventEndDateH.className = 'rswpError'; ret=false; } else { form.EventEndDateH.className = '';  }	
			if(form.EventEndDateM.value > 59 || form.EventEndDateM.value < 0 || form.EventEndDateM.value == '') { form.EventEndDateM.className = 'rswpError'; ret=false; } else { form.EventEndDateM.className = '';  }
		<?php } ?>
		if(ret) form.submit();
	}
	return false;
	 
}
<?php } ?>
</script>

<form action="" method="post" enctype="multipart/form-data" name="adminForm">
<?php echo RSEventsHelper::makeButtons($buttons); ?>
<?php 
switch($subpage) {
default:
case 'event':

echo '	<script type="text/javascript" src="'.WP_PLUGIN_URL.'/rsevents/assets/calendar/calendar.js"></script>
		<script type="text/javascript" src="'.WP_PLUGIN_URL.'/rsevents/assets/calendar/calendar-setup.js"></script>
		<script type="text/javascript" src="'.WP_PLUGIN_URL.'/rsevents/assets/calendar/calendar-en.js"></script>
		<style type="text/css"> @import url("'.WP_PLUGIN_URL.'/rsevents/assets/calendar/skins/tiger/theme.css"); </style>';
?>

<table cellspacing="0" cellpadding="0" border="0" width="100%">
	<tr>
		<td valign="top">
			<table  class="widefat page">
				<tr>
					<td>
						<label for="published">
							<?php echo RSE_PUBLISHED.':'; ?>
						</label>
					</td>
					<td>						
						<input type="radio" <?php checked($event->published,0,true); ?> value="0" id="published0" name="published"/>
						<label for="published0"><?php echo RSE_NO; ?></label>
						<input type="radio" <?php checked($event->published,1,true); ?> value="1" id="published1" name="published"/>
						<label for="published1"><?php echo RSE_YES; ?></label>
					</td>
				</tr>
				<tr>
					<td>
						<label for="eventname">
							<?php echo RSE_EVENT_NAME_DEFAULT.':'; ?>
						</label>
					</td>
					<td>						
						<input name="EventName" value="<?php echo $event->EventName; ?>" size="50" /> (*)
					</td>
				</tr>
				<tr>
					<td>
						<label for="eventsubtitle">
							<?php echo RSE_EVENT_SUBTITLE.':'; ?>
						</label>
					</td>
					<td>						
						<input name="EventSubtitle" value="<?php echo $event->EventSubtitle; ?>" size="50" />
					</td>
				</tr>
				<tr>
					<td>
						<label for="hosted">
							<?php echo RSE_EVENT_HOSTER.':'; ?>
						</label>
					</td>
					<td>						
						<input name="EventHost" value="<?php echo $event->EventHost; ?>" size="50" /> (*)
					</td>
					<td>						
						
					</td>
				</tr>
				<tr>
					<td>
						<label for="category">
							<?php echo RSE_EVENT_CATEGORY.':'; ?> (pro)
						</label>
					</td>
					<td>Events</td>
				</tr>
				<tr>
					<td>
						<label for="design">
							<?php echo RSE_EVENT_DESIGN.':'; ?> (pro)
						</label>
					</td>
					<td>default</td>
				</tr>
				<tr>
					<td>
						<label for="location">
							<?php echo RSE_EVENT_LOCATION.':'; ?> <img id="rse_hideme" style="display:none;" src="<?php echo WP_PLUGIN_URL.'/rsevents/images/icons/loader.gif' ?>">
						</label>
					</td>
					<td>						
						<input type="text" name="lfilter" id="lfilter" value="" size="15" onkeyup="rse_search_locations('<?php echo WP_PLUGIN_URL; ?>',this.value);" onkeydown="rse_stop_search_locations();"/> 
						<span id="rse_locations">
						<?php $locations = $wpdb->get_results("SELECT IdLocation,LocationName FROM ".$wpdb->prefix."rsevents_locations ORDER BY LocationName ASC"); ?>
						<select size="1" id="IdLocation" name="IdLocation">
							<option <?php selected($event->IdLocation,0,true); ?> value="0"><?php echo RSE_EVENT_SELECT_LOCATION; ?></option>
							<?php foreach($locations as $location) { ?>
								<option <?php selected($event->IdLocation,$location->IdLocation,true); ?> value="<?php echo $location->IdLocation; ?>"><?php echo $location->LocationName; ?></option>
							<?php } ?>
						</select>
						</span> (*)
					</td>
				</tr>
				<tr>
					<td>
						<label for="owner">
							<?php echo RSE_EVENT_OWNER.':'; ?>
						</label>
					</td>
					<td>						
						<?php $users = $wpdb->get_results("SELECT ID,user_login FROM ".$wpdb->prefix."users"); ?> 
						<select size="5" id="IdUser" name="IdUser" style="height:8em;width:13%">
							<?php foreach($users as $user) { ?>
								<option <?php selected($event->IdUser,$user->ID,true); ?> value="<?php echo $user->ID; ?>"><?php echo $user->user_login; ?></option>
							<?php } ?>
						</select>
						(*)
					</td>
				</tr>
				<tr>
					<td>
						<label for="StartDate">
							<?php echo RSE_EVENT_START_DATE.':'; ?>
						</label>
					</td>
					<td>						
						<input type="text" id="EventStartDate" name="EventStartDate" value="<?php echo date('Y-m-d',empty($event->EventStartDate) ? time() : $event->EventStartDate); ?>" /> <img src="<?php echo WP_PLUGIN_URL ?>/rsevents/images/icons/calendar.png" id="EventStartDate_ico"/>
							  <script type="text/javascript">
								Calendar.setup({
								  inputField    : "EventStartDate",
								  button        : "EventStartDate_ico",
								  ifFormat      : "%Y-%m-%d",
								  align         : "Tl",
								  singleClick   :    true
								});
							  </script>
						(*)
					</td>
				</tr>
				<tr>
					<td>
						<label for="StartTime">
							<?php echo RSE_EVENT_START_TIME.':'; ?>
						</label>
					</td>
					<td>						
						<input name="EventStartDateH" value="<?php echo $event->EventStartDateH; ?>" size="3" maxlength="2" onkeyup="javascript:this.value=this.value.replace(/[^0-9]/g, '');" /> : <input name="EventStartDateM" value="<?php echo $event->EventStartDateM; ?>" size="3" maxlength="2" onkeyup="javascript:this.value=this.value.replace(/[^0-9]/g, '');" />
						<?php if($RSEConfig['enable.12format'] == 1) { ?>
							<input type="radio" <?php checked($event->EventAmPm1,0,true); ?> value="0" id="EventAmPm10" name="EventAmPm1"/>
							<label for="EventAmPm10">am</label>
							<input type="radio" <?php checked($event->EventAmPm1,1,true); ?> value="1" id="EventAmPm11" name="EventAmPm1"/>
							<label for="EventAmPm11">pm</label>
						<?php } ?>
					</td>
				</tr>
				<tr>
					<td>
						<label for="EndDate">
							<?php echo RSE_EVENT_END_DATE.':'; ?>
						</label>
					</td>
					<td>						
						<input type="text" id="EventEndDate" name="EventEndDate" value="<?php echo date('Y-m-d',empty($event->EventEndDate) ? time() : $event->EventEndDate); ?>" /> <img src="<?php echo WP_PLUGIN_URL ?>/rsevents/images/icons/calendar.png" id="EventEndDate_ico"/>
							  <script type="text/javascript">
								Calendar.setup({
								  inputField    : "EventEndDate",
								  button        : "EventEndDate_ico",
								  ifFormat      : "%Y-%m-%d",
								  align         : "Tl",
								  singleClick   :    true
								});
							  </script> (*)
					</td>
				</tr>
				<tr>
					<td>
						<label for="EndTime">
							<?php echo RSE_EVENT_END_TIME.':'; ?>
						</label>
					</td>
					<td>						
						<input name="EventEndDateH" value="<?php echo $event->EventEndDateH; ?>" size="3" maxlength="2" onkeyup="javascript:this.value=this.value.replace(/[^0-9]/g, '');" /> : <input name="EventEndDateM" value="<?php echo $event->EventEndDateM; ?>" size="3" maxlength="2" onkeyup="javascript:this.value=this.value.replace(/[^0-9]/g, '');" />
						<?php if($RSEConfig['enable.12format'] == 1) { ?>
							<input type="radio" <?php checked($event->EventAmPm2,0,true); ?> value="0" id="EventAmPm20" name="EventAmPm2"/>
							<label for="EventAmPm20">am</label>
							<input type="radio" <?php checked($event->EventAmPm2,1,true); ?> value="1" id="EventAmPm21" name="EventAmPm2"/>
							<label for="EventAmPm21">pm</label>
						<?php } ?>
					</td>
				</tr>
				<tr>
					<td>
						<label for="web">
							<?php echo RSE_EVENT_WEB.':'; ?>
						</label>
					</td>
					<td>						
						<input name="EventURL" value="<?php echo $event->EventURL; ?>" size="50" />
					</td>
				</tr>
				<tr>
					<td>
						<label for="phone">
							<?php echo RSE_EVENT_PHONE.':'; ?>
						</label>
					</td>
					<td>						
						<input name="EventPhone" value="<?php echo $event->EventPhone; ?>" size="50" />
					</td>
				</tr>
				<tr>
					<td>
						<label for="email">
							<?php echo RSE_EVENT_EMAIL.':'; ?>
						</label>
					</td>
					<td>						
						<input name="EventEmail" value="<?php echo $event->EventEmail; ?>" size="50" />
					</td>
				</tr>
				<tr>
					<td>
						<label for="access" title="<?php echo esc_js(RSE_EVENT_TYPE_INFO); ?>">
							<?php echo RSE_EVENT_OPTION_TYPE.':'; ?>
						</label>
					</td>
					<td>
						<input type="radio" <?php checked($event->EventType,0,true); ?> value="0" id="EventType0" name="EventType"/>
						<label for="EventType0"><?php echo RSE_PRIVATE; ?></label>
						<input type="radio" <?php checked($event->EventType,1,true); ?> value="1" id="EventType1" name="EventType"/>
						<label for="EventType1"><?php echo RSE_PUBLIC; ?></label>
					</td>
				</tr>
				<?php if($event->EventType == '0') { ?>
				<tr>
					<td width="200">
						<label for="privateUrl">
							<?php echo RSE_EVENT_OPTION_PRIVATE_URL.':'; ?>
						</label>
					</td>
					<td>
						<?php $pid = $wpdb->get_var("SELECT ID FROM `".$wpdb->prefix."posts` WHERE `post_content` LIKE '%[rsevents_page%' AND `post_status` = 'publish' LIMIT 1"); ?>
						<strong><a href="<?php echo get_bloginfo('wpurl').'/index.php?page_id='.$pid.'&view=events&task=show&id='.$id.'&privateUrl='.$event->EventPrivateUrl; ?>" target="_blank"><?php echo get_bloginfo('wpurl').'/index.php?page_id='.$pid.'&view=events&task=show&id='.$id.'&privateUrl='.$event->EventPrivateUrl; ?></a></strong> - (<a href="javascript:void(0);" onclick="rse_private('<?php echo $id; ?>');"><?php echo RSE_EVENT_GENERATE_PRIVATE_URL;?></a>)
					</td>
				</tr>
				<?php } ?>
				<?php if ($RSEConfig['enable.event.icon'] == 1) { ?>
				<tr>
					<td width="200">
						<label for="icon">
							<?php echo RSE_ICON.':'; ?>
						</label>
					</td>
					<td>
						<?php if ($event->EventIcon == '') { ?>
							<input type="file" name="icon" size="40"/> <input type="button" onclick="rswp_set_option('apply')" value="Upload" />
						<?php } else { ?>
							<img style="vertical-align:middle;" src="<?php echo WP_PLUGIN_URL; ?>/rsevents/images/thumbs/<?php echo str_replace('.jpg','_'.$RSEConfig['event.icon.small'].'.jpg',$event->EventIcon); ?>" /> <a href="javascript:void(0);" onclick="rse_del_ico(<?php echo $id; ?>)"><img src="<?php echo WP_PLUGIN_URL.'/rsevents/images/icons/delete.png'; ?>" /></a>
						<?php } ?>
					</td>
				</tr>
				<?php } ?>
			</table>
		</td>
	</tr>
</table>
<?php break; ?>

<?php case 'description': ?>

<script language="javascript" type="text/javascript">		
		tinyMCE.init({
			// General options
			mode : "exact",
			elements : "EventDescription",
			theme : "advanced",
			plugins : "style,layer,table,advimage,advlink,emotions,preview,searchreplace,directionality,noneditable,visualchars,nonbreaking,template,inlinepopups",

			// Theme options
			theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,styleselect,formatselect,fontselect,fontsizeselect",
			theme_advanced_buttons2 : "search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
			theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,|,ltr,rtl",
			theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,restoredraft",
			theme_advanced_toolbar_location : "top",
			theme_advanced_toolbar_align : "left",
			theme_advanced_statusbar_location : "bottom",
			theme_advanced_resizing : true,
		});
</script>

<table cellspacing="0" cellpadding="0" border="0" width="100%">
	<tr>
		<td valign="top">
			<table  class="widefat page">
				<tr>
					<td>
						<label for="description">
							<?php echo RSE_EVENT_DESCRIPTION.':'; ?>
						</label>
					</td>
					<td>
						<textarea id="EventDescription" name="EventDescription" cols="80" rows="20"><?php echo $event->EventDescription; ?></textarea>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<?php break; ?>
<?php case 'files': 
$files = RSEventsDataEvents::getFiles();
?>

<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td valign="top">
				<table  class="adminform">
					<tr>
						<td>
							<label for="input1">
								<?php echo RSE_EVENT_FILES.':'; ?>
							</label>
						</td>
						<td>
							<div id="files">
							<input type="file" name="files[]" size="40"/> <input type="button" onclick="rswp_set_option('apply');" value="Upload" />
							</div>
							<br/><a href="javascript:void(0);" onclick="newFile();return false;"><?php echo RSE_EVENT_ADD_FILES;?></a>
						</td>
					</tr>
				</table>
<?php if(!empty($files)) { ?>	
		<table class="widefat page">
			<thead>
				<tr>
					<th width="5">#</th>
					<th><?php echo  RSE_EVENT_FILES_NAME; ?></th>
					<th width="100"><?php echo  RSE_EVENT_FILES_DELETE; ?></th>
				</tr>
			</thead>
			<tbody>
	<?php
	$k = 0;
	for ($i=0,$n=count($files);$i<$n;$i++)
	{		
		$row =& $files[$i];
		$fname = !empty($row->FileName) ? $row->FileName : '---';
	?>
			<tr class="<?php echo "row$k"; ?>">
				<td><?php echo $row->IdFile; ?></td>
				<td><a href="<?php echo WP_PLUGIN_URL ?>/rsevents/files/<?php echo $row->FileLocation; ?>" class="thickbox"><?php echo $fname; ?></a></td>
				<td align="center"><a href="javascript:void(0);" onclick="rse_del_file('<?php echo $row->IdFile; ?>','<?php echo $row->IdEvent; ?>');"><img src="<?php echo WP_PLUGIN_URL.'/rsevents/images/icons/delete.png'; ?>" title="Delete" alt="Delete file"></a></td>
			</tr>
	<?php	$k=1-$k;
	}
	?>
			</tbody>
				</table>
<?php } ?>		
			</td>
		</tr>
	</table>

<?php break; ?>

<?php } ?>
<input type="hidden" name="option" value="" />
<input type="hidden" name="gid" value="" />
<input type="hidden" name="eid" value="" />
</form>

<?php break; ?>

<?php case 'eventrepeat':

$buttons = array('save','apply','cancel');
$id = isset($_GET['id']) ? $_GET['id'] : 0;
$data = RSEventsDataEvents::getRepeat();
$evname = $wpdb->get_var("SELECT EventName FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent =".$id);
?>

<h2><?php echo RSE_REPEAT_FOR.' '.$evname; ?></h2>
<div class="clear"></div>
<?php echo RSEMessages::show($message); ?>

<script type="text/javascript">
function selectall() 
{
	for ( i=0; i<document.getElementById('EventRepeatAlso').options.length; i++)
	{	
	document.getElementById('EventRepeatAlso').options[i].selected = true;
	}
}

function rswp_submitform()
{
	var form = document.adminForm;
	if(form.option.value == 'cancel') 
	{	
		form.option.value = 'cancel'; 
		form.submit();
	} else 
	{
		ret = true;
		if(form.EventRepeatNumber.value <= 0) { form.EventRepeatNumber.className = 'rswpError'; ret=false; } else { form.EventRepeatNumber.className = '';  }	
		if(ret) { selectall(); form.submit(); }
	}
	return false;
	 
}

function addOption(from,to)
{
	var found = false;
	
	for(i=0;i<to.length;i++)
		if(to[i].value == from.value)
			found = true;
	
	if (!found)
		to.options[to.options.length] = new Option( from.value, from.value, false, false);
}

function removeOption(from)
{
	if (from.options.selectedIndex == -1) return false;
	for(i=from.length-1; i>=0;i--)
		if (from.options[i].selected)
			from.remove(from.options[i].index);
}

</script>
<form action="" method="post" enctype="multipart/form-data" name="adminForm" id="adminForm">
<?php echo RSEventsHelper::makeButtons($buttons); ?>
<?php
echo '	<script type="text/javascript" src="'.WP_PLUGIN_URL.'/rsevents/assets/calendar/calendar.js"></script>
		<script type="text/javascript" src="'.WP_PLUGIN_URL.'/rsevents/assets/calendar/calendar-setup.js"></script>
		<script type="text/javascript" src="'.WP_PLUGIN_URL.'/rsevents/assets/calendar/calendar-en.js"></script>
		<style type="text/css"> @import url("'.WP_PLUGIN_URL.'/rsevents/assets/calendar/skins/tiger/theme.css"); </style>';
?>
<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td valign="top">
				<table  class="widefat page">
					<tr>
						<td width="200">
							<label for="recurency">
								<?php echo RSE_ENABLE_REPEAT.':'; ?>
							</label>
						</td>
						<td>
							<input type="radio" <?php checked($data->EventEnableRepeat,0,true); ?> value="0" id="EventEnableRepeat0" name="EventEnableRepeat"/>
							<label for="EventEnableRepeat0"><?php echo RSE_NO; ?></label>
							<input type="radio" <?php checked($data->EventEnableRepeat,1,true); ?> value="1" id="EventEnableRepeat1" name="EventEnableRepeat"/>
							<label for="EventEnableRepeat1"><?php echo RSE_YES; ?></label>
						</td>
					</tr>
					<tr>
						<td width="200">
							<label for="repeat">
								<?php echo RSE_REPEAT_METHOD.':'; ?>
							</label>
						</td>
						<td>
							<input type="text" name="EventRepeatNumber" value="<?php echo $data->EventRepeatNumber;?>" size="2" maxlength="2" onkeyup="javascript:this.value=this.value.replace(/[^0-9]/g, '');" /> &nbsp;&nbsp;
							<select size="1" id="EventRepeatType" name="EventRepeatType">
								<option <?php selected($data->EventRepeatType,0,true); ?> value="0"><?php echo RSE_SELECT_TYPE; ?></option>
								<option <?php selected($data->EventRepeatType,1,true); ?> value="1"><?php echo RSE_REPEAT_DAYS; ?></option>
								<option <?php selected($data->EventRepeatType,2,true); ?> value="2"><?php echo RSE_REPEAT_WEEKS; ?></option>
								<option <?php selected($data->EventRepeatType,3,true); ?> value="3"><?php echo RSE_REPEAT_MONTHS; ?></option>
								<option <?php selected($data->EventRepeatType,4,true); ?> value="4"><?php echo RSE_REPEAT_YEARS; ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<td width="200">
							<label for="until">
								<?php echo RSE_REPEAT_UNTIL.':'; ?>
							</label>
						</td>
						<td>
							 <input type="text" id="EventRepeatUntil" name="EventRepeatUntil" value="<?php echo date('Y-m-d',empty($data->EventRepeatUntil) ? time() : $data->EventRepeatUntil); ?>" /> <img src="<?php echo WP_PLUGIN_URL ?>/rsevents/images/icons/calendar.png" id="EventRepeatUntil_ico"/>
							  <script type="text/javascript">
								Calendar.setup({
								  inputField    : "EventRepeatUntil",
								  button        : "EventRepeatUntil_ico",
								  ifFormat      : "%Y-%m-%d",
								  align         : "Tl",
								  singleClick   :    true
								});
							  </script>
						</td>
					</tr>
					<tr>
						<td width="200">
							<label for="EventRepeatAlso">
								<?php echo RSE_REPEAT_ALSO.':'; ?>
							</label>
						</td>
						<td>
							<table width="100%">
								<tr>
									<td>
										<select multiple="multiple" style="height:15em;" size="10" id="EventRepeatAlso" name="EventRepeatAlso[]">
											<?php $dates = $wpdb->get_var("SELECT EventRepeatAlso FROM ".$wpdb->prefix."rsevents_events WHERE IdEvent =".$id); 
													if(!empty($dates))
													{
														$dates = explode(',',$dates);
														foreach($dates as $date)
															echo '<option value="'.date('Y-m-d',$date).'">'.date('Y-m-d',$date).'</option>';
													}
											?>
										</select>
									</td>
									<td>
										<input type="button" name="repeatbutton" value="&laquo;" onclick="addOption(document.getElementById('RepeatAlso'),document.getElementById('EventRepeatAlso'));"/> <br/><br/>
										<input type="button" name="repeatbutton1" value="&raquo;" onclick="removeOption(document.getElementById('EventRepeatAlso'));"/>
									</td>
									<td>
										<input type="text" id="RepeatAlso" name="RepeatAlso" value="<?php echo date('Y-m-d',empty($data->RepeatAlso) ? time() : $data->RepeatAlso); ?>" /> <img src="<?php echo WP_PLUGIN_URL ?>/rsevents/images/icons/calendar.png" id="RepeatAlso_ico"/>
									  <script type="text/javascript">
										Calendar.setup({
										  inputField    : "RepeatAlso",
										  button        : "RepeatAlso_ico",
										  ifFormat      : "%Y-%m-%d",
										  align         : "Tl",
										  singleClick   :    true
										});
									  </script>
									</td>
								</tr>
							</table>							
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
<input type="hidden" name="option" value="" />
<input type="hidden" name="view" value="repeat" />
</form>

<?php break; ?>
<?php } ?>

</div>