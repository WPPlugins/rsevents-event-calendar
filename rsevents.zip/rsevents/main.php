<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');

$message = isset($_GET['message']) ? $_GET['message'] : '';
echo RSEMessages::show($message);
?>

<div class="wrap">
<br/><br/>
<form action="admin.php?page=rsevents" method="post" name="adminForm">
<table class="thisform">
		<tr class="thisform">
  		<td width="50%" valign="top" class="thisform">
  			<table width="100%" class="thisform2" border="1">
  				<tr class="thisform2">
      				<td align="center" height="100px" width="33%" class="thisform2">
      				<div align="center">
			            <a href="admin.php?page=rse_events" style="text-decoration:none;" title="<?php echo RSE_EVENT_MANAGER; ?>">
			            <img src="<?php echo WP_PLUGIN_URL; ?>/rsevents/images/icons/events.png" width="48px" height="48px" align="middle" border="0"/>
			            <br />
			            <?php echo RSE_EVENT_MANAGER; ?>
			            </a>
			        </div>
					</td>
      				<td align="center" height="100px" class="thisform2">
			            <a href="admin.php?page=rse_locations" style="text-decoration:none;" title="<?php echo RSE_LOCATIONS; ?>">
			            <img src="<?php echo WP_PLUGIN_URL; ?>/rsevents/images/icons/locations.png" width="48px" height="48px" align="middle" border="0"/>
			            <br />
			            <?php echo RSE_LOCATIONS; ?>
			            </a>
					</td>
					<td height="100" align="center" class="thisform2">
			            <a title="<?php echo RSE_SETTINGS; ?>" style="text-decoration: none;" href="admin.php?page=rse_settings">
			            <img width="48" height="48" border="0" align="middle" src="<?php echo WP_PLUGIN_URL; ?>/rsevents/images/icons/settings.png"/>
			            <br/><?php echo RSE_SETTINGS; ?></a>
					</td>
				</tr>
  				<tr class="thisform2">
      				<td height="100" align="center" class="thisform2"></td>
					<td></td>
					<td></td>
				</tr>
				<tr class="thisform2">
					<td height="100" align="center" class="thisform2"></td>
					<td></td>
					<td></td>
				</tr>
			</table>

		</td>
	    <td width="50%" valign="top" align="center">

		    <table border="1" width="100%" class="thisform">
				<tr class="thisform">
		            <th class="cpanel" colspan="2"><?php echo RSE_PRODUCT.' '.RSE_VERSION;?></th></td>
		         </tr>
		         <tr class="thisform"><td bgcolor="#FFFFFF" colspan="2"><br />
		      <div style="width=100%" align="center">
		      <img src="<?php echo WP_PLUGIN_URL; ?>/rsevents/images/rs_events_logo.jpg" align="middle" alt="RSEvents! Logo"/>
		      <br /><br /></div>
		      </td></tr>
		         <tr class="thisform">
		            <td width="120" bgcolor="#FFFFFF"><?php echo RSE_INSTALLED_VERSION; ?></td>
		            <td bgcolor="#FFFFFF"><?php echo RSE_VERSION;?></td>
		         </tr>
		         <tr class="thisform">
		            <td bgcolor="#FFFFFF"><?php echo RSE_COPYRIGHT_NAME; ?></td>
		            <td bgcolor="#FFFFFF"><?php echo RSE_COPYRIGHT;?></td>
		         </tr>
		         <tr class="thisform">
		            <td bgcolor="#FFFFFF"><?php echo RSE_LICENSE_NAME; ?></td>
		            <td bgcolor="#FFFFFF"><?php echo RSE_LICENSE;?></td>
		         </tr>
		         <tr class="thisform">
		            <td valign="top" bgcolor="#FFFFFF"><?php echo RSE_AUTHOR_NAME; ?></td>
		            <td bgcolor="#FFFFFF">
		            <?php echo RSE_AUTHOR;?>
					</td>
		         </tr>
		      </table>
			<br/>
			</td>
	   </tr>
	</table>
</form>
</div>