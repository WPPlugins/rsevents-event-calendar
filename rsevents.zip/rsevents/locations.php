<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');
require_once(WP_PLUGIN_DIR.'/rsevents/controllers/locations.php');
require_once(WP_PLUGIN_DIR.'/rsevents/data/locations.php');
require_once(WP_PLUGIN_DIR.'/rsevents/data/pagination.php');

$task = isset($_GET['task']) ? $_GET['task'] : ''; 
$message = isset($_GET['message']) ? $_GET['message'] : ''; 

/*  Do Actions  */
$option = isset($_POST['option']) ? $_POST['option'] : '';
$published = isset($_POST['generalid']) ? intval($_POST['generalid']) : '';
$cids = isset($_POST['cid']) ? $_POST['cid'] : '';
if(isset($option) && $option == 'delete') RSEventsLocations::delete($cids);
if(isset($option) && $option == 'edit') RSEventsLocations::addedit($cids);
if(isset($option) && $option == 'cancel') RSEventsLocations::cancel();
if(isset($option) && ($option == 'apply' || $option == 'save')) RSEventsLocations::save();
if(!empty($option) && isset($published) && ($option == 'publish' || $option == 'unpublish'))  RSEventsLocations::publish($published,$option);
?>

<div class="wrap">
<?php 
switch($task) {
default:  case '':

$buttons = array('addedit','delete'); 
$data = RSEventsDataLocations::getData();
$total = RSEventsDataLocations::getTotal();
$limit = isset($_POST['limit']) ? intval($_POST['limit']) : 15;
$limitstart = isset($_POST['limitstart']) ? intval($_POST['limitstart']) : 0;
$pagination = new RSPagination($total->nr,$limitstart,$limit); 
?>

<h2><?php echo RSE_LOCATIONS; ?></h2>
<div class="clear"></div>
<?php echo RSEMessages::show($message); ?>

<form action="" method="post" name="adminForm">
<?php echo RSEventsHelper::makeButtons($buttons); ?>
	<table>
		<tr>
			<td><?php echo RSE_FILTER; ?> <input type="text" name="rs_filter" id="rs_filter" class="text_area" value="<?php echo @$_POST['rs_filter']; ?>"/> <input type="button" value="<?php echo RSE_FILTER; ?>" onclick="createFilter(document.getElementById('rs_filter').value);return false;" /> <input type="button" onclick="eraseFilter();" value="<?php echo RSE_CLEAR_FILTER; ?>" />
			</td>
		</tr>
	</table>
	<div id="editcell1">
		<table class="widefat page" width="100%">
			<thead>
			<tr>
				<th width="1%">#</th>
				<th width="1%"><input type="checkbox" name="toggle" value="" onclick="rswp_checkAll(<?php echo count($data); ?>);"/></th>
				<th width="50%"><?php echo RSE_LOCATION_NAME_DEFAULT; ?></th>
				<th width="3%"><?php echo RSE_PUBLISHED; ?></th>
			</tr>
			</thead>
	<?php
	$k = 0;
	for ($i=0,$n=count($data);$i<$n;$i++)
	{
		$row =& $data[$i];
		$locationname = empty($row->LocationName) ? RSE_NONAME : $row->LocationName;
	?>
			<tr class="<?php echo "row$k"; ?>">
				<td><?php echo $row->IdLocation; ?></td>
				<td align="center"><input type="checkbox" onclick="rswp_isChecked(this.checked);" id="cb<?php echo $i; ?>" value="<?php echo $row->IdLocation; ?>" name="cid[]" /></td>
				<td><?php echo '<a href="admin.php?page=rse_locations&task=edit&id='.$row->IdLocation.'">'.$locationname.'</a>'; ?></td>
				<td align="center"><?php echo RSEventsHelper::isPublished($wpdb->prefix.'rsevents_locations','IdLocation',$row->IdLocation); ?></td>
			</tr>
	<?php
		$k=1-$k;
	}
	?>
		<tfoot>
			<tr>
				<td colspan="5"><?php echo $pagination->getPagination(); ?></td>
			</tr>
		</tfoot>
		</table>
	</div>
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="generalid" value="" />
<input type="hidden" name="option" value="" />
<input type="hidden" name="rs_filter" value="" id="filter" />
</form>
<?php break; ?>
<?php case 'edit': ?>

<?php 
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
RSEventsDataLocations::checkDB();
$buttons = array('apply','save','cancel');
$location = RSEventsDataLocations::getLocation($id);
?>

<h2><?php echo ($id == 0) ? RSE_LOCATION_NEW : RSE_LOCATION_EDIT; ?></h2>
<div class="clear"></div>
<?php echo RSEMessages::show($message); ?>
<script language="javascript" type="text/javascript">
function rswp_submitform()
{
	var form = document.adminForm;
	if(form.option.value == 'cancel') 
	{	
		form.option.value = 'cancel'; 
		form.submit();
	} else 
	{
		ret = true;
		if(form.LocationName.value=='') { form.LocationName.className = 'rswpError'; ret=false; } else { form.LocationName.className = '';  }	
		if(form.LocationAddress.value=='') { form.LocationAddress.className = 'rswpError'; ret=false; } else { form.LocationAddress.className = '';  }	
		if(ret) form.submit();
	}
	return false;
	 
}

tinyMCE.init({
	// General options
	mode : "exact",
	elements : "LocationDescription",
	theme : "advanced",
	plugins : "style,layer,table,advimage,advlink,emotions,preview,searchreplace,directionality,noneditable,visualchars,nonbreaking,template,inlinepopups",

	// Theme options
	theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,styleselect,formatselect,fontselect,fontsizeselect",
	theme_advanced_buttons2 : "search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
	theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,|,ltr,rtl",
	theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,restoredraft",
	theme_advanced_toolbar_location : "top",
	theme_advanced_toolbar_align : "left",
	theme_advanced_statusbar_location : "bottom",
	theme_advanced_resizing : true,
});

</script>
<form action="" method="post" name="adminForm" id="adminForm">
<?php echo RSEventsHelper::makeButtons($buttons); ?>
	<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td valign="top">
				<table  class="widefat page">
					<tr>
						<td>
							<label for="published">
								<?php echo RSE_PUBLISHED.':'; ?>
							</label>
						</td>
						<td>						
							<input type="radio" <?php checked($location->published,0,true); ?> value="0" id="published0" name="published"/>
							<label for="published0"><?php echo RSE_NO; ?></label>
							<input type="radio" <?php checked($location->published,1,true); ?> value="1" id="published1" name="published"/>
							<label for="published1"><?php echo RSE_YES; ?></label>
						</td>
					</tr>
					<tr>
						<td>
							<label for="name">
								<?php echo RSE_LOCATION_NAME.':'; ?>
							</label>
						</td>
						<td>						
							<input name="LocationName" value="<?php echo $location->LocationName; ?>" size="50" maxlength="100" /> (*)
						</td>
					</tr>
					<tr>
						<td>
							<label for="weburl">
								<?php echo RSE_LOCATION_URL.':'; ?>
							</label>
						</td>
						<td>						
							<input name="LocationURL" value="<?php echo $location->LocationURL; ?>" size="50" maxlength="100" />
						</td>
					</tr>
					<tr>
						<td>
							<label for="address">
								<?php echo RSE_LOCATION_ADDRESS.':'; ?>
							</label>
						</td>
						<td>						
							<input name="LocationAddress" value="<?php echo $location->LocationAddress; ?>" size="50"  /> (*)
						</td>
					</tr>
					<tr>
						<td>
							<label for="zip">
								<?php echo RSE_LOCATION_ZIP.':'; ?>
							</label>
						</td>
						<td>						
							<input name="LocationZip" value="<?php echo $location->LocationZip; ?>" size="50" maxlength="100" />
						</td>
					</tr>
					<tr>
						<td>
							<label for="city">
								<?php echo RSE_LOCATION_CITY.':'; ?>
							</label>
						</td>
						<td>						
							<input name="LocationCity" value="<?php echo $location->LocationCity; ?>" size="50" maxlength="100" />
						</td>
					</tr>
					<tr>
						<td>
							<label for="state">
								<?php echo RSE_LOCATION_STATE.':'; ?>
							</label>
						</td>
						<td>						
							<input name="LocationState" value="<?php echo $location->LocationState; ?>" size="50" maxlength="100" />
						</td>
					</tr>
					<tr>
						<td>
							<label for="country">
								<?php echo RSE_LOCATION_COUNTRY.':'; ?>
							</label>
						</td>
						<td>						
							<input name="LocationCountry" value="<?php echo $location->LocationCountry; ?>" size="50" maxlength="100" />
						</td>
					</tr>
					<tr>
						<td>
							<label for="description">
								<?php echo RSE_LOCATION_DESCRIPTION.':'; ?>
							</label>
						</td>
						<td>
							<textarea id="LocationDescription" name="LocationDescription" cols="80" rows="20"><?php echo $location->LocationDescription; ?></textarea>							
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
<input type="hidden" name="option" value="" />
</form>
<?php break; ?>
<?php } ?>

</div>