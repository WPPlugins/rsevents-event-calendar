<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */
/*
Plugin Name: RSEvents!
Plugin URI: http://www.rsplugins.com/
Description:With RSEvents! you can organize events, invite people , sell tickets and keep track of transactions , customize events with music , videos , use custom designs for each event you organize and much more.
Author: RSPlugins.com
Version: 1.0.0
Author URI: http://www.rsplugins.com/
*/

ob_start();

//do not enter 
defined('ABSPATH') or die('<h1>Permission denied!</h1>');
if(!defined('_RSWP')) define('_RSWP',1);

define('RSE_PRODUCT','RSEvents!');
define('RSE_VERSION','1.0.0');
define('RSE_COPYRIGHT','&copy;2010 www.rsplugins.com');
define('RSE_LICENSE','GPL License');
define('RSE_AUTHOR','<a href="http://www.rsplugins.com" target="_blank">www.rsplugins.com</a>');

//load the helper
require_once(WP_PLUGIN_DIR.'/rsevents/data/helper.php');
//load message file
require_once(WP_PLUGIN_DIR.'/rsevents/data/messages.php');

//Only for debugging
//error_reporting(E_ALL);
//ini_set('display_errors',true);

//include the language files
$lang = (WPLANG == '') ? 'en' : WPLANG;
if(is_file(WP_PLUGIN_DIR.'/rsevents/lang/'.$lang.'.php'))
	include(WP_PLUGIN_DIR.'/rsevents/lang/'.$lang.'.php');
else include(WP_PLUGIN_DIR.'/rsevents/lang/en.php');

//read the settings
rsevents_read_settings();


add_action('admin_menu', 'rsevents');

function rsevents()
{
  add_menu_page('RSEvents!', 'RSEvents!', 'administrator', 'rsevents', 'rsevents_main',WP_PLUGIN_URL.'/rsevents/images/rs_events_icon.gif');
  add_submenu_page('rsevents', 'Events', 'Events', 'administrator', 'rse_events', 'rsevents_events');
  add_submenu_page('rsevents', 'Locations', 'Locations', 'administrator', 'rse_locations', 'rsevents_locations');
  add_submenu_page('rsevents', 'Settings', 'Settings', 'administrator', 'rse_settings', 'rsevents_settings');
  
}

function rsevents_main()
{
	global $wpdb;
	if(!defined('_RSWP')) define('_RSWP',1);
	require_once(WP_PLUGIN_DIR . '/rsevents/main.php');
}

function rsevents_events()
{
	global $wpdb,$RSEventsConfig;
	if(!defined('_RSWP')) define('_RSWP',1);
	$RSEConfig = rsevents_get_settings();
	require_once( WP_PLUGIN_DIR . '/rsevents/events.php');
}

function rsevents_locations()
{
	global $wpdb;
	if(!defined('_RSWP')) define('_RSWP',1);
	$RSEConfig = rsevents_get_settings();
	require_once( WP_PLUGIN_DIR . '/rsevents/locations.php');
}

function rsevents_settings()
{
	global $wpdb;
	if(!defined('_RSWP')) define('_RSWP',1);
	$RSEConfig = rsevents_get_settings();
	require_once( WP_PLUGIN_DIR . '/rsevents/settings.php');
}

function rsevents_read_settings()
{
	global $RSEventsConfig;
	global $wpdb;
	
	$configs = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."rsevents_config",OBJECT);
	foreach($configs as $config)
		$RSEventsConfig[$config->ConfigName] = $config->ConfigValue;
}

function rsevents_get_settings($setting=null)
{
	global $RSEventsConfig;
	if ($setting == null)
		return $RSEventsConfig;
	
	if (isset($RSEventsConfig[$setting]))
		return $RSEventsConfig[$setting];
	
	return false;
}

function rse_frontend($args)
{
	global $wpdb,$rseargs,$wp_query,$RSEventsConfig,$userdata;
	
	$rseargs = $args;
	
	if(isset($_GET['view']))
	{
		$defaults = array('calendar','locations','events');
		
		$view = $_GET['view'];
		if(!in_array($view,$defaults)) $view = 'events';
		
	} elseif(isset($args['view']))
		$view = $args['view'];
	else $view = 'events';
	
	$msgid = isset($_GET['message']) ? $_GET['message'] : ''; 
	echo RSEMessages::show($msgid);
	
	require_once( WP_PLUGIN_DIR . '/rsevents/frontend/controller.php');
	require_once( WP_PLUGIN_DIR . '/rsevents/frontend/data.php');
	require_once( WP_PLUGIN_DIR . '/rsevents/frontend/'.$view.'.php');
}

add_shortcode('rsevents_page', 'rse_frontend');


/* SCRIPT AREA */

	function rse_b_scripts()
	{
		if(is_admin())
		{
			$url = get_bloginfo('wpurl').'/wp-content/plugins/rsevents/assets/'; 	
			wp_enqueue_style('style',$url.'css/style.css');
			wp_enqueue_script('script',$url.'js/script.js');
			
		}
	}

	function STMCE() 
	{
		// conditions here
		if (function_exists('add_thickbox')) add_thickbox();
		$url = get_bloginfo('wpurl').'/wp-content/plugins/rsevents/assets/';
		echo '<script type="text/javascript" src="' .$url. 'editor/tiny_mce.js" /></script>' . "\n";	
		do_action("admin_print_styles-post-php");
		do_action('admin_print_styles');
	}
	
	function rse_add_thickbox()
	{
		add_thickbox();
	?>
		<script type="text/javascript">
		/* <![CDATA[ */
		var tb_pathToImage = '<?php echo esc_js( includes_url( '/js/thickbox/loadingAnimation.gif' ) ); ?>';
		var tb_closeImage = '<?php echo esc_js( includes_url( '/js/thickbox/tb-close.png' ) ); ?>';
		/* ]]> */
		</script>
<?php	
	}

	function rse_f_scripts() 
	{
		wp_print_scripts('jquery');
		$url = get_bloginfo('wpurl').'/wp-content/plugins/rsevents/assets/css/'; 
		echo '<link type="text/css" rel="stylesheet" href="' .$url. 'frontend.css" />' . "\n";	
		$url = get_bloginfo('wpurl').'/wp-content/plugins/rsevents/assets/'; 
		echo '<script type="text/javascript" src="' .$url. 'editor/tiny_mce.js" /></script>' . "\n";		
		echo '<script type="text/javascript" src="' .$url. 'js/script.js" /></script>' . "\n";

		?>
		
	<?php
	}

	function rswp_tooltip()
	{
		$url = get_bloginfo('wpurl').'/wp-content/plugins/rsevents/assets/'; 
		echo '<script type="text/javascript" src="' .$url. 'js/wz_tooltip.js" /></script>' . "\n";
	}

add_filter('admin_head','STMCE');
add_action( 'wp_footer', 'rswp_tooltip');
add_action( 'wp_head', 'rse_f_scripts');
add_action('wp_print_scripts', 'rse_b_scripts');
add_action( 'wp_head', 'rse_add_thickbox', 0 );



function rsevents_install()
{
	global $wpdb;
	if(!defined('_RSWP')) define('_RSWP',1);
	require_once(WP_PLUGIN_DIR.'/rsevents/sql/install.php');
}

function rsevents_uninstall()
{
	global $wpdb;
	if(!defined('_RSWP')) define('_RSWP',1);
	require_once(WP_PLUGIN_DIR.'/rsevents/sql/uninstall.php');
}

register_activation_hook(__FILE__, 'rsevents_install');
register_uninstall_hook(__FILE__, 'rsevents_uninstall');

?>