<?php
/**
 * @package RSEvents!
 * @author RSPlugins.com
 * @version 1.0.0
 */

defined('_RSWP') or die('<h1>Permission denied!</h1>');
require_once(WP_PLUGIN_DIR.'/rsevents/controllers/settings.php');
require_once(WP_PLUGIN_DIR.'/rsevents/data/settings.php');

$subpage = isset($_GET['subpage']) ? $_GET['subpage'] : 'general';
$message = isset($_GET['message']) ? $_GET['message'] : ''; 
$buttons = array('save','apply','cancel');


/*  Do Actions  */
$option = isset($_POST['option']) ? $_POST['option'] : '';
if(!empty($option) && ($option == 'save' || $option == 'apply')) RSEventsSettings::save($option); 
if(!empty($option) && $option == 'cancel') RSEventsSettings::cancel();
?>

<div class="wrap">
<h2><?php echo RSE_SETTINGS; ?></h2>
<div class="clear"></div>
<?php echo RSEMessages::show($message); ?>

<?php RSEventsDataSettings::subpage(); ?>

<form action="" method="post" name="adminForm">
<?php echo RSEventsHelper::makeButtons($buttons); ?>
<?php switch($subpage) { ?>
<?php default: case 'general': { ?>

<table cellspacing="0" cellpadding="0" border="0" width="100%">
	<tr>
		<td valign="top">
			<table  class="widefat page">
				<tr>
					<td width="200">
						<label for="date">
							<?php echo RSE_DATE_FORMAT.':'; ?>
						</label>
					</td>
					<td>
						<input type="text" name="rseventsConfig[global.dateformat]" value="<?php echo $RSEConfig['global.dateformat'];  ?>" size="55" maxlength="50">
					</td>
				</tr>
				<tr>
					<td width="200">
						<label for="debug">
							<?php echo RSE_12H.':'; ?>
						</label>
					</td>
					<td>
						<input type="radio" value="0" <?php checked($RSEConfig['enable.12format'],0,true); ?> id="enable.12format0" name="rseventsConfig[enable.12format]"/>
							<label for="enable.12format0"><?php echo RSE_NO; ?></label>
						<input type="radio" value="1" <?php checked($RSEConfig['enable.12format'],1,true); ?> id="enable.12format1" name="rseventsConfig[enable.12format]"/>
							<label for="enable.12format1"><?php echo RSE_YES; ?></label>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<?php } break; ?>
<?php case 'events': { ?>

<br/>
<strong><?php echo RSE_EVENT_INTRO; ?><br/></strong>
<table cellspacing="0" cellpadding="0" border="0" width="100%" class="widefat page">
	<tr>
		<td width="10%">
			<label for="layouts">
				<?php echo RSE_SELECT_INTRO_LAYOUT.' : '; ?>
			</label>
		</td>
		<td>
			<select size="1" onchange="rse_changeLayout(this.value);" id="rseventsConfigevents.layout" name="rseventsConfig[events.layout]">
				<option <?php selected($RSEConfig['events.layout'],0,true); ?> value="0"><?php echo RSE_SELECT_LAYOUT; ?></option>
				<option <?php selected($RSEConfig['events.layout'],1,true); ?> value="1"><?php echo RSE_DEFAULT_LAYOUT; ?></option>
				<option <?php selected($RSEConfig['events.layout'],2,true); ?> value="2"><?php echo RSE_TABLE_LAYOUT; ?></option>
			</select>
		</td>
	</tr>
	<tr>
		<td width="13%">
			<label for="layouts">
				<?php echo RSE_EVENTS_PER_PAGE.' : '; ?>
			</label>
		</td>
		<td>
			<input type="text" size="3" name="rseventsConfig[events.perpage]" value="<?php echo $RSEConfig['events.perpage']; ?>" onkeyup="javascript:this.value=this.value.replace(/[^0-9]/g, '');" />
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<textarea id="layoutArea" name="rseventsConfig[layouts.eventintro]" rows="10" cols="100%"><?php echo $RSEConfig['layouts.eventintro']; ?></textarea>
		</td>
	</tr>
</table>
<br/>
<strong><?php echo RSE_GUEST_MENU_OPTIONS; ?></strong>
<table cellspacing="0" cellpadding="0" border="0" width="100%" class="widefat page">
	<tr>
		<td width="10%">
			<label for="invite">
				<?php echo RSE_SHOW_INVITE.' : '; ?>
			</label>
		</td>
		<td>
			<input type="radio" value="0" <?php checked($RSEConfig['event.show.invite'],0,true); ?> id="event.show.invite0" name="rseventsConfig[event.show.invite]"/>
				<label for="event.show.invite0"><?php echo RSE_NO; ?></label>
			<input type="radio" value="1" <?php checked($RSEConfig['event.show.invite'],1,true); ?> id="event.show.invite1" name="rseventsConfig[event.show.invite]"/>
				<label for="event.show.invite1"><?php echo RSE_YES; ?></label>
		</td>
	</tr>
	<tr>
		<td width="10%">
			<label for="outlook">
				<?php echo RSE_SHOW_OUTLOOK.' : '; ?>
			</label>
		</td>
		<td>
			<input type="radio" value="0" <?php checked($RSEConfig['event.show.outlook'],0,true); ?> id="event.show.outlook0" name="rseventsConfig[event.show.outlook]"/>
				<label for="event.show.outlook0"><?php echo RSE_NO; ?></label>
			<input type="radio" value="1" <?php checked($RSEConfig['event.show.outlook'],1,true); ?> id="event.show.outlook1" name="rseventsConfig[event.show.outlook]"/>
				<label for="event.show.outlook1"><?php echo RSE_YES; ?></label>
		</td>
	</tr>
</table>
<br/>
<strong><?php echo RSE_ICON_SHOW; ?></strong>
<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td valign="top">
				<table  class="widefat page">
					<tr>
						<td width="200">
							<label for="enableicon">
								<?php echo RSE_ENABLE_ICON.':'; ?>
							</label>
						</td>
						<td>
							<input type="radio" <?php checked($RSEConfig['enable.event.icon'],0,true); ?> value="0" id="enable.event.icon0" name="rseventsConfig[enable.event.icon]"/>
							<label for="enable.event.icon0"><?php echo RSE_NO; ?></label>
							<input type="radio" <?php checked($RSEConfig['enable.event.icon'],1,true); ?> value="1" id="enable.event.icon1" name="rseventsConfig[enable.event.icon]"/>
							<label for="enable.event.icon1"><?php echo RSE_YES; ?></label>
						</td>
					</tr>
					<tr>
						<td width="200">
							<label for="sicon">
								<?php echo RSE_SMALL_ICON.':'; ?>
							</label>
						</td>
						<td>
							<input type="text" name="rseventsConfig[event.icon.small]" value="<?php echo $RSEConfig['event.icon.small']; ?>" size="5"  maxlength="4" /> px
						</td>
					</tr>
					<tr>
						<td width="200">
							<label for="bicon">
								<?php echo RSE_BIG_ICON.':'; ?>
							</label>
						</td>
						<td>
							<input type="text" name="rseventsConfig[event.icon.big]" value="<?php echo $RSEConfig['event.icon.big']; ?>" size="5" maxlength="4" /> px
						</td>
					</tr>
				</table>
			</td>
		</tr>
</table>
<br/>
<strong><?php echo RSE_FILES_ALLOWED; ?></strong>
<table cellspacing="0" cellpadding="0" border="0" width="100%">
		<tr>
			<td valign="top">
				<table  class="widefat page">
					<tr>
						<td width="200">
							<label for="extensions">
								<?php echo RSE_EXTENSIONS.':'; ?>
							</label>
						</td>
						<td>
							<textarea name="rseventsConfig[event.files]" rows="5" cols="30%"><?php echo $RSEConfig['event.files'] ; ?></textarea>
						</td>
					</tr>
				</table>
			</td>
		</tr>
</table>
<br/>

<?php } break; ?>
<?php case 'emails': { ?>

<table cellspacing="0" cellpadding="0" border="0" width="100%">
	<tr>
		<td valign="top">
			<table  class="widefat page">
				<tr>
					<td width="100">
						<label for="from">
							<?php echo RSE_EMAIL_FROM.':'; ?>
						</label>
					</td>
					<td>
						<input type="text" name="rseventsConfig[emails.from]" value="<?php echo $RSEConfig['emails.from'];  ?>" size="55" />
					</td>
				</tr>
				<tr>
					<td width="100">
						<label for="fromName">
							<?php echo RSE_EMAIL_FROM_NAME.':'; ?>
						</label>
					</td>
					<td>
						<input type="text" name="rseventsConfig[emails.from.name]" value="<?php echo $RSEConfig['emails.from.name'];  ?>" size="55" />
					</td>
				</tr>
				<tr>
					<td width="100">
						<label for="reply">
							<?php echo RSE_EMAIL_REPLY.':'; ?>
						</label>
					</td>
					<td>
						<input type="text" name="rseventsConfig[emails.reply]" value="<?php echo $RSEConfig['emails.reply'];  ?>" size="55" />
					</td>
				</tr>
				<tr>
					<td width="100">
						<label for="cc">
							<?php echo 'CC:'; ?>
						</label>
					</td>
					<td>
						<input type="text" name="rseventsConfig[emails.cc]" value="<?php echo $RSEConfig['emails.cc'];  ?>" size="55" />
					</td>
				</tr>
				<tr>
					<td width="100">
						<label for="cc">
							<?php echo 'BCC:'; ?>
						</label>
					</td>
					<td>
						<input type="text" name="rseventsConfig[emails.bcc]" value="<?php echo $RSEConfig['emails.bcc'];  ?>" size="55" />
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br/>

<script type="text/javascript">
tinyMCE.init({
	// General options
	mode : "exact",
	elements : "rseventsConfig[emails.invite.content]",
	theme : "advanced",
	plugins : "style,layer,table,advimage,advlink,emotions,preview,searchreplace,directionality,noneditable,visualchars,nonbreaking,template,inlinepopups",

	// Theme options
	theme_advanced_buttons1 : "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,|,styleselect,formatselect,fontselect,fontsizeselect",
	theme_advanced_buttons2 : "search,replace,|,bullist,numlist,|,outdent,indent,blockquote,|,undo,redo,|,link,unlink,anchor,image,cleanup,help,code,|,insertdate,inserttime,preview,|,forecolor,backcolor",
	theme_advanced_buttons3 : "tablecontrols,|,hr,removeformat,visualaid,|,sub,sup,|,charmap,emotions,|,ltr,rtl",
	theme_advanced_buttons4 : "insertlayer,moveforward,movebackward,absolute,|,styleprops,|,cite,abbr,acronym,del,ins,attribs,|,visualchars,nonbreaking,template,restoredraft",
	theme_advanced_toolbar_location : "top",
	theme_advanced_toolbar_align : "left",
	theme_advanced_statusbar_location : "bottom",
	theme_advanced_resizing : true,
});
</script>
<table cellspacing="0" cellpadding="0" border="0" width="100%">
	<tr>
		<td valign="top">
			<table  class="widefat page">
				<tr>
					<td width="100">
						<label for="subject">
							<?php echo RSE_EMAIL_SUBJECT.':'; ?>
						</label>
					</td>
					<td>
						<input type="text" name="rseventsConfig[emails.invite.subject]" value="<?php echo $RSEConfig['emails.invite.subject'];  ?>" size="55" maxlength="50">
					</td>
				</tr>
				<tr>
					<td width="100">
						<label for="">
							<?php echo RSE_EMAIL_MODE.':'; ?>
						</label>
					</td>
					<td>
						<input type="radio" <?php checked($RSEConfig['emails.invite.type'],0,true); ?> value="0" id="emails.invite.type0" name="rseventsConfig[emails.invite.type]"/>
						<label for="emails.invite.type0"><?php echo RSE_TEXT; ?></label>
						<input type="radio" <?php checked($RSEConfig['emails.invite.type'],1,true); ?> value="1" id="emails.invite.type1" name="rseventsConfig[emails.invite.type]"/>
						<label for="emails.invite.type1"><?php echo RSE_HTML; ?></label>
					</td>
				</tr>
				<tr>
					<td width="100">
						<label for="reply">
							<?php echo RSE_EMAIL_MESSAGE.':'; ?>
						</label>
					</td>
					<td>
					<?php if($RSEConfig['emails.invite.type'] == 1) 					
						echo '<textarea name="rseventsConfig[emails.invite.content]" rows="20" cols="100%">'.$RSEConfig['emails.invite.content'].'</textarea>';
						else
						{
					?>
						<textarea name="rseventsConfig[emails.invite.content]" rows="10" cols="100%"><?php echo $RSEConfig['emails.invite.content'];  ?></textarea>
					<?php } ?>
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>

<?php } break; ?>

<?php } ?>
<input type="hidden" name="option" value="" />
</form>
</div>